"""Manual smoke test against a running Step-1 server on localhost:8000.

Run from the repository/package root after starting backend/server.py.
The theme-assist calls are live and may use R2D2 plus ADK/Gemini in the internal environment.
"""
from __future__ import annotations

import json
import urllib.request

BASE = "http://127.0.0.1:8000"


def get(path: str, timeout: int = 10):
    with urllib.request.urlopen(BASE + path, timeout=timeout) as response:
        return json.loads(response.read().decode())


def post(path: str, body, timeout: int = 300):
    request = urllib.request.Request(
        BASE + path,
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode())


def show(label: str, payload) -> None:
    print(f"\n=== {label} ===")
    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    show("HEALTH", get("/health"))

    # Theme-quality gate examples requested for testing.
    show("THEME ASSIST — STRONG", post(
        "/api/v1/rpr/themes/assist",
        {"theme": "US trade policy and tariffs", "description": "Corporate margin, refinancing and spread transmission"},
        timeout=180,
    ))
    show("THEME ASSIST — BROAD", post(
        "/api/v1/rpr/themes/assist",
        {"theme": "US", "description": ""},
        timeout=180,
    ))
    show("THEME ASSIST — AMBIGUOUS", post(
        "/api/v1/rpr/themes/assist",
        {"theme": "FIFA", "description": ""},
        timeout=180,
    ))
    show("THEME ASSIST — OFF DOMAIN", post(
        "/api/v1/rpr/themes/assist",
        {"theme": "cooking", "description": ""},
        timeout=180,
    ))

    print("\nLive Trigger-1 and Trigger-2 calls are intentionally commented out because they can take several minutes.")
    print("Uncomment them after the theme gate responses are verified.")

    # trigger1 = post(
    #     "/api/v1/rpr/market-events/fetch",
    #     {
    #         "themes": ["US trade policy and tariffs"],
    #         "theme_inputs": [
    #             {
    #                 "theme": "US trade policy and tariffs",
    #                 "description": "Corporate margin, refinancing and spread transmission",
    #             }
    #         ],
    #         "max_events_per_theme": 3,
    #     },
    #     timeout=900,
    # )
    # show("TRIGGER 1", trigger1)

    # trigger2 = post(
    #     "/api/v1/rpr/step1/enrich",
    #     {
    #         "narrative": "ABC Bank five-year CDS widened after concerns about commercial real-estate exposure."
    #     },
    #     timeout=600,
    # )
    # show("TRIGGER 2", trigger2)
