import json
import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

import theme_assistant  # noqa: E402


def test_obvious_off_domain_fallback():
    result = theme_assistant._fallback_classification("cooking", "")
    assert result["classification"] == "OFF_DOMAIN"
    assert result["scan_recommendation"] == "SUGGEST_MARKET_THEMES"


def test_geography_only_is_relevant_but_broad():
    result = theme_assistant._fallback_classification("US", "")
    assert result["classification"] == "RELEVANT_BUT_BROAD"
    assert result["credit_relevance"] == "MEDIUM"


def test_fifa_without_financial_context_is_ambiguous():
    result = theme_assistant._fallback_classification("FIFA", "")
    assert result["classification"] == "AMBIGUOUS"


def test_specific_credit_theme_is_strong():
    result = theme_assistant._fallback_classification("US trade policy and tariffs", "Corporate margin and credit spread transmission")
    assert result["classification"] == "STRONG"
    assert result["scan_recommendation"] == "SCAN"


def test_non_strong_theme_gets_live_web_suggestions(monkeypatch):
    monkeypatch.setattr(
        theme_assistant,
        "classify_theme",
        lambda theme, description="": {
            "classification": "OFF_DOMAIN",
            "credit_relevance": "NONE",
            "specificity": "LOW",
            "scan_recommendation": "SUGGEST_MARKET_THEMES",
            "reason": "Off domain",
        },
    )
    payload = {
        "suggestions": [
            {
                "theme": "US trade and tariff policy",
                "rationale": "Current policy changes have direct corporate margin and credit implications.",
                "relationship_to_original": "ALTERNATIVE",
                "evidence_strength": "HIGH",
                "key_credit_channels": ["corporate margins", "trade", "spreads"],
                "source_names": ["Reuters"],
                "source_urls": ["https://www.reuters.com/example1"],
            },
            {
                "theme": "Global monetary-policy divergence and funding conditions",
                "rationale": "Rate divergence affects refinancing, FX and funding conditions.",
                "relationship_to_original": "ALTERNATIVE",
                "evidence_strength": "HIGH",
                "key_credit_channels": ["rates", "funding", "FX"],
                "source_names": ["Federal Reserve"],
                "source_urls": ["https://www.federalreserve.gov/example2"],
            },
            {
                "theme": "Energy supply disruption and commodity credit risk",
                "rationale": "Energy prices transmit to sovereign and corporate credit conditions.",
                "relationship_to_original": "ALTERNATIVE",
                "evidence_strength": "MEDIUM",
                "key_credit_channels": ["commodities", "inflation", "sovereign"],
                "source_names": ["IEA"],
                "source_urls": ["https://www.iea.org/example3"],
            },
        ]
    }
    monkeypatch.setattr(theme_assistant, "_adk_search_sync", lambda prompt, timeout=120: json.dumps(payload))
    result = theme_assistant.assist_theme("cooking")
    assert result["classification"] == "OFF_DOMAIN"
    assert result["suggestion_status"] == "SUCCESS"
    assert len(result["suggestions"]) == 3
    assert result["suggestions"][0]["theme"] == "US trade and tariff policy"


def test_live_suggestion_failure_does_not_invent_fallback_themes(monkeypatch):
    monkeypatch.setattr(
        theme_assistant,
        "classify_theme",
        lambda theme, description="": {
            "classification": "RELEVANT_BUT_BROAD",
            "credit_relevance": "HIGH",
            "specificity": "LOW",
            "scan_recommendation": "REFINE",
            "reason": "Broad",
        },
    )
    def fail(prompt, timeout=120):
        raise RuntimeError("search unavailable")
    monkeypatch.setattr(theme_assistant, "_adk_search_sync", fail)
    result = theme_assistant.assist_theme("geopolitics")
    assert result["suggestion_status"] == "TECHNICAL_FAILURE"
    assert result["suggestions"] == []


def test_web_dossier_can_be_normalized_by_llm_gateway(monkeypatch):
    monkeypatch.setattr(
        theme_assistant,
        "classify_theme",
        lambda theme, description="": {
            "classification": "RELEVANT_BUT_BROAD",
            "credit_relevance": "MEDIUM",
            "specificity": "LOW",
            "scan_recommendation": "REFINE",
            "reason": "Broad geography",
        },
    )
    monkeypatch.setattr(
        theme_assistant,
        "_adk_search_sync",
        lambda prompt, timeout=120: "Current evidence dossier: tariffs, Treasury funding, and banking credit conditions.",
    )
    payload = {
        "suggestions": [
            {
                "theme": "US trade policy and tariff developments",
                "rationale": "Supported by the dossier.",
                "relationship_to_original": "DIRECT",
                "evidence_strength": "HIGH",
                "key_credit_channels": ["corporate margins"],
                "source_names": ["Reuters"],
                "source_urls": ["https://www.reuters.com/example"],
            }
        ]
    }
    fake = types.ModuleType("llm_gateway")
    class Gateway:
        def call_text(self, system_prompt, user_prompt, max_tokens=1400):
            assert "enterprise_web_evidence_dossier" in user_prompt
            return json.dumps(payload)
    fake.get_gateway = lambda: Gateway()
    monkeypatch.setitem(sys.modules, "llm_gateway", fake)
    result = theme_assistant.assist_theme("US")
    assert result["suggestion_status"] == "SUCCESS"
    assert result["suggestions"][0]["theme"] == "US trade policy and tariff developments"


def test_materially_overlapping_theme_is_filtered():
    suggestions = [
        {"theme": "US trade protectionism and tariff-driven corporate margin pressure"},
        {"theme": "European bank funding and refinancing conditions"},
    ]
    filtered = theme_assistant._filter_existing_theme_duplicates(
        suggestions,
        ["US Trade Policy & Tariffs"],
    )
    assert len(filtered) == 1
    assert filtered[0]["theme"] == "European bank funding and refinancing conditions"
