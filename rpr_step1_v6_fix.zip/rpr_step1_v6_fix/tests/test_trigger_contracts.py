import importlib
import json
import sys
import types
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND))

from step1_quality import SECTION_TITLES  # noqa: E402


def full_report(credit_text=None):
    parts = []
    for title in SECTION_TITLES:
        if title == "Credit Market Impact" and credit_text:
            text = credit_text
            tier = "SUFFICIENT"
        else:
            text = (
                f"{title} has a sourced 10% observation on 2026-08-10. "
                f"(Source: [Reuters, 2026-08-10](https://www.reuters.com/{title.lower().replace(' ', '-')}))"
            )
            tier = "SUFFICIENT"
        parts.append(f"{title}: {text}\n[EVIDENCE_TIER: {tier}]\n[RETRIEVAL_STATUS: SUCCESS]")
    return "\n".join(parts) + "\nSearch Queries Used:\n- exact test query"


def test_trigger1_two_pass_uses_description_and_returns_three(monkeypatch):
    import market_event_scout

    prompts = []
    discovery = {
        "events": [
            {"title": "Event A", "event_date": "2026-08-10", "why_material": "A", "search_seed": "A credit", "confidence": "HIGH"},
            {"title": "Event B", "event_date": "2026-08-11", "why_material": "B", "search_seed": "B credit", "confidence": "HIGH"},
            {"title": "Event C", "event_date": "2026-08-12", "why_material": "C", "search_seed": "C credit", "confidence": "MEDIUM"},
        ]
    }

    def fake_search(prompt, timeout=240):
        prompts.append(prompt)
        if "MODE: DISCOVERY" in prompt:
            return json.dumps(discovery)
        return full_report()

    monkeypatch.setattr(market_event_scout, "_adk_search_sync", fake_search)
    monkeypatch.setattr(market_event_scout, "_PARALLEL_ENRICH", False)
    scout = market_event_scout.MarketEventScout()
    result = scout.fetch_events(
        [{"theme": "US Trade Policy & Tariffs", "description": "Focus on corporate margins and refinancing stress"}],
        max_events_per_theme=3,
    )
    assert result["total"] == 3
    assert result["theme_inputs"][0]["description"] == "Focus on corporate margins and refinancing stress"
    assert "THEME_DESCRIPTION: Focus on corporate margins and refinancing stress" in prompts[0]
    assert all(len(ev["sections"]) == 8 for ev in result["events"])


def test_trigger1_discovery_normalizer_is_used_when_adk_format_is_not_json(monkeypatch):
    import market_event_scout

    prompts = []
    def fake_search(prompt, timeout=240):
        prompts.append(prompt)
        if "MODE: DISCOVERY" in prompt:
            return "Web research found Event A and Event B, but the shared search agent returned prose."
        return full_report()

    monkeypatch.setattr(market_event_scout, "_adk_search_sync", fake_search)
    monkeypatch.setattr(
        market_event_scout,
        "_normalize_discovery_with_llm",
        lambda **kwargs: [
            market_event_scout.CandidateEvent(title="Event A", search_seed="Event A credit"),
            market_event_scout.CandidateEvent(title="Event B", search_seed="Event B credit"),
        ],
    )
    monkeypatch.setattr(market_event_scout, "_PARALLEL_ENRICH", False)
    scout = market_event_scout.MarketEventScout()
    result = scout.fetch_events([{"theme": "Broad Theme", "description": "credit"}], 3)
    assert result["total"] == 2
    assert result["events"][0]["subtitle"] == "Event A"


def test_trigger2_preserves_specific_narrative_and_uses_r2d2(monkeypatch):
    # narrative_enricher requires the governed R2D2_PROMPT module. Stub only for this unit test.
    stub = types.ModuleType("r2d2_prompt")
    stub.R2D2_PROMPT = "R2D2 BASE PROMPT — {narrative} — {REPORT_AS_OF}"
    sys.modules["r2d2_prompt"] = stub
    if "narrative_enricher" in sys.modules:
        del sys.modules["narrative_enricher"]
    narrative_enricher = importlib.import_module("narrative_enricher")

    captured = {"search": "", "system": "", "user": ""}
    narrative = "ABC Bank five-year CDS widened after concerns about commercial real-estate exposure."

    def fake_search(prompt, timeout=240):
        captured["search"] = prompt
        return "Evidence dossier with sources.\nSearch Queries Used:\n- ABC Bank CDS commercial real estate"

    def fake_r2d2(system_prompt, user_prompt):
        captured["system"] = system_prompt
        captured["user"] = user_prompt
        return full_report(
            "ABC Bank five-year CDS widened 45 bps on 2026-08-10. "
            "(Source: [Reuters, 2026-08-10](https://www.reuters.com/abc-bank))"
        )

    monkeypatch.setattr(narrative_enricher, "_adk_search_sync", fake_search)
    monkeypatch.setattr(narrative_enricher, "_call_r2d2", fake_r2d2)
    result = narrative_enricher.enrich_narrative(narrative)
    assert narrative in captured["search"]
    assert narrative in captured["system"]
    assert narrative in captured["user"]
    assert result["model_path"] == "ADK Gemini enterprise retrieval -> R2D2/Claude synthesis"
    assert "45 bps" in result["credit_market_impact"]
    assert len(result["sections"]) == 8


def test_trigger2_removes_synthesis_url_not_present_in_web_dossier(monkeypatch):
    stub = types.ModuleType("r2d2_prompt")
    stub.R2D2_PROMPT = "R2D2 BASE PROMPT — {narrative} — {REPORT_AS_OF}"
    sys.modules["r2d2_prompt"] = stub
    if "narrative_enricher" in sys.modules:
        del sys.modules["narrative_enricher"]
    narrative_enricher = importlib.import_module("narrative_enricher")

    allowed_url = "https://www.reuters.com/allowed"
    invented_url = "https://www.example.com/not-in-dossier"
    monkeypatch.setattr(
        narrative_enricher,
        "_adk_search_sync",
        lambda prompt, timeout=240: f"Evidence dossier. Reuters source: {allowed_url}\nSearch Queries Used:\n- test",
    )

    def fake_r2d2(system_prompt, user_prompt):
        report = full_report(
            f"CDS widened 45 bps. (Source: [Reuters, 2026-08-10]({invented_url}))"
        )
        return report

    monkeypatch.setattr(narrative_enricher, "_call_r2d2", fake_r2d2)
    result = narrative_enricher.enrich_narrative("Specific bank credit event")
    assert invented_url not in result["credit_market_impact"]
    credit_meta = next(
        x for x in result["enhancement_meta"]["section_meta"]
        if x["section_name"] == "Credit Market Impact"
    )
    assert credit_meta["unverified_citation_count"] == 1
    assert any("citation" in x.lower() for x in credit_meta["limitations"])
