# RPR Step 1 Final Test Patch

This package is the final Step-1 test patch for both entry paths while preserving the v31 tech-lead visual baseline.

## Business behavior

### Trigger 1 — Market Scanner
1. Analyst enters one or more broad themes plus optional descriptions.
2. Theme Quality Gate classifies each theme as STRONG, RELEVANT_BUT_BROAD, AMBIGUOUS, LOW_CREDIT_RELEVANCE, or OFF_DOMAIN.
3. Non-STRONG themes show an analyst-controlled warning. A live Gemini/ADK search retrieves current market-risk evidence and a governed synthesis step proposes up to three stronger themes. The theme is never changed automatically.
4. If the analyst proceeds, Gemini 2.5 Flash + enterprise web search performs market-event discovery.
5. The scanner targets up to three distinct, recent, evidence-supported material events per theme.
6. Each selected event is enriched independently into the fixed eight Step-1 sections.

### Trigger 2 — User Narrative
1. Analyst enters a specific event narrative.
2. Gemini/ADK performs enterprise-web retrieval for that exact event.
3. R2D2/Claude synthesizes the retrieved evidence using the existing governed R2D2_PROMPT plus the Step-1 evidence-contract add-on.
4. The supplied narrative is preserved as scope/context and is not treated as evidence or replaced by a different event.

## Common eight-section contract

1. Event Overview
2. Event History
3. Direct Impact Geographies
4. Contagious Impact Geographies
5. Equity Market Impact
6. Credit Market Impact
7. Commodity Market Impact
8. Assumptions

Both triggers return the same machine-grade Step-1 payload (`schema_version: step1.v2`) behind the visible eight sections. It includes deterministic section quality, source/metric/date telemetry, evidence ledger, structured context when supported, retrieval status, readiness and query-log provenance.

## Evidence-quality controls

- Evidence sufficiency and retrieval execution are separate.
- `NONE` is allowed only when retrieval completed but no relevant evidence was found.
- Technical retrieval failure maps to `NOT_ASSESSED`, not `NONE`.
- Quantitative metrics are optional unless supported by retrieved evidence; no metric should be invented to fill coverage.
- Trigger-2 R2D2 direct-URL citations not present in the Gemini/ADK evidence dossier are removed before deterministic quality scoring.
- Model evidence tags are retained as conservative controls even after control tags are removed from visible text.
- Consequential/conflicting values are expected to be disclosed rather than silently reconciled.

## Evidence Coverage Can Be Improved

The old generic enhancement behavior is replaced by an evidence-repair workflow:
1. only `LIMITED/NONE + SUCCESS` sections are eligible for search diagnosis;
2. technical retrieval conditions are handled separately;
3. diagnosis defaults to NOT_RECOMMENDED;
4. the analyst reviews/edits the proposed search refinement;
5. `Prepare Rescan` only consolidates guidance;
6. `Confirm & Rescan` explicitly starts a targeted rescan;
7. only affected sections are eligible for replacement;
8. each affected section is compared before vs after;
9. non-improving replacements are rejected and original section text is retained;
10. backend-owned enhancement-assisted rescan count is capped at two per scope for this PoC.

## Analyst edits and downstream safety

When an analyst confirms Step 1, the frontend calls `/api/v1/rpr/step1/finalize`. The backend rebuilds deterministic evidence metadata from the confirmed text. Analyst-modified sections are explicitly flagged. Pre-edit model structured metadata is not reused when analyst edits are present, preventing downstream steps from consuming stale AI structure as if it described the confirmed text.

## Visual-design constraint

The v31 tech-lead static design is not redesigned. The v5 API test HTML retains the existing core CSS/layout and only adds compact styles required for the Theme Quality Gate and rescan-result status components.

## Files deliberately unchanged

Do not replace these as part of this patch:
- `backend/web_search_agent.py`
- `backend/r2d2_prompt.py`
- `backend/llm_gateway.py`
- `backend/rpr_service.py`
- `backend/main.py`
- the v31 tech-lead static baseline HTML

The patch intentionally relies on the existing `web_search_agent.run_web_search()` and `llm_gateway.get_gateway().call_text()` interfaces.

## Run

From the backend directory:

```bash
python server.py
```

Expected API base:

```text
http://127.0.0.1:8000
```

Open the test frontend:

```text
frontend/rpr-step1-test-v5.html
```

## Recommended test sequence

1. Verify `/health`.
2. Trigger 1 theme tests: `US trade policy and tariffs`, `US`, `FIFA`, `cooking`.
3. Confirm STRONG themes proceed without a warning card.
4. Confirm `US` is treated as relevant but broad and receives live current-market alternatives.
5. Confirm `FIFA` is treated as ambiguous/low-relevance unless a financial/credit description is supplied.
6. Confirm `cooking` is treated as off-domain and receives current market-risk alternatives rather than an invented connection.
7. Confirm choosing an ALTERNATIVE suggestion clears an unrelated old theme description; DIRECT/POSSIBLE refinements can retain the description.
8. Confirm Trigger 1 returns up to three distinct supported events per theme and does not invent events to fill a quota.
9. Inspect `enhancement_meta.section_meta` and `machine_payload` for each event.
10. Exercise an eligible LIMITED/NONE section through Prepare Rescan -> Confirm & Rescan.
11. Confirm only quality-improving affected sections are accepted.
12. Test Trigger 2 with a specific narrative and confirm the original narrative remains separate from refinement guidance.
13. Edit a section manually, confirm Step 1, and inspect the finalized payload's `analyst_state.modified_sections`.

## Automated local validation

```bash
pytest -q tests/test_step1_quality.py tests/test_theme_assistant.py tests/test_trigger_contracts.py
```

See `VALIDATION_REPORT.txt` for the validation performed before delivery.
