# Step 1 Final Test Patch — Changelog

## Theme Quality Gate
- Expanded from simple broad-theme detection to a credit-portfolio suitability gate.
- Classifications: STRONG, RELEVANT_BUT_BROAD, AMBIGUOUS, LOW_CREDIT_RELEVANCE, OFF_DOMAIN.
- Added live current-market evidence retrieval for non-STRONG themes.
- Added separate governed suggestion synthesis so shared ADK output formatting does not have to be JSON.
- Added analyst-only application of suggestions; no silent replacement.
- ALTERNATIVE suggestions clear an unrelated old description to avoid contaminating the new scan scope.

## Trigger 1
- Explicitly aligned to broad-theme market discovery.
- Discovery always precedes event enrichment; broad theme is never treated as a fake specific event.
- Targets up to three distinct supported events per theme.
- Added discovery-output normalizer for compatibility with shared search-agent formatting.
- Added targeted follow-up discovery searches when the first Gemini/ADK discovery result contains fewer than the requested event count.
- Each event is enriched independently; enrichment can run in parallel.
- Added common Step-1 machine payload and evidence ledger.

## Trigger 2
- Preserves specific user narrative scope.
- Uses Gemini/ADK for enterprise-web evidence retrieval and R2D2/Claude for synthesis.
- Existing `R2D2_PROMPT` remains unchanged.
- Added governed Trigger-2 retrieval prompt and synthesis add-on.
- Direct-URL synthesis citations absent from the retrieved evidence dossier are removed before quality scoring.

## Evidence quality
- Added deterministic source, approved-source, metric, date, conflict and retrieval telemetry.
- Preserves model evidence tier as a conservative control after visible control tags are stripped.
- Added source dates and latest source date metadata.
- `NONE` is distinct from technical failure.
- Noncritical technical failure yields READY_WITH_LIMITATIONS; critical technical failure can block readiness.
- Added structured_context plus deterministic evidence_ledger to `step1.v2`.

## Evidence Coverage improvement
- Renamed generic improvement card to evidence-focused language.
- Added controlled diagnosis cause codes and richer evidence summary.
- Added NOT_APPLICABLE and INSUFFICIENT_INPUT states.
- Added analyst Prepare Rescan -> Confirm & Rescan flow.
- Added section-targeted rescans.
- Added before/after quality measurement.
- Accepts only affected sections that materially improve; preserves original otherwise.
- Backend owns enhancement-assisted rescan count.

## Analyst confirmation
- Added `/api/v1/rpr/step1/finalize`.
- Rebuilds deterministic machine payload from analyst-confirmed text.
- Explicitly marks analyst-modified sections.
- Prevents stale pre-edit model structured metadata from being silently reused after manual edits.

## UI
- Core v31-derived CSS/layout is preserved.
- Only compact Theme Quality Gate and rescan-result styles are added.
- API test HTML version is `rpr-step1-test-v5.html`.
