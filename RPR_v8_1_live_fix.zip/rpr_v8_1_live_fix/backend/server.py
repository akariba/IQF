"""Active Step-1 FastAPI backend for the RPR HTML prototype."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from market_event_scout import MarketEventScout
from narrative_enricher import NarrativeEnrichError, enrich_narrative
from rpr_enhancement_routes import (
    enhancement_router,
    can_rescan,
    register_rescan_result,
)
from theme_assistant import assist_theme
from step1_quality import build_machine_payload
from step2_routes import step2_router
from rpr_feedback_routes import feedback_router

app = FastAPI(
    title="ICM PM Rapid Portfolio Review — Backend",
    version="1.6.1",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(enhancement_router)
app.include_router(step2_router)
app.include_router(feedback_router)

_scout = MarketEventScout()


class ThemeInput(BaseModel):
    theme: str
    description: str = ""


class FetchRequest(BaseModel):
    # `themes` is retained for backward compatibility with the current HTML/API callers.
    themes: List[str] = Field(default_factory=list)
    theme_inputs: List[ThemeInput] = Field(default_factory=list)
    max_events_per_theme: int = 3


class RefineRequest(BaseModel):
    event: Dict[str, Any]
    feedback: str
    affected_sections: List[str] = Field(default_factory=list)
    analyst_modified_sections: List[str] = Field(default_factory=list)


class EnrichRequest(BaseModel):
    narrative: str


class ThemeAssistRequest(BaseModel):
    theme: str
    description: str = ""


class FinalizeStep1Request(BaseModel):
    trigger: str
    event: Dict[str, Any] = Field(default_factory=dict)
    sections: List[Dict[str, Any]] = Field(default_factory=list)
    base_machine_payload: Dict[str, Any] = Field(default_factory=dict)
    analyst_modified_sections: List[str] = Field(default_factory=list)


@app.get("/health")
def health() -> Dict[str, Any]:
    pf = _scout.preflight()
    return {
        "status": "ok" if pf.get("ok") else "degraded",
        "version": "1.6.1",
        "step1": pf,
    }


@app.post("/api/v1/rpr/themes/assist")
def theme_assist(req: ThemeAssistRequest) -> Dict[str, Any]:
    theme = str(req.theme or "").strip()
    if not theme:
        raise HTTPException(status_code=400, detail="Theme is required")
    return assist_theme(theme=theme, description=req.description)


@app.post("/api/v1/rpr/step1/finalize")
def finalize_step1(req: FinalizeStep1Request) -> Dict[str, Any]:
    """Rebuild the machine payload from the analyst-confirmed Step-1 text.

    This prevents downstream steps from consuming stale AI-generated section text after
    the analyst has edited a section. Model-suggested structured metadata is retained only
    when no section was modified; deterministic evidence metadata is always rebuilt.
    """
    trigger = str(req.trigger or "").strip().lower()
    if trigger not in {"trigger1", "trigger2"}:
        raise HTTPException(status_code=400, detail="trigger must be trigger1 or trigger2")
    if not req.sections:
        raise HTTPException(status_code=400, detail="Confirmed Step-1 sections are required")

    modified = []
    seen = set()
    for item in req.analyst_modified_sections:
        name = str(item or "").strip()
        if name and name not in seen:
            seen.add(name)
            modified.append(name)

    base = req.base_machine_payload or {}
    query_log = base.get("search_queries") if isinstance(base.get("search_queries"), list) else []
    query_log_source = str(base.get("query_log_source") or "unknown")
    base_model_metadata = base.get("model_metadata") if isinstance(base.get("model_metadata"), dict) else {}
    payload = build_machine_payload(
        trigger=trigger,
        sections=req.sections,
        event=req.event,
        query_log=query_log,
        query_log_source=query_log_source,
        model_metadata=base_model_metadata if not modified else {},
    )
    payload["analyst_state"] = {
        "confirmed": True,
        "modified_sections": modified,
        "structured_model_metadata_reused": not bool(modified),
        "note": (
            "Deterministic evidence metadata was rebuilt from confirmed text. "
            "Pre-edit model structured metadata was not reused for analyst-modified sections."
            if modified
            else "Confirmed text matches the current AI-generated section baseline."
        ),
    }
    return {"machine_payload": payload, "quality": payload.get("quality")}


@app.post("/api/v1/rpr/market-events/fetch")
def fetch_market_events(req: FetchRequest) -> Dict[str, Any]:
    theme_specs: List[Dict[str, str]] = []
    for item in req.theme_inputs:
        theme = str(item.theme or "").strip()
        if theme:
            theme_specs.append({"theme": theme, "description": str(item.description or "").strip()})
    if not theme_specs:
        theme_specs = [
            {"theme": str(t).strip(), "description": ""}
            for t in req.themes
            if str(t).strip()
        ]
    if not theme_specs:
        raise HTTPException(status_code=400, detail="At least one theme is required")
    try:
        return _scout.fetch_events(themes=theme_specs, max_events_per_theme=req.max_events_per_theme)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Market scanner failed: {exc}") from exc


@app.post("/api/v1/rpr/market-events/refine")
def refine_market_event(req: RefineRequest) -> Dict[str, Any]:
    feedback = str(req.feedback or "").strip()
    if not feedback:
        raise HTTPException(status_code=400, detail="Feedback is required")
    theme = str(req.event.get("theme_name") or req.event.get("theme") or "")
    event_id = int(req.event.get("id") or req.event.get("event_id") or 0)
    if not can_rescan("trigger1", theme=theme, event_id=event_id):
        raise HTTPException(status_code=409, detail="Maximum enhancement-assisted rescan count reached for this event")
    try:
        updated = _scout.refine_event(
            event=req.event,
            feedback=feedback,
            affected_sections=req.affected_sections,
            analyst_modified_sections=req.analyst_modified_sections,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Targeted rescan failed: {exc}") from exc

    outcome = str((updated.get("rescan_result") or {}).get("outcome") or "COMPLETED")
    count = register_rescan_result(
        scope_type="trigger1",
        theme=theme,
        event_id=event_id,
        feedback=feedback,
        outcome=outcome,
    )
    updated.setdefault("rescan_result", {})["attempt_count"] = count
    return {"event": updated, "rescan_result": updated.get("rescan_result")}


@app.post("/api/v1/rpr/step1/enrich")
def step1_enrich(req: EnrichRequest) -> Dict[str, Any]:
    narrative = str(req.narrative or "").strip()
    if not narrative:
        raise HTTPException(status_code=400, detail="Narrative is required")
    try:
        return enrich_narrative(narrative=narrative)
    except NarrativeEnrichError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("server:app", host="127.0.0.1", port=8000, reload=True)
