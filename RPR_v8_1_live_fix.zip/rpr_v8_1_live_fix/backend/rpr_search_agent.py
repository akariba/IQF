"""Citi-ADK-native Gemini 3.5 enterprise web-search runtime for RPR.

This module is the ONLY Step-1 enterprise-web entry point in the consolidated build.
It intentionally does not fall back to the legacy ``web_search_agent.py`` path.

Runtime contract
----------------
* Gemini model: ``gemini-3.5-flash`` by default.
* Vertex location: ``us`` by default (per-instance override via the Citi ADK Adapter).
* Search tool: ``enterprise_web_search``.
* Fresh Vertex model + LlmAgent + InMemorySessionService + Runner for EVERY call.
  Nothing owning an async HTTP/session lifecycle is cached across threads/event loops.
* Authentication is delegated to the official Citi ADK Adapter. Per the internal adapter
  README, CLIENT_ID/CLIENT_SECRET use COIN auth; otherwise the adapter can use Helix CLI
  auth. RPR itself never logs or persists credentials/tokens.

The fresh-per-call lifecycle is deliberate: it prevents the cross-event-loop connector
reuse that previously produced ``AssertionError: self._connector is not None``.
"""
from __future__ import annotations

import json
import logging
import os
import uuid
from typing import Any, Dict

from google.adk.agents import LlmAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools import enterprise_web_search
from google.genai import types
from citi_adk_adapter.models import Vertex

from rpr_model_trace import model_span

log = logging.getLogger("uvicorn.error")

_BASE_MODEL = os.environ.get("RPR_GEMINI_MODEL", "gemini-3.5-flash")
DISCOVERY_MODEL = os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", _BASE_MODEL)
EVIDENCE_MODEL = os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", _BASE_MODEL)
THEME_MODEL = os.environ.get("RPR_GEMINI_THEME_MODEL", _BASE_MODEL)
VERTEX_LOCATION = os.environ.get("RPR_GEMINI_LOCATION", "us")
APP_NAME = os.environ.get("RPR_GEMINI_APP_NAME", "rpr_enterprise_web")
USER_ID = os.environ.get("RPR_GEMINI_USER_ID", "rpr-user")

BASE_INSTRUCTION = """You are the enterprise-web retrieval layer for a bank credit-risk application.
Use enterprise_web_search whenever current/public evidence is requested.
Follow the caller's event/theme scope and output contract exactly.
Prefer primary/authoritative sources and reputable financial news.
Never invent facts, numbers, publication dates, URLs, source support, or search execution.
If evidence is unavailable, say so in the requested schema.
Do not replace the requested event with a different event.
Do not perform final credit-risk synthesis when the caller asks for an evidence dossier.
"""


def model_for_role(role: str) -> str:
    role_l = str(role or "evidence").strip().lower()
    if role_l == "theme":
        return THEME_MODEL
    if role_l == "discovery":
        return DISCOVERY_MODEL
    return EVIDENCE_MODEL


def runtime_info() -> Dict[str, Any]:
    """Non-secret runtime configuration for health/debug output."""
    env = _prepare_adapter_environment()
    constructor_ok = True
    constructor_error = ""
    try:
        Vertex(model=DISCOVERY_MODEL)
    except Exception as exc:  # constructor-only preflight; no search/network request
        constructor_ok = False
        constructor_error = f"{type(exc).__name__}: {exc}"
    return {
        "provider": "citi_adk_adapter.Vertex",
        "discovery_model": DISCOVERY_MODEL,
        "evidence_model": EVIDENCE_MODEL,
        "theme_model": THEME_MODEL,
        "vertex_location": VERTEX_LOCATION,
        "adapter_vertex_location": env.get("VERTEX_LOCATION"),
        "adapter_constructor": "Vertex(model=...)",
        "adapter_constructor_ok": constructor_ok,
        "adapter_constructor_error": constructor_error or None,
        "search_tool": "enterprise_web_search",
        "agent_lifecycle": "fresh_per_call",
        "legacy_search_fallback": False,
    }


def _prepare_adapter_environment() -> Dict[str, str]:
    """Bridge the RPR/current project env names to the official Citi ADK Adapter names.

    The internal adapter README uses VERTEX_PROJECT / VERTEX_LOCATION / VERTEX_ENDPOINT.
    The existing RPR project historically used VERTEX_PROJECT_ID /
    VERTEX_PROJECT_LOCATION / BASE_VERTEX_URL.  Keep both in sync so the adapter receives
    the same approved project/endpoint configuration without requiring another manual
    environment migration.  No credentials/tokens are copied or logged here.
    """
    os.environ["VERTEX_LOCATION"] = VERTEX_LOCATION
    project = os.environ.get("VERTEX_PROJECT") or os.environ.get("VERTEX_PROJECT_ID")
    if project:
        os.environ.setdefault("VERTEX_PROJECT", project)
    endpoint = os.environ.get("VERTEX_ENDPOINT") or os.environ.get("BASE_VERTEX_URL")
    if endpoint:
        os.environ.setdefault("VERTEX_ENDPOINT", endpoint.rstrip("/"))
    return {
        "VERTEX_LOCATION": os.environ.get("VERTEX_LOCATION", ""),
        "VERTEX_PROJECT": os.environ.get("VERTEX_PROJECT", ""),
        "VERTEX_ENDPOINT_SOURCE": "VERTEX_ENDPOINT" if os.environ.get("VERTEX_ENDPOINT") else "adapter_default",
    }


def _new_vertex(model_name: str) -> Vertex:
    """Create a fresh Citi Vertex wrapper using the reference implementation pattern.

    The Citi reference implementation provided for this project constructs
    ``Vertex(model=...)`` and resolves location from the adapter environment.  v8 used
    the newer ``model_location=`` constructor argument, which is not available in every
    installed adapter build and can fail before the model trace starts.  Use the broadly
    compatible constructor and force VERTEX_LOCATION=us through the official adapter env.
    """
    _prepare_adapter_environment()
    return Vertex(model=model_name)


def _new_agent(role: str) -> LlmAgent:
    model_name = model_for_role(role)
    # IMPORTANT: both Vertex and LlmAgent are fresh for every call.
    return LlmAgent(
        name=f"rpr_web_{str(role or 'evidence').lower()}_{uuid.uuid4().hex[:10]}",
        model=_new_vertex(model_name),
        instruction=BASE_INSTRUCTION,
        description="RPR Citi-ADK enterprise web retrieval agent",
        tools=[enterprise_web_search],
        output_key="results",
    )


def _to_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (dict, list, tuple)):
        try:
            return json.dumps(value, ensure_ascii=False)
        except Exception:
            return str(value)
    return str(value)


async def run_web_search(
    query: str,
    role: str = "evidence",
    trace_label: str = "",
    **_: Any,
) -> Dict[str, Any]:
    """Run one isolated Gemini 3.5 + enterprise_web_search invocation."""
    prompt = str(query or "").strip()
    if not prompt:
        raise ValueError("Search query/prompt is required")

    model_name = model_for_role(role)
    session_id = "rprws-" + uuid.uuid4().hex

    with model_span(
        provider="citi-adk-vertex",
        model=model_name,
        role=f"enterprise_web_{str(role or 'evidence').lower()}",
        scope=trace_label,
    ) as trace:
        env = _prepare_adapter_environment()
        log.info(
            "[RPR-SEARCH] config model=%s location=%s adapter_location=%s lifecycle=fresh_per_call tool=enterprise_web_search scope=%s",
            model_name,
            VERTEX_LOCATION,
            env.get("VERTEX_LOCATION") or "-",
            trace_label or "-",
        )
        # Construct everything inside the trace so constructor/session failures are visible
        # instead of being silently converted into a zero-event scan.
        session_service = InMemorySessionService()
        agent = _new_agent(role)
        await session_service.create_session(
            app_name=APP_NAME,
            user_id=USER_ID,
            session_id=session_id,
        )
        runner = Runner(
            agent=agent,
            app_name=APP_NAME,
            session_service=session_service,
        )
        message = types.Content(role="user", parts=[types.Part(text=prompt)])

        final_chunks: list[str] = []
        async for event in runner.run_async(
            user_id=USER_ID,
            session_id=session_id,
            new_message=message,
        ):
            is_final = getattr(event, "is_final_response", None)
            try:
                final = bool(is_final()) if callable(is_final) else bool(is_final)
            except Exception:
                final = False
            if not final:
                continue
            content = getattr(event, "content", None)
            for part in getattr(content, "parts", []) or []:
                text = getattr(part, "text", None)
                if text:
                    final_chunks.append(str(text))

        answer = "\n".join(x for x in final_chunks if x).strip()

        # Some ADK agents primarily persist output_key into session state. Mirror the
        # internal reference implementation by reading state if the final event had no text.
        if not answer:
            session = await session_service.get_session(
                app_name=APP_NAME,
                user_id=USER_ID,
                session_id=session_id,
            )
            state = getattr(session, "state", {}) if session is not None else {}
            if isinstance(state, dict):
                for key in ("results", "web_search_results"):
                    candidate = _to_text(state.get(key)).strip()
                    if candidate:
                        answer = candidate
                        break

        if not answer:
            raise RuntimeError("Gemini enterprise web search completed without a usable result")

        trace.output_chars = len(answer)

    return {
        "answer": answer,
        "raw": answer,
        "role": role,
        "model": model_name,
        "vertex_location": VERTEX_LOCATION,
        "model_trace": trace.to_dict(),
    }
