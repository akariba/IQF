"""Step-1 deterministic evidence-quality utilities.

This module is intentionally model-agnostic.  It turns the eight Step-1 text
sections into richer machine metadata that can be consumed by the enhancement
workflow and downstream RPR steps.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

SECTION_TITLES: List[str] = [
    "Event Overview",
    "Event History",
    "Direct Impact Geographies",
    "Contagious Impact Geographies",
    "Equity Market Impact",
    "Credit Market Impact",
    "Commodity Market Impact",
    "Assumptions",
]

CANONICAL_NO_DATA = "No significant data identified in the sources reviewed for the defined three-month window."
CANONICAL_LIMITED_SUFFIX = "No significant additional data identified in the sources reviewed for the defined three-month window."

APPROVED_SOURCE_NAMES = {
    "bloomberg", "reuters", "lseg", "financial times", "ft", "sec", "sec edgar",
    "wall street journal", "wsj", "cnbc", "marketwatch", "ecb", "european central bank",
    "federal reserve", "fed", "bis", "bank for international settlements", "s&p", "s&p global",
    "moody's", "moodys", "fitch", "iea", "opec", "world bank", "imf", "fdic", "finma",
}

_SOURCE_RE = re.compile(
    r"\(Source:\s*\[([^\],]+),\s*(\d{4}-\d{2}-\d{2})\]\((https?://[^)]+)\)\)",
    re.IGNORECASE,
)
_EVIDENCE_TAG_RE = re.compile(r"\[EVIDENCE_TIER:\s*(SUFFICIENT|LIMITED|NONE|NOT_ASSESSED)\]", re.IGNORECASE)
_RETRIEVAL_TAG_RE = re.compile(
    r"\[RETRIEVAL_STATUS:\s*(SUCCESS|COMPLETED|PARTIAL_TECHNICAL_FAILURE|TECHNICAL_FAILURE|FAILED)\]",
    re.IGNORECASE,
)
_CONTROL_TAG_RE = re.compile(
    r"\[(?:EVIDENCE_TIER|RETRIEVAL_STATUS):\s*[^\]]+\]",
    re.IGNORECASE,
)
_URL_RE = re.compile(r"https?://[^\s)\]]+", re.IGNORECASE)
_DATE_RE = re.compile(r"\b(?:19|20)\d{2}[-/]\d{1,2}[-/]\d{1,2}\b|\b(?:19|20)\d{2}\b")
_METRIC_SUFFIX_RE = re.compile(
    r"(?<!\w)(?:[-+]?\d{1,3}(?:,\d{3})*(?:\.\d+)?|[-+]?\d+(?:\.\d+)?)\s*"
    r"(?:%|percentage\s+points?|pp|bps?|basis\s+points?|bp|million|billion|trillion|"
    r"USD|EUR|GBP|CHF|JPY|PLN|CNY|RMB|x|times|points?|index\s+points?|barrels?|bpd|mb/d|mt|tons?|tonnes?)(?=\s|[.,;:)\]]|$)",
    re.IGNORECASE,
)
_METRIC_PREFIX_RE = re.compile(
    r"(?<!\w)(?:USD|EUR|GBP|CHF|JPY|PLN|CNY|RMB|\$|€|£|¥)\s*"
    r"(?:[-+]?\d{1,3}(?:,\d{3})*(?:\.\d+)?|[-+]?\d+(?:\.\d+)?)"
    r"(?:\s*(?:million|billion|trillion))?\b",
    re.IGNORECASE,
)
_FINANCE_TERM_RE = re.compile(
    r"\b(?:cds|spread|yield|bond|rating|downgrade|watch|funding|liquidity|equity|index|shares?|"
    r"volatility|oil|gold|gas|commodity|fx|currency|default|sovereign|credit|basis points?|bps?)\b",
    re.IGNORECASE,
)
_CONFLICT_RE = re.compile(r"\b(?:conflict|discrepancy|differ(?:s|ed|ent)|versus|vs\.?|reported\s+.*but)\b", re.IGNORECASE)


@dataclass
class SourceEvidence:
    publisher: str
    publication_date: str
    url: str
    approved: bool


@dataclass
class SectionAssessment:
    section_name: str
    evidence_tier: str
    retrieval_status: str
    deterministic_score: int
    char_count: int
    source_count: int
    approved_source_count: int
    source_names: List[str]
    source_dates: List[str]
    latest_source_date: Optional[str]
    metric_count: int
    has_date: bool
    has_financial_terms: bool
    conflict_detected: bool
    unverified_citation_count: int
    limitations: List[str]
    model_evidence_tier: Optional[str] = None
    model_retrieval_status: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _approved_source(name: str) -> bool:
    n = re.sub(r"\s+", " ", (name or "").strip().lower())
    return any(a == n or a in n or n in a for a in APPROVED_SOURCE_NAMES)


def normalize_retrieval_status(value: Optional[str]) -> str:
    v = (value or "SUCCESS").strip().upper()
    if v == "COMPLETED":
        return "SUCCESS"
    if v == "FAILED":
        return "TECHNICAL_FAILURE"
    if v in {"SUCCESS", "PARTIAL_TECHNICAL_FAILURE", "TECHNICAL_FAILURE"}:
        return v
    return "SUCCESS"


def strip_control_tags(text: str) -> str:
    return _CONTROL_TAG_RE.sub("", str(text or "")).strip()


def extract_model_tags(text: str) -> Tuple[Optional[str], Optional[str]]:
    t = str(text or "")
    ev = _EVIDENCE_TAG_RE.search(t)
    rs = _RETRIEVAL_TAG_RE.search(t)
    ev_val = ev.group(1).upper() if ev else None
    rs_val = normalize_retrieval_status(rs.group(1)) if rs else None
    return ev_val, rs_val


def extract_sources(text: str) -> List[SourceEvidence]:
    out: List[SourceEvidence] = []
    seen = set()
    for publisher, pub_date, url in _SOURCE_RE.findall(str(text or "")):
        key = (publisher.strip().lower(), pub_date.strip(), url.strip())
        if key in seen:
            continue
        seen.add(key)
        out.append(SourceEvidence(
            publisher=publisher.strip(),
            publication_date=pub_date.strip(),
            url=url.strip(),
            approved=_approved_source(publisher),
        ))
    return out


def extract_metrics(text: str) -> List[str]:
    vals: List[str] = []
    seen = set()
    raw = str(text or "")
    for pattern in (_METRIC_PREFIX_RE, _METRIC_SUFFIX_RE):
        for m in pattern.finditer(raw):
            val = m.group(0).strip()
            key = re.sub(r"\s+", " ", val.lower())
            if key not in seen:
                seen.add(key)
                vals.append(val)
    return vals


def _derive_tier(cleaned: str, score: int, source_count: int) -> str:
    if not cleaned or CANONICAL_NO_DATA.lower() in cleaned.lower():
        return "NONE"
    if source_count == 0:
        return "LIMITED"
    if score >= 70:
        return "SUFFICIENT"
    return "LIMITED"


def _conservative_tier(model_tier: Optional[str], deterministic_tier: str) -> str:
    if not model_tier or model_tier not in {"SUFFICIENT", "LIMITED", "NONE", "NOT_ASSESSED"}:
        return deterministic_tier
    if model_tier == "NOT_ASSESSED":
        return "NOT_ASSESSED"
    rank = {"NONE": 0, "LIMITED": 1, "SUFFICIENT": 2}
    # Never upgrade beyond the more conservative of model and deterministic checks.
    return model_tier if rank[model_tier] <= rank[deterministic_tier] else deterministic_tier


def assess_section(
    section_name: str,
    text: str,
    retrieval_status: Optional[str] = None,
    model_evidence_tier: Optional[str] = None,
    model_retrieval_status: Optional[str] = None,
    unverified_citation_count: int = 0,
) -> SectionAssessment:
    raw = str(text or "")
    tag_tier, tag_status = extract_model_tags(raw)
    model_tier = str(model_evidence_tier or tag_tier or "").upper() or None
    model_status = normalize_retrieval_status(model_retrieval_status or tag_status) if (model_retrieval_status or tag_status) else None
    status = normalize_retrieval_status(retrieval_status or model_status)
    cleaned = strip_control_tags(raw)

    if status == "TECHNICAL_FAILURE":
        return SectionAssessment(
            section_name=section_name,
            evidence_tier="NOT_ASSESSED",
            retrieval_status=status,
            deterministic_score=0,
            char_count=len(cleaned),
            source_count=0,
            approved_source_count=0,
            source_names=[],
            source_dates=[],
            latest_source_date=None,
            metric_count=0,
            has_date=False,
            has_financial_terms=False,
            conflict_detected=False,
            unverified_citation_count=int(unverified_citation_count or 0),
            limitations=["Retrieval did not complete; evidence sufficiency was not assessed."],
            model_evidence_tier=model_tier,
            model_retrieval_status=model_status,
        )

    sources = extract_sources(raw)
    metrics = extract_metrics(cleaned)
    approved = [s for s in sources if s.approved]
    source_dates = sorted({s.publication_date for s in sources if s.publication_date})
    latest_source_date = max(source_dates) if source_dates else None
    has_date = bool(_DATE_RE.search(cleaned)) or any(bool(s.publication_date) for s in sources)
    has_fin = bool(_FINANCE_TERM_RE.search(cleaned))
    conflict = bool(_CONFLICT_RE.search(cleaned))

    if not cleaned or CANONICAL_NO_DATA.lower() in cleaned.lower():
        score = 0
    else:
        score = 0
        score += min(30, len(sources) * 10)
        score += min(20, len(approved) * 10)
        score += min(25, len(metrics) * 6)
        score += 10 if has_date else 0
        score += 8 if len(cleaned) >= 120 else (4 if len(cleaned) >= 60 else 0)
        score += 7 if has_fin else 0
        if conflict:
            score -= 8
        score = max(0, min(100, score))

    deterministic_tier = _derive_tier(cleaned, score, len(sources))
    tag_conflict = False
    if model_tier == "NONE" and sources:
        # A NONE tag is semantically incompatible with sourced report content.
        tier = deterministic_tier
        tag_conflict = True
    elif model_tier == "NOT_ASSESSED" and status == "SUCCESS":
        tier = deterministic_tier
        tag_conflict = True
    else:
        tier = _conservative_tier(model_tier, deterministic_tier)
    if status == "PARTIAL_TECHNICAL_FAILURE" and tier == "SUFFICIENT":
        # Keep the content usable, but remain conservative when retrieval was incomplete.
        tier = "LIMITED"

    limitations: List[str] = []
    if cleaned and CANONICAL_NO_DATA.lower() not in cleaned.lower():
        if not sources:
            limitations.append("No inline source citation was detected.")
        if not approved and sources:
            limitations.append("No approved-source publisher was detected in inline citations.")
        if not metrics and section_name in {"Equity Market Impact", "Credit Market Impact", "Commodity Market Impact"}:
            limitations.append("No quantitative market observation was detected.")
        if not has_date:
            limitations.append("No explicit observation/publication date was detected.")
        if conflict:
            limitations.append("Potential source/value discrepancy detected; analyst review may be required.")
    if tag_conflict:
        limitations.append("Model evidence tag conflicted with the retrieved content; deterministic evidence checks were used.")
    if status == "PARTIAL_TECHNICAL_FAILURE":
        limitations.append("Some retrieval attempts failed; evidence reflects only successfully retrieved sources.")
    if int(unverified_citation_count or 0) > 0:
        limitations.append(
            f"{int(unverified_citation_count)} synthesis citation(s) were removed because their URLs were not present in the retrieved evidence dossier."
        )

    return SectionAssessment(
        section_name=section_name,
        evidence_tier=tier,
        retrieval_status=status,
        deterministic_score=score,
        char_count=len(cleaned),
        source_count=len(sources),
        approved_source_count=len(approved),
        source_names=sorted({s.publisher for s in sources}),
        source_dates=source_dates,
        latest_source_date=latest_source_date,
        metric_count=len(metrics),
        has_date=has_date,
        has_financial_terms=has_fin,
        conflict_detected=conflict,
        unverified_citation_count=int(unverified_citation_count or 0),
        limitations=limitations,
        model_evidence_tier=model_tier,
        model_retrieval_status=model_status,
    )


def assess_sections(
    sections: Sequence[Dict[str, Any]],
    default_retrieval_status: str = "SUCCESS",
) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for i, title in enumerate(SECTION_TITLES):
        src = sections[i] if i < len(sections) else {}
        text = str(src.get("txt", src.get("text", "")) or "")
        status = src.get("retrieval_status") or default_retrieval_status
        out.append(assess_section(
            title,
            text,
            status,
            model_evidence_tier=src.get("model_evidence_tier"),
            model_retrieval_status=src.get("model_retrieval_status"),
            unverified_citation_count=int(src.get("unverified_citation_count") or 0),
        ).to_dict())
    return out


def overall_retrieval_status(section_meta: Sequence[Dict[str, Any]]) -> str:
    statuses = [normalize_retrieval_status(str(m.get("retrieval_status") or "SUCCESS")) for m in (section_meta or [])]
    if not statuses or all(s == "SUCCESS" for s in statuses):
        return "SUCCESS"
    if statuses and all(s == "TECHNICAL_FAILURE" for s in statuses):
        return "TECHNICAL_FAILURE"
    return "PARTIAL_TECHNICAL_FAILURE"


def summarize_quality(section_meta: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    metas = list(section_meta or [])
    counts = {"SUFFICIENT": 0, "LIMITED": 0, "NONE": 0, "NOT_ASSESSED": 0}
    scores: List[int] = []
    technical = 0
    for m in metas:
        tier = str(m.get("evidence_tier", "NONE")).upper()
        counts[tier] = counts.get(tier, 0) + 1
        scores.append(int(m.get("deterministic_score") or 0))
        if str(m.get("retrieval_status", "SUCCESS")).upper() != "SUCCESS":
            technical += 1
    avg = round(sum(scores) / len(scores)) if scores else 0

    critical = {"Event Overview", "Event History", "Credit Market Impact"}
    critical_missing = [
        str(m.get("section_name")) for m in metas
        if str(m.get("section_name")) in critical
        and str(m.get("evidence_tier", "")).upper() in {"NONE", "NOT_ASSESSED"}
    ]
    critical_technical = [
        str(m.get("section_name")) for m in metas
        if str(m.get("section_name")) in critical
        and str(m.get("retrieval_status", "")).upper() == "TECHNICAL_FAILURE"
    ]
    if critical_technical:
        readiness = "NOT_READY_TECHNICAL"
    elif technical or critical_missing:
        readiness = "READY_WITH_LIMITATIONS"
    elif counts.get("LIMITED", 0) or counts.get("NONE", 0):
        readiness = "READY_WITH_LIMITATIONS"
    else:
        readiness = "READY"

    return {
        "average_score": avg,
        "counts": counts,
        "technical_sections": technical,
        "overall_retrieval_status": overall_retrieval_status(metas),
        "critical_missing": critical_missing,
        "critical_technical": critical_technical,
        "readiness": readiness,
    }


def _sentence_chunks(text: str) -> List[str]:
    cleaned = strip_control_tags(text)
    # Split conservatively so URLs are less likely to be destroyed.
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", cleaned) if s.strip()]


def build_evidence_ledger(sections: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    ledger: List[Dict[str, Any]] = []
    for i, title in enumerate(SECTION_TITLES):
        src = sections[i] if i < len(sections) else {}
        text = str(src.get("txt", src.get("text", "")) or "")
        for sentence in _sentence_chunks(text):
            sources = extract_sources(sentence)
            if not sources:
                continue
            metrics = extract_metrics(sentence)
            statement_type = "OBSERVED_OR_REPORTED"
            low = sentence.lower()
            if title == "Assumptions":
                if "scenario" in low:
                    statement_type = "SCENARIO"
                elif "forecast" in low or "projection" in low or "projected" in low:
                    statement_type = "FORECAST"
                elif "policy path" in low or "would" in low or "expects" in low:
                    statement_type = "POLICY_PATH"
                else:
                    statement_type = "ASSUMPTION_OR_OUTLOOK"
            for source in sources:
                ledger.append({
                    "section": title,
                    "claim": sentence,
                    "statement_type": statement_type,
                    "metrics": metrics,
                    "source": source.publisher,
                    "source_date": source.publication_date,
                    "source_url": source.url,
                    "approved_source": source.approved,
                })
    return ledger


def build_machine_payload(
    *,
    trigger: str,
    sections: Sequence[Dict[str, Any]],
    event: Optional[Dict[str, Any]] = None,
    query_log: Optional[Sequence[str]] = None,
    query_log_source: str = "model_reported_or_search_instruction",
    model_metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    section_meta = assess_sections(sections)
    mm = model_metadata if isinstance(model_metadata, dict) else {}

    def _unique_strings(value: Any, limit: int = 100) -> List[str]:
        out: List[str] = []
        seen = set()
        for item in value if isinstance(value, list) else []:
            s = str(item or "").strip()
            key = s.lower()
            if s and key not in seen:
                seen.add(key)
                out.append(s)
            if len(out) >= limit:
                break
        return out

    observations: List[Dict[str, Any]] = []
    for item in mm.get("key_market_observations", []) if isinstance(mm.get("key_market_observations"), list) else []:
        if not isinstance(item, dict):
            continue
        clean = {
            "asset_class": str(item.get("asset_class") or "").strip(),
            "instrument": str(item.get("instrument") or "").strip(),
            "value": str(item.get("value") or "").strip(),
            "unit": str(item.get("unit") or "").strip(),
            "direction": str(item.get("direction") or "").strip(),
            "observation_date": str(item.get("observation_date") or "").strip(),
            "source": str(item.get("source") or "").strip(),
        }
        if any(clean.values()):
            observations.append(clean)
        if len(observations) >= 100:
            break

    payload = {
        "schema_version": "step1.v2",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "trigger": trigger,
        "event": event or {},
        "sections": [
            {
                "num": i + 1,
                "title": SECTION_TITLES[i],
                "text": strip_control_tags(str((sections[i] if i < len(sections) else {}).get("txt", (sections[i] if i < len(sections) else {}).get("text", "")) or "")),
            }
            for i in range(len(SECTION_TITLES))
        ],
        "section_meta": section_meta,
        "quality": summarize_quality(section_meta),
        "evidence_ledger": build_evidence_ledger(sections),
        "search_queries": list(query_log or []),
        "query_log_source": query_log_source,
        "structured_context": {
            "entities": _unique_strings(mm.get("entities")),
            "geographies": _unique_strings(mm.get("geographies")),
            "transmission_channels": _unique_strings(mm.get("transmission_channels")),
            "key_market_observations": observations,
            "limitations": _unique_strings(mm.get("limitations")),
        },
    }
    if mm:
        # Keep model-suggested structure separate from deterministic evidence metadata.
        payload["model_metadata"] = mm
    return payload


def compare_quality(
    before_meta: Sequence[Dict[str, Any]],
    after_meta: Sequence[Dict[str, Any]],
    affected_sections: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    affected = set(affected_sections or SECTION_TITLES)
    bmap = {str(m.get("section_name")): m for m in before_meta}
    amap = {str(m.get("section_name")): m for m in after_meta}
    rows: List[Dict[str, Any]] = []
    rank = {"NOT_ASSESSED": -1, "NONE": 0, "LIMITED": 1, "SUFFICIENT": 2}
    any_improved = False
    all_sufficient = True
    for title in SECTION_TITLES:
        if title not in affected:
            continue
        b = bmap.get(title, {})
        a = amap.get(title, {})
        bt = str(b.get("evidence_tier", "NONE")).upper()
        at = str(a.get("evidence_tier", "NONE")).upper()
        bs = int(b.get("deterministic_score") or 0)
        ass = int(a.get("deterministic_score") or 0)
        before_rank = rank.get(bt, 0)
        after_rank = rank.get(at, 0)
        after_status = str(a.get("retrieval_status", "SUCCESS")).upper()
        improved = (
            after_status == "SUCCESS"
            and (
                after_rank > before_rank
                or (after_rank == before_rank and ass >= bs + 10)
            )
        )
        any_improved = any_improved or improved
        all_sufficient = all_sufficient and at == "SUFFICIENT"
        rows.append({
            "section": title,
            "before_tier": bt,
            "after_tier": at,
            "before_score": bs,
            "after_score": ass,
            "score_delta": ass - bs,
            "before_sources": int(b.get("source_count") or 0),
            "after_sources": int(a.get("source_count") or 0),
            "before_metrics": int(b.get("metric_count") or 0),
            "after_metrics": int(a.get("metric_count") or 0),
            "improved": improved,
        })
    if rows and all_sufficient and any_improved:
        outcome = "RESOLVED"
    elif any_improved:
        outcome = "IMPROVED"
    else:
        outcome = "NO_IMPROVEMENT"
    return {"outcome": outcome, "affected_sections": [r["section"] for r in rows], "sections": rows}


def select_improved_sections(
    original_sections: Sequence[Dict[str, Any]],
    candidate_sections: Sequence[Dict[str, Any]],
    affected_sections: Sequence[str],
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Accept targeted replacements section-by-section only when evidence quality improves.

    This prevents one improved section from causing a different affected section to be overwritten
    by a weaker rescan result.
    """
    affected = [s for s in affected_sections if s in SECTION_TITLES]
    merged = merge_targeted_sections(original_sections, candidate_sections, affected)
    before_meta = assess_sections(original_sections)
    after_meta = assess_sections(merged)
    comparison = compare_quality(before_meta, after_meta, affected)
    improved_map = {row["section"]: bool(row.get("improved")) for row in comparison.get("sections", [])}

    final_sections: List[Dict[str, Any]] = []
    for i, title in enumerate(SECTION_TITLES):
        original = dict(original_sections[i]) if i < len(original_sections) else {"num": i + 1, "title": title, "txt": ""}
        original.setdefault("num", i + 1)
        original["title"] = title
        if title in affected and improved_map.get(title):
            replacement = dict(merged[i]) if i < len(merged) else original
            final_sections.append(replacement)
        else:
            final_sections.append(original)

    final_meta = assess_sections(final_sections)
    comparison["original_retained"] = not any(improved_map.values())
    comparison["accepted_sections"] = [title for title, accepted in improved_map.items() if accepted]
    comparison["retained_sections"] = [title for title in affected if not improved_map.get(title, False)]
    comparison["final_quality"] = summarize_quality(final_meta)
    return final_sections, comparison


def merge_targeted_sections(
    original_sections: Sequence[Dict[str, Any]],
    candidate_sections: Sequence[Dict[str, Any]],
    affected_sections: Sequence[str],
) -> List[Dict[str, Any]]:
    affected = set(affected_sections or SECTION_TITLES)
    cmap = {
        str(s.get("title") or SECTION_TITLES[i] if i < len(SECTION_TITLES) else ""): s
        for i, s in enumerate(candidate_sections or [])
    }
    out: List[Dict[str, Any]] = []
    for i, title in enumerate(SECTION_TITLES):
        orig = dict(original_sections[i]) if i < len(original_sections) else {"num": i + 1, "title": title, "txt": ""}
        orig.setdefault("num", i + 1)
        orig["title"] = title
        if title in affected:
            cand = cmap.get(title)
            if cand is None and i < len(candidate_sections):
                cand = candidate_sections[i]
            if cand is not None:
                new = dict(orig)
                new["txt"] = str(cand.get("txt", cand.get("text", "")) or "")
                if cand.get("retrieval_status"):
                    new["retrieval_status"] = cand.get("retrieval_status")
                if cand.get("model_evidence_tier"):
                    new["model_evidence_tier"] = cand.get("model_evidence_tier")
                if cand.get("model_retrieval_status"):
                    new["model_retrieval_status"] = cand.get("model_retrieval_status")
                if cand.get("unverified_citation_count") is not None:
                    new["unverified_citation_count"] = int(cand.get("unverified_citation_count") or 0)
                out.append(new)
                continue
        out.append(orig)
    return out


def parse_sectioned_report(text: str) -> Dict[str, Any]:
    """Parse the stable 8-section text contract plus optional metadata footer."""
    raw = str(text or "")
    sections: List[Dict[str, Any]] = []
    positions: List[Tuple[int, int, str]] = []
    for title in SECTION_TITLES:
        m = re.search(rf"(?im)^\s*{re.escape(title)}\s*:\s*", raw)
        if m:
            positions.append((m.start(), m.end(), title))
    positions.sort(key=lambda x: x[0])

    for idx, (start, content_start, title) in enumerate(positions):
        end = positions[idx + 1][0] if idx + 1 < len(positions) else len(raw)
        chunk = raw[content_start:end]
        # Stop at known footer blocks if this is the final section.
        chunk = re.split(r"(?im)^\s*(?:Search Queries Used|Machine Metadata|\[MACHINE_METADATA\])\s*:?\s*$", chunk, maxsplit=1)[0]
        model_tier, model_status = extract_model_tags(chunk)
        cleaned = strip_control_tags(chunk).strip()
        sections.append({
            "num": SECTION_TITLES.index(title) + 1,
            "title": title,
            "txt": cleaned,
            "model_evidence_tier": model_tier,
            "retrieval_status": model_status or "SUCCESS",
        })

    # Ensure all eight exist in exact order.
    smap = {s["title"]: s for s in sections}
    sections = [smap.get(t, {"num": i + 1, "title": t, "txt": "", "retrieval_status": "SUCCESS"}) for i, t in enumerate(SECTION_TITLES)]

    qmatch = re.search(r"(?is)Search Queries Used\s*:\s*(.*?)(?:\n\s*\[MACHINE_METADATA\]|\n\s*Machine Metadata\s*:|\Z)", raw)
    queries: List[str] = []
    if qmatch:
        for line in qmatch.group(1).splitlines():
            q = re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", line).strip()
            if q and not q.startswith("["):
                queries.append(q)

    metadata: Dict[str, Any] = {}
    mm = re.search(r"(?is)\[MACHINE_METADATA\]\s*(.*?)\s*\[/MACHINE_METADATA\]", raw)
    if not mm:
        mm = re.search(r"(?is)Machine Metadata\s*:\s*(\{.*\})\s*$", raw)
    if mm:
        try:
            metadata = json.loads(mm.group(1).strip())
        except Exception:
            metadata = {}

    return {"sections": sections, "search_queries": queries, "machine_metadata": metadata}
