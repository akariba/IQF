"""Shared Step-1 evidence enhancement routes for Trigger 1 and Trigger 2."""
from __future__ import annotations

import json
import re
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from narrative_enricher import NarrativeEnrichError, enrich_narrative

PROMPT_DIR = Path(__file__).resolve().parent / "prompts"
_MAX_RESCANS = 2
_state_lock = threading.Lock()
_scope_state: Dict[str, Dict[str, Any]] = {}

enhancement_router = APIRouter()


def _load_prompt(name: str, fallback: str) -> str:
    path = PROMPT_DIR / name
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return fallback


def _scope_key(scope_type: str, theme: str = "", event_id: Optional[int] = None, narrative_preview: str = "") -> str:
    st = (scope_type or "").strip().lower()
    if st == "trigger1":
        return f"t1:{(theme or '').strip().lower()}:{int(event_id or 0)}"
    return f"t2:{(narrative_preview or '')[:40].strip().lower()}"


def _get_state(key: str) -> Dict[str, Any]:
    with _state_lock:
        return _scope_state.setdefault(key, {"rescan_count": 0, "attempted_feedback": [], "outcomes": []})


def get_attempt_count(scope_type: str, theme: str = "", event_id: Optional[int] = None, narrative_preview: str = "") -> int:
    return int(_get_state(_scope_key(scope_type, theme, event_id, narrative_preview)).get("rescan_count") or 0)


def can_rescan(scope_type: str, theme: str = "", event_id: Optional[int] = None, narrative_preview: str = "") -> bool:
    return get_attempt_count(scope_type, theme, event_id, narrative_preview) < _MAX_RESCANS


def register_rescan_result(
    *,
    scope_type: str,
    theme: str = "",
    event_id: Optional[int] = None,
    narrative_preview: str = "",
    feedback: str,
    outcome: str,
) -> int:
    key = _scope_key(scope_type, theme, event_id, narrative_preview)
    with _state_lock:
        st = _scope_state.setdefault(key, {"rescan_count": 0, "attempted_feedback": [], "outcomes": []})
        st["rescan_count"] = int(st.get("rescan_count") or 0) + 1
        norm = " ".join(str(feedback or "").lower().split())
        if norm and norm not in st["attempted_feedback"]:
            st["attempted_feedback"].append(norm)
        st["outcomes"].append(str(outcome or ""))
        return st["rescan_count"]


def _strip_fences(text: str) -> str:
    t = str(text or "").strip()
    t = re.sub(r"^```(?:json)?\s*", "", t, flags=re.I)
    t = re.sub(r"\s*```$", "", t)
    return t.strip()


def _call_llm_text(system_prompt: str, user_prompt: str, max_tokens: int = 1200) -> str:
    try:
        from llm_gateway import get_gateway  # type: ignore
        gateway = get_gateway()
        if hasattr(gateway, "call_text"):
            return str(gateway.call_text(system_prompt=system_prompt, user_prompt=user_prompt, max_tokens=max_tokens))
    except Exception:
        pass
    return ""


def _technical_status(value: str) -> bool:
    return str(value or "").upper() in {"PARTIAL_TECHNICAL_FAILURE", "TECHNICAL_FAILURE", "FAILED"}


def _compact_evidence_summary(meta: List[Dict[str, Any]], affected: List[str]) -> str:
    rows = []
    amap = set(affected)
    for m in meta:
        if amap and str(m.get("section_name")) not in amap:
            continue
        rows.append(
            f"{m.get('section_name')}: {m.get('evidence_tier')} / {m.get('retrieval_status')} · "
            f"sources {m.get('source_count', 0)} · approved {m.get('approved_source_count', 0)} · "
            f"metrics {m.get('metric_count', 0)} · score {m.get('deterministic_score', 0)}"
        )
    return " | ".join(rows)


class DiagnoseRequest(BaseModel):
    scope_type: str
    theme: str = ""
    event_id: Optional[int] = None
    narrative_preview: str = ""
    executed_query: str = ""
    query_log: List[str] = Field(default_factory=list)
    query_log_source: str = ""
    section_meta: List[Dict[str, Any]] = Field(default_factory=list)
    attempt_count: Optional[int] = None  # compatibility only; backend state is authoritative


class DiagnoseResponse(BaseModel):
    decision: str
    cause_code: Optional[str] = None
    affected_sections: List[str] = Field(default_factory=list)
    diagnosis: Optional[str] = None
    suggested_feedback: Optional[str] = None
    evidence_summary: str = ""
    attempt_count: int = 0


class ConsolidateRequest(BaseModel):
    scope_type: str
    theme: str = ""
    event_id: Optional[int] = None
    narrative_preview: str = ""
    user_approved_feedback: str
    affected_sections: List[str] = Field(default_factory=list)
    original_diagnosis: str = ""


class ConsolidateResponse(BaseModel):
    copyable_feedback: str


class ReEnrichRequest(BaseModel):
    narrative: str
    refinement_guidance: str
    affected_sections: List[str] = Field(default_factory=list)
    base_sections: List[Dict[str, Any]] = Field(default_factory=list)
    analyst_modified_sections: List[str] = Field(default_factory=list)


@enhancement_router.post("/api/v1/rpr/enhance/diagnose", response_model=DiagnoseResponse)
def diagnose(req: DiagnoseRequest) -> DiagnoseResponse:
    key = _scope_key(req.scope_type, req.theme, req.event_id, req.narrative_preview)
    st = _get_state(key)
    attempts = int(st.get("rescan_count") or 0)

    if attempts >= _MAX_RESCANS:
        return DiagnoseResponse(
            decision="NOT_RECOMMENDED",
            diagnosis=None,
            suggested_feedback=None,
            affected_sections=[],
            evidence_summary="Maximum enhancement-assisted rescan count reached.",
            attempt_count=attempts,
        )

    query_log = [str(q).strip() for q in req.query_log if str(q).strip()]
    if not query_log and str(req.executed_query or "").strip():
        query_log = [str(req.executed_query).strip()]
    if not query_log:
        return DiagnoseResponse(
            decision="INSUFFICIENT_INPUT",
            diagnosis="Search/query telemetry was not supplied.",
            suggested_feedback=None,
            affected_sections=[],
            evidence_summary="",
            attempt_count=attempts,
        )

    eligible: List[Dict[str, Any]] = []
    technical: List[Dict[str, Any]] = []
    for m in req.section_meta or []:
        tier = str(m.get("evidence_tier") or "").upper()
        status = str(m.get("retrieval_status") or "SUCCESS").upper()
        if _technical_status(status) or tier == "NOT_ASSESSED":
            technical.append(m)
            continue
        if tier in {"LIMITED", "NONE"} and status in {"SUCCESS", "COMPLETED"}:
            eligible.append(m)

    if not eligible:
        if technical:
            return DiagnoseResponse(
                decision="NOT_APPLICABLE",
                diagnosis="The relevant weak sections reflect a retrieval problem, not a completed-search evidence gap.",
                suggested_feedback=None,
                affected_sections=[str(m.get("section_name")) for m in technical if m.get("section_name")],
                evidence_summary=_compact_evidence_summary(technical, []),
                attempt_count=attempts,
            )
        return DiagnoseResponse(
            decision="NOT_RECOMMENDED",
            diagnosis=None,
            suggested_feedback=None,
            affected_sections=[],
            evidence_summary="No eligible LIMITED/NONE section was found.",
            attempt_count=attempts,
        )

    # LLM gets compact evidence/search telemetry, not the whole report.
    payload = {
        "trigger_type": req.scope_type,
        "scope": {
            "theme": req.theme or None,
            "event_id": req.event_id,
            "narrative_preview": req.narrative_preview or None,
        },
        "backend_rescan_count": attempts,
        "query_log": query_log,
        "query_log_source": req.query_log_source or "unspecified",
        "previously_attempted_feedback": st.get("attempted_feedback") or [],
        "eligible_sections": eligible,
        "technical_sections": technical,
    }
    system = _load_prompt(
        "enhancement_diagnosis.txt",
        "Default NOT_RECOMMENDED. Return JSON decision/cause_code/affected_sections/diagnosis/suggested_feedback.",
    )
    raw = _call_llm_text(system, json.dumps(payload, ensure_ascii=False), max_tokens=1200)
    obj: Dict[str, Any] = {}
    if raw:
        try:
            obj = json.loads(_strip_fences(raw))
        except Exception:
            obj = {}

    allowed_decisions = {"RECOMMENDED", "NOT_RECOMMENDED", "NOT_APPLICABLE", "INSUFFICIENT_INPUT"}
    allowed_causes = {
        "AMBIGUOUS_ENTITY", "MISSING_ALIAS", "QUERY_TOO_BROAD", "QUERY_TOO_NARROW",
        "MISSING_SEARCH_DIMENSION", "MISSING_GEOGRAPHY", "MISSING_INSTRUMENT",
        "MISSING_SOURCE_CATEGORY", "RECENCY_WINDOW_EDGE_CASE",
    }
    decision = str(obj.get("decision") or "NOT_RECOMMENDED").upper()
    if decision not in allowed_decisions:
        decision = "NOT_RECOMMENDED"

    affected = [str(x) for x in (obj.get("affected_sections") or []) if str(x) in {str(m.get("section_name")) for m in eligible}]
    cause = str(obj.get("cause_code") or "").upper() or None
    diagnosis_text = str(obj.get("diagnosis") or "").strip() or None
    suggestion = str(obj.get("suggested_feedback") or "").strip() or None

    if decision == "RECOMMENDED":
        if cause not in allowed_causes or not affected or not diagnosis_text or not suggestion:
            decision = "NOT_RECOMMENDED"
            cause = None
            diagnosis_text = None
            suggestion = None
        else:
            norm = " ".join(suggestion.lower().split())
            if norm in (st.get("attempted_feedback") or []):
                decision = "NOT_RECOMMENDED"
                cause = None
                diagnosis_text = None
                suggestion = None
    else:
        cause = None
        suggestion = None

    summary = _compact_evidence_summary(req.section_meta, affected or [str(m.get("section_name")) for m in eligible])
    return DiagnoseResponse(
        decision=decision,
        cause_code=cause,
        affected_sections=affected,
        diagnosis=diagnosis_text,
        suggested_feedback=suggestion,
        evidence_summary=summary,
        attempt_count=attempts,
    )


@enhancement_router.post("/api/v1/rpr/enhance/consolidate", response_model=ConsolidateResponse)
def consolidate(req: ConsolidateRequest) -> ConsolidateResponse:
    user_text = str(req.user_approved_feedback or "").strip()
    if not user_text:
        raise HTTPException(status_code=400, detail="Approved feedback is required")

    payload = {
        "scope_type": req.scope_type,
        "theme": req.theme or None,
        "event_id": req.event_id,
        "narrative_preview": req.narrative_preview or None,
        "affected_sections": req.affected_sections,
        "original_diagnosis": req.original_diagnosis or None,
        "analyst_approved_text": user_text,
    }
    system = _load_prompt(
        "feedback_consolidation.txt",
        "Preserve user intent exactly. Return only concise approved search refinement guidance.",
    )
    raw = _call_llm_text(system, json.dumps(payload, ensure_ascii=False), max_tokens=800).strip()
    if not raw:
        if req.scope_type.lower() == "trigger1":
            raw = (
                f"Theme: {req.theme}\n"
                f"Event: {req.event_id if req.event_id is not None else ''}\n"
                f"Affected Sections: {', '.join(req.affected_sections)}\n"
                f"Requested Search Enhancement: {user_text}"
            )
        else:
            raw = (
                f"Narrative Scope: {req.narrative_preview}\n"
                f"Affected Sections: {', '.join(req.affected_sections)}\n"
                f"Requested Search Enhancement: {user_text}"
            )
    return ConsolidateResponse(copyable_feedback=raw)


@enhancement_router.post("/api/v1/rpr/step1/re-enrich")
def re_enrich(req: ReEnrichRequest) -> Dict[str, Any]:
    narrative = str(req.narrative or "").strip()
    guidance = str(req.refinement_guidance or "").strip()
    if not narrative or not guidance:
        raise HTTPException(status_code=400, detail="Narrative and refinement guidance are required")
    preview = narrative[:120]
    if not can_rescan("trigger2", narrative_preview=preview):
        raise HTTPException(status_code=409, detail="Maximum enhancement-assisted rescan count reached for this narrative")
    try:
        data = enrich_narrative(
            narrative=narrative,
            refinement_guidance=guidance,
            affected_sections=req.affected_sections,
            base_sections=req.base_sections,
            analyst_modified_sections=req.analyst_modified_sections,
        )
    except NarrativeEnrichError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    outcome = str((data.get("rescan_result") or {}).get("outcome") or "COMPLETED")
    count = register_rescan_result(
        scope_type="trigger2",
        narrative_preview=preview,
        feedback=guidance,
        outcome=outcome,
    )
    data.setdefault("rescan_result", {})["attempt_count"] = count
    return data
