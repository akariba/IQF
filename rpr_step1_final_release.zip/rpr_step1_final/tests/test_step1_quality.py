import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "backend"))

from step1_quality import (  # noqa: E402
    SECTION_TITLES,
    assess_section,
    assess_sections,
    compare_quality,
    extract_metrics,
    merge_targeted_sections,
    parse_sectioned_report,
    select_improved_sections,
    summarize_quality,
)


def _no_data_sections():
    return [
        {
            "num": i + 1,
            "title": title,
            "txt": "No significant data identified in the sources reviewed for the defined three-month window.",
        }
        for i, title in enumerate(SECTION_TITLES)
    ]


def test_no_data_is_none():
    a = assess_section(
        "Commodity Market Impact",
        "No significant data identified in the sources reviewed for the defined three-month window.\n"
        "[EVIDENCE_TIER: NONE]\n[RETRIEVAL_STATUS: SUCCESS]",
    )
    assert a.evidence_tier == "NONE"
    assert a.retrieval_status == "SUCCESS"


def test_technical_failure_not_none():
    a = assess_section(
        "Credit Market Impact",
        "[EVIDENCE_TIER: NOT_ASSESSED]\n[RETRIEVAL_STATUS: TECHNICAL_FAILURE]",
    )
    assert a.evidence_tier == "NOT_ASSESSED"
    assert a.retrieval_status == "TECHNICAL_FAILURE"




def test_none_tag_with_sourced_content_is_not_treated_as_true_none():
    a = assess_section(
        "Credit Market Impact",
        "Five-year CDS widened 45 bps on 2026-08-10. (Source: [Reuters, 2026-08-10](https://www.reuters.com/example))\n"
        "[EVIDENCE_TIER: NONE]\n[RETRIEVAL_STATUS: SUCCESS]",
    )
    assert a.evidence_tier in {"LIMITED", "SUFFICIENT"}
    assert any("conflicted" in x.lower() for x in a.limitations)


def test_metric_extraction_handles_prefix_and_suffix_currency():
    text = "AT1 write-down was CHF 16 billion, shares fell 12.5%, and CDS widened 45 bps."
    metrics = extract_metrics(text)
    assert any("CHF 16 billion" in x for x in metrics)
    assert any("12.5%" in x for x in metrics)
    assert any("45 bps" in x.lower() for x in metrics)


def test_targeted_merge_preserves_unaffected():
    before = [{"num": i + 1, "title": t, "txt": f"old-{i}"} for i, t in enumerate(SECTION_TITLES)]
    after = [{"num": i + 1, "title": t, "txt": f"new-{i}"} for i, t in enumerate(SECTION_TITLES)]
    merged = merge_targeted_sections(before, after, ["Credit Market Impact"])
    assert merged[5]["txt"] == "new-5"
    assert merged[4]["txt"] == "old-4"
    assert merged[6]["txt"] == "old-6"


def test_comparison_does_not_call_tier_downgrade_an_improvement():
    before = _no_data_sections()
    before[5] = {
        "num": 6,
        "title": "Credit Market Impact",
        "txt": (
            "Five-year CDS widened 45 bps on 2026-08-10 and bonds fell 3%. "
            "(Source: [Reuters, 2026-08-10](https://www.reuters.com/example)) "
            "(Source: [Bloomberg, 2026-08-10](https://www.bloomberg.com/example))"
        ),
    }
    after = list(before)
    after[5] = {
        "num": 6,
        "title": "Credit Market Impact",
        "txt": (
            "A long but weakly sourced paragraph mentioning credit, funding, liquidity, bond spreads and ratings "
            "without any source citation. " * 5
        ),
    }
    b = assess_sections(before)
    a = assess_sections(after)
    comp = compare_quality(b, a, ["Credit Market Impact"])
    assert comp["sections"][0]["after_tier"] != "SUFFICIENT"
    assert comp["sections"][0]["improved"] is False


def test_select_improved_sections_accepts_only_sections_that_improve():
    before = _no_data_sections()
    before[4] = {
        "num": 5,
        "title": "Equity Market Impact",
        "txt": "Shares fell 8% on 2026-08-10. (Source: [Reuters, 2026-08-10](https://www.reuters.com/equity))",
    }
    candidate = _no_data_sections()
    candidate[4] = {
        "num": 5,
        "title": "Equity Market Impact",
        "txt": "Shares moved materially but no sourced number was identified.",
    }
    candidate[5] = {
        "num": 6,
        "title": "Credit Market Impact",
        "txt": (
            "Five-year CDS widened 45 bps on 2026-08-10. "
            "(Source: [Reuters, 2026-08-10](https://www.reuters.com/credit))"
        ),
    }
    final_sections, comp = select_improved_sections(
        before,
        candidate,
        ["Equity Market Impact", "Credit Market Impact"],
    )
    assert final_sections[4]["txt"] == before[4]["txt"]
    assert final_sections[5]["txt"] == candidate[5]["txt"]
    assert comp["accepted_sections"] == ["Credit Market Impact"]
    assert "Equity Market Impact" in comp["retained_sections"]


def test_machine_metadata_parser_handles_nested_json():
    report = "\n".join(
        [
            f"{title}: No significant data identified in the sources reviewed for the defined three-month window.\n"
            "[EVIDENCE_TIER: NONE]\n[RETRIEVAL_STATUS: SUCCESS]"
            for title in SECTION_TITLES
        ]
    )
    report += '''\nSearch Queries Used:\n- test query\n[MACHINE_METADATA]\n{
      "entities": ["ABC Corp"],
      "key_market_observations": [{"asset_class": "credit", "instrument": "5Y CDS", "value": "45", "unit": "bps"}]
    }\n[/MACHINE_METADATA]'''
    parsed = parse_sectioned_report(report)
    assert parsed["machine_metadata"]["entities"] == ["ABC Corp"]
    assert parsed["machine_metadata"]["key_market_observations"][0]["instrument"] == "5Y CDS"


def test_explicit_limited_tag_is_preserved_after_parser_control_tags_removed():
    report = "\n".join(
        [
            (
                f"{title}: A supported 10% observation on 2026-08-10. "
                f"(Source: [Reuters, 2026-08-10](https://www.reuters.com/{i}))\n"
                f"[EVIDENCE_TIER: {'LIMITED' if title == 'Credit Market Impact' else 'SUFFICIENT'}]\n"
                "[RETRIEVAL_STATUS: SUCCESS]"
            )
            for i, title in enumerate(SECTION_TITLES)
        ]
    )
    parsed = parse_sectioned_report(report)
    meta = assess_sections(parsed["sections"])
    credit = next(x for x in meta if x["section_name"] == "Credit Market Impact")
    assert credit["model_evidence_tier"] == "LIMITED"
    assert credit["evidence_tier"] == "LIMITED"


def test_noncritical_technical_failure_is_ready_with_limitations_not_hard_blocked():
    sections = _no_data_sections()
    sections[0]["txt"] = (
        "Event was reported on 2026-08-10. "
        "(Source: [Reuters, 2026-08-10](https://www.reuters.com/event))"
    )
    sections[1]["txt"] = (
        "Event history was reported on 2026-08-09. "
        "(Source: [Reuters, 2026-08-09](https://www.reuters.com/history))"
    )
    sections[5]["txt"] = (
        "Five-year CDS widened 45 bps on 2026-08-10. "
        "(Source: [Reuters, 2026-08-10](https://www.reuters.com/credit))"
    )
    sections[6] = {
        "num": 7,
        "title": "Commodity Market Impact",
        "txt": "",
        "retrieval_status": "TECHNICAL_FAILURE",
    }
    meta = assess_sections(sections)
    assert summarize_quality(meta)["readiness"] == "READY_WITH_LIMITATIONS"
