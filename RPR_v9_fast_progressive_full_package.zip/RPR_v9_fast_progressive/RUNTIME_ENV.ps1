# RPR v9 fast progressive runtime settings.
# This script does not contain, print or persist a token.

# Works both when dot-sourced and when corporate policy requires
# Get-Content .\RUNTIME_ENV.ps1 -Raw | Invoke-Expression from the project root.
$rprRoot = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }

$env:RPR_GEMINI_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_DISCOVERY_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_EVIDENCE_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_THEME_MODEL = "gemini-3.5-flash"
$env:RPR_GEMINI_LOCATION = "us"
$env:RPR_STEP1_REFINEMENT_MODEL = "claude-opus-4-6"
$env:STEP2_SONNET_MODEL = "claude-sonnet-4-6"
$env:STEP2_OPUS_MODEL = "claude-opus-4-6"
$env:RPR_FEEDBACK_MODEL = "claude-sonnet-4-6"
$env:RPR_THEME_GATE_MODEL = "claude-sonnet-4-6"

# v9: one Gemini batch call plus one Opus batch call per theme.
$env:RPR_T1_MAX_EVENTS_PER_THEME = "2"
$env:RPR_T1_THEME_WORKERS = "3"
$env:RPR_T1_OPUS_WORKERS = "2"
$env:RPR_T1_BACKGROUND_WORKERS = "2"
$env:RPR_T1_INITIAL_RESULT_TIMEOUT = "90"
$env:RPR_T1_THEME_GATE_TIMEOUT = "45"
$env:RPR_T1_REFINEMENT_TIMEOUT = "120"
$env:RPR_T1_TARGETED_TIMEOUT = "90"
$env:RPR_T1_OPUS_MAX_TOKENS = "4200"
$env:RPR_T1_GEMINI_MAX_CHARS = "36000"
$env:RPR_T1_CACHE_SECONDS = "900"
$env:RPR_T1_JOB_TTL_SECONDS = "3600"
$env:RPR_HELIX_TOKEN_CACHE_SECONDS = "480"

# Canonical adapter names, bridged from the already-approved RPR environment.
$env:VERTEX_LOCATION = "us"
if ($env:VERTEX_PROJECT_ID -and -not $env:VERTEX_PROJECT) {
    $env:VERTEX_PROJECT = $env:VERTEX_PROJECT_ID
}

$candidateUrls = @(
    $env:RPR_VERTEX_BASE_URL,
    $env:R2D2_BASE_URL,
    $env:VERTEX_ENDPOINT,
    $env:BASE_VERTEX_URL,
    $env:R2D2_UAT_URL
)
$rawVertexUrl = $candidateUrls | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1

# If the current process has no URL variables, read the existing non-secret gateway default.
if (-not $rawVertexUrl) {
    $pythonExe = Join-Path $rprRoot "portfolio-agent\.venv\Scripts\python.exe"
    if (Test-Path $pythonExe) {
        $gatewayUrl = & $pythonExe -c "from llm_gateway import R2D2LLMGateway; print(R2D2LLMGateway._UAT_URL)"
        if ($LASTEXITCODE -eq 0 -and $gatewayUrl) {
            $rawVertexUrl = $gatewayUrl.Trim()
        }
    }
}

if ($rawVertexUrl) {
    # google-genai appends /v1 itself. Remove an existing API-version suffix exactly once.
    $cleanVertexUrl = $rawVertexUrl.Trim().TrimEnd('/') -replace '/v1(?:alpha\d*|beta\d*)?$', ''
    $env:RPR_VERTEX_BASE_URL = $cleanVertexUrl.TrimEnd('/')
    $env:VERTEX_ENDPOINT = $env:RPR_VERTEX_BASE_URL
}

$endpointReady = [bool]$env:RPR_VERTEX_BASE_URL
$projectReady = [bool]($env:VERTEX_PROJECT -or $env:VERTEX_PROJECT_ID -or $env:R2D2_GCP_PROJECT)
Write-Host "RPR v9 runtime loaded. endpointReady=$endpointReady projectReady=$projectReady model=$env:RPR_GEMINI_MODEL"
