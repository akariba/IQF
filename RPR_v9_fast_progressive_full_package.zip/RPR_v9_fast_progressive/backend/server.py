"""Active Step-1 FastAPI backend for the RPR HTML prototype."""
from __future__ import annotations

import copy
import hashlib
import json
import os
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from market_event_scout import MarketEventScout
from narrative_enricher import NarrativeEnrichError, enrich_narrative
from rpr_enhancement_routes import (
    enhancement_router,
    can_rescan,
    register_rescan_result,
)
from theme_assistant import assist_theme
from theme_assistant_batch import assist_themes_batch
from step1_quality import build_machine_payload
from step2_routes import step2_router
from rpr_feedback_routes import feedback_router

app = FastAPI(
    title="ICM PM Rapid Portfolio Review — Backend",
    version="1.7.0",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(enhancement_router)
app.include_router(step2_router)
app.include_router(feedback_router)

_scout = MarketEventScout()
_job_lock = threading.RLock()
_job_executor = ThreadPoolExecutor(
    max_workers=max(1, min(2, int(os.environ.get("RPR_T1_BACKGROUND_WORKERS", "2")))),
    thread_name_prefix="rpr-step1-refine",
)
_jobs: Dict[str, Dict[str, Any]] = {}
_scan_cache: Dict[str, Dict[str, Any]] = {}
_cache_ttl_seconds = max(60, int(os.environ.get("RPR_T1_CACHE_SECONDS", "900")))
_job_ttl_seconds = max(900, int(os.environ.get("RPR_T1_JOB_TTL_SECONDS", "3600")))


class ThemeInput(BaseModel):
    theme: str
    description: str = ""


class FetchRequest(BaseModel):
    # `themes` is retained for backward compatibility with the current HTML/API callers.
    themes: List[str] = Field(default_factory=list)
    theme_inputs: List[ThemeInput] = Field(default_factory=list)
    max_events_per_theme: int = 2
    bypass_cache: bool = False


class RefineRequest(BaseModel):
    event: Dict[str, Any]
    feedback: str
    affected_sections: List[str] = Field(default_factory=list)
    analyst_modified_sections: List[str] = Field(default_factory=list)


class EnrichRequest(BaseModel):
    narrative: str


class ThemeAssistRequest(BaseModel):
    theme: str
    description: str = ""


class ThemeAssistBatchRequest(BaseModel):
    themes: List[ThemeInput] = Field(default_factory=list)


class FinalizeStep1Request(BaseModel):
    trigger: str
    event: Dict[str, Any] = Field(default_factory=dict)
    sections: List[Dict[str, Any]] = Field(default_factory=list)
    base_machine_payload: Dict[str, Any] = Field(default_factory=dict)
    analyst_modified_sections: List[str] = Field(default_factory=list)


def _scan_key(theme_specs: List[Dict[str, str]], max_events: int) -> str:
    payload = {
        "themes": [
            {
                "theme": str(item.get("theme") or "").strip().lower(),
                "description": str(item.get("description") or "").strip().lower(),
            }
            for item in theme_specs
        ],
        "max_events": int(max_events),
        "gemini_model": os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash"),
        "opus_model": os.environ.get("RPR_STEP1_REFINEMENT_MODEL", "claude-opus-4-6"),
        "pipeline": "v9",
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()


def _prune_state() -> None:
    now = time.time()
    with _job_lock:
        for key in [key for key, value in _scan_cache.items() if now - float(value.get("stored_at") or 0) > _cache_ttl_seconds]:
            _scan_cache.pop(key, None)
        for job_id in [job_id for job_id, value in _jobs.items() if now - float(value.get("created_at") or 0) > _job_ttl_seconds]:
            _jobs.pop(job_id, None)


def _job_response(job_id: str) -> Dict[str, Any]:
    with _job_lock:
        job = _jobs.get(job_id)
        if not job:
            raise KeyError(job_id)
        result = copy.deepcopy(job.get("result") or {})
        result.update({
            "job_id": job_id,
            "job_status": job.get("status") or "unknown",
            "refinement_status": result.get("refinement_status") or job.get("status") or "unknown",
            "job_updated_at": job.get("updated_at"),
        })
        if job.get("error"):
            result["job_error"] = job["error"]
        return result


def _run_refinement_job(job_id: str) -> None:
    with _job_lock:
        job = _jobs.get(job_id)
        if not job:
            return
        job["status"] = "refining"
        job["updated_at"] = time.time()
        initial = copy.deepcopy(job.get("result") or {})
        cache_key = str(job.get("cache_key") or "")
    try:
        refined = _scout.refine_initial_result(initial)
        status = str(refined.get("refinement_status") or "complete")
        with _job_lock:
            job = _jobs.get(job_id)
            if not job:
                return
            job["result"] = refined
            job["status"] = status
            job["error"] = ""
            job["updated_at"] = time.time()
            if cache_key:
                _scan_cache[cache_key] = {"stored_at": time.time(), "result": copy.deepcopy(refined)}
    except Exception as exc:  # Gemini initial result remains available even on unexpected failures.
        with _job_lock:
            job = _jobs.get(job_id)
            if not job:
                return
            retained = copy.deepcopy(job.get("result") or {})
            retained["refinement_status"] = "failed"
            retained.setdefault("warnings", []).append(
                f"Background Opus refinement failed; Gemini results were retained: {type(exc).__name__}: {exc}"
            )
            job["result"] = retained
            job["status"] = "failed"
            job["error"] = f"{type(exc).__name__}: {exc}"
            job["updated_at"] = time.time()


@app.get("/health")
def health() -> Dict[str, Any]:
    pf = _scout.preflight()
    return {
        "status": "ok" if pf.get("ok") else "degraded",
        "version": "1.7.0",
        "step1": pf,
        "step1_jobs": {"active": sum(1 for job in _jobs.values() if job.get("status") in {"pending", "refining"})},
    }


@app.post("/api/v1/rpr/themes/assist")
def theme_assist(req: ThemeAssistRequest) -> Dict[str, Any]:
    theme = str(req.theme or "").strip()
    if not theme:
        raise HTTPException(status_code=400, detail="Theme is required")
    return assist_theme(theme=theme, description=req.description)


@app.post("/api/v1/rpr/themes/assist-batch")
def theme_assist_batch(req: ThemeAssistBatchRequest) -> Dict[str, Any]:
    themes = [
        {"theme": str(item.theme or "").strip(), "description": str(item.description or "").strip()}
        for item in req.themes
        if str(item.theme or "").strip()
    ]
    if not themes:
        raise HTTPException(status_code=400, detail="At least one theme is required")
    return assist_themes_batch(themes)


@app.post("/api/v1/rpr/step1/finalize")
def finalize_step1(req: FinalizeStep1Request) -> Dict[str, Any]:
    """Rebuild the machine payload from the analyst-confirmed Step-1 text.

    This prevents downstream steps from consuming stale AI-generated section text after
    the analyst has edited a section. Model-suggested structured metadata is retained only
    when no section was modified; deterministic evidence metadata is always rebuilt.
    """
    trigger = str(req.trigger or "").strip().lower()
    if trigger not in {"trigger1", "trigger2"}:
        raise HTTPException(status_code=400, detail="trigger must be trigger1 or trigger2")
    if not req.sections:
        raise HTTPException(status_code=400, detail="Confirmed Step-1 sections are required")

    modified = []
    seen = set()
    for item in req.analyst_modified_sections:
        name = str(item or "").strip()
        if name and name not in seen:
            seen.add(name)
            modified.append(name)

    base = req.base_machine_payload or {}
    query_log = base.get("search_queries") if isinstance(base.get("search_queries"), list) else []
    query_log_source = str(base.get("query_log_source") or "unknown")
    base_model_metadata = base.get("model_metadata") if isinstance(base.get("model_metadata"), dict) else {}
    payload = build_machine_payload(
        trigger=trigger,
        sections=req.sections,
        event=req.event,
        query_log=query_log,
        query_log_source=query_log_source,
        model_metadata=base_model_metadata if not modified else {},
    )
    payload["analyst_state"] = {
        "confirmed": True,
        "modified_sections": modified,
        "structured_model_metadata_reused": not bool(modified),
        "note": (
            "Deterministic evidence metadata was rebuilt from confirmed text. "
            "Pre-edit model structured metadata was not reused for analyst-modified sections."
            if modified
            else "Confirmed text matches the current AI-generated section baseline."
        ),
    }
    return {"machine_payload": payload, "quality": payload.get("quality")}


@app.post("/api/v1/rpr/market-events/fetch")
def fetch_market_events(req: FetchRequest) -> Dict[str, Any]:
    _prune_state()
    theme_specs: List[Dict[str, str]] = []
    for item in req.theme_inputs:
        theme = str(item.theme or "").strip()
        if theme:
            theme_specs.append({"theme": theme, "description": str(item.description or "").strip()})
    if not theme_specs:
        theme_specs = [
            {"theme": str(t).strip(), "description": ""}
            for t in req.themes
            if str(t).strip()
        ]
    if not theme_specs:
        raise HTTPException(status_code=400, detail="At least one theme is required")
    max_events = max(1, min(3, int(req.max_events_per_theme or 2)))
    cache_key = _scan_key(theme_specs, max_events)
    if not req.bypass_cache:
        with _job_lock:
            cached = _scan_cache.get(cache_key)
            if cached and time.time() - float(cached.get("stored_at") or 0) <= _cache_ttl_seconds:
                response = copy.deepcopy(cached.get("result") or {})
                response.update({
                    "job_id": None,
                    "job_status": "complete",
                    "refinement_status": response.get("refinement_status") or "complete",
                    "cache_hit": True,
                })
                return response
    try:
        initial = _scout.fetch_initial_events(themes=theme_specs, max_events_per_theme=max_events)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Market scanner failed: {exc}") from exc

    job_id = uuid.uuid4().hex
    initial.update({
        "job_id": job_id,
        "job_status": "pending" if initial.get("events") else "complete",
        "refinement_status": "pending" if initial.get("events") else "not_started",
        "cache_hit": False,
    })
    with _job_lock:
        _jobs[job_id] = {
            "created_at": time.time(),
            "updated_at": time.time(),
            "status": initial["job_status"],
            "result": copy.deepcopy(initial),
            "cache_key": cache_key,
            "error": "",
        }
    if initial.get("events"):
        _job_executor.submit(_run_refinement_job, job_id)
    return initial


@app.get("/api/v1/rpr/market-events/jobs/{job_id}")
def market_event_job(job_id: str) -> Dict[str, Any]:
    _prune_state()
    try:
        return _job_response(job_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Market scanner job not found or expired") from exc


@app.post("/api/v1/rpr/market-events/jobs/{job_id}/retry-refinement")
def retry_market_event_refinement(job_id: str) -> Dict[str, Any]:
    _prune_state()
    with _job_lock:
        job = _jobs.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Market scanner job not found or expired")
        if job.get("status") in {"pending", "refining"}:
            return _job_response(job_id)
        job["status"] = "pending"
        job["error"] = ""
        job["updated_at"] = time.time()
        result = job.get("result") or {}
        result["refinement_status"] = "pending"
        for event in result.get("events") or []:
            event.setdefault("enhancement_meta", {})["refinement_status"] = "pending"
    _job_executor.submit(_run_refinement_job, job_id)
    return _job_response(job_id)


@app.post("/api/v1/rpr/market-events/refine")
def refine_market_event(req: RefineRequest) -> Dict[str, Any]:
    feedback = str(req.feedback or "").strip()
    if not feedback:
        raise HTTPException(status_code=400, detail="Feedback is required")
    theme = str(req.event.get("theme_name") or req.event.get("theme") or "")
    event_id = int(req.event.get("id") or req.event.get("event_id") or 0)
    if not can_rescan("trigger1", theme=theme, event_id=event_id):
        raise HTTPException(status_code=409, detail="Maximum enhancement-assisted rescan count reached for this event")
    try:
        updated = _scout.refine_event(
            event=req.event,
            feedback=feedback,
            affected_sections=req.affected_sections,
            analyst_modified_sections=req.analyst_modified_sections,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Targeted rescan failed: {exc}") from exc

    outcome = str((updated.get("rescan_result") or {}).get("outcome") or "COMPLETED")
    count = register_rescan_result(
        scope_type="trigger1",
        theme=theme,
        event_id=event_id,
        feedback=feedback,
        outcome=outcome,
    )
    updated.setdefault("rescan_result", {})["attempt_count"] = count
    return {"event": updated, "rescan_result": updated.get("rescan_result")}


@app.post("/api/v1/rpr/step1/enrich")
def step1_enrich(req: EnrichRequest) -> Dict[str, Any]:
    narrative = str(req.narrative or "").strip()
    if not narrative:
        raise HTTPException(status_code=400, detail="Narrative is required")
    try:
        return enrich_narrative(narrative=narrative)
    except NarrativeEnrichError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("server:app", host="127.0.0.1", port=8000, reload=True)
