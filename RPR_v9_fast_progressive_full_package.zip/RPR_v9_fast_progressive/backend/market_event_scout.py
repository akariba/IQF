"""RPR Trigger-1 v9 fast progressive market scanner.

The initial response uses one Gemini 3.5 enterprise-web call per theme to discover
and evidence up to two events by default. One background Opus call per theme refines every
event together. A refinement failure never discards successful Gemini evidence.
"""
from __future__ import annotations

import asyncio
import copy
import inspect
import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from rpr_model_trace import model_span
from step1_quality import (
    SECTION_TITLES,
    assess_sections,
    build_machine_payload,
    overall_retrieval_status,
    parse_sectioned_report,
    select_improved_sections,
    strip_control_tags,
    summarize_quality,
)

try:
    from rpr_search_agent import run_web_search as _adk_run_web_search  # type: ignore
    _ADK_IMPORT_ERROR = ""
except Exception as exc:  # pragma: no cover
    _adk_run_web_search = None
    _ADK_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"


PROMPT_DIR = Path(__file__).resolve().parent / "prompts"
BATCH_DISCOVERY_PROMPT_PATH = PROMPT_DIR / "trigger1_batch_discovery_evidence.txt"
BATCH_OPUS_PROMPT_PATH = PROMPT_DIR / "trigger1_batch_opus_refinement.txt"
TARGETED_RETRIEVAL_PROMPT_PATH = PROMPT_DIR / "trigger1_refinement.txt"
TARGETED_OPUS_PROMPT_PATH = PROMPT_DIR / "trigger1_opus_refinement.txt"

_GEMINI_TIMEOUT = max(30, int(os.environ.get("RPR_T1_INITIAL_RESULT_TIMEOUT", "90")))
_OPUS_TIMEOUT = max(30, int(os.environ.get("RPR_T1_REFINEMENT_TIMEOUT", "120")))
_TARGETED_TIMEOUT = max(30, int(os.environ.get("RPR_T1_TARGETED_TIMEOUT", "90")))
_THEME_WORKERS = max(1, min(3, int(os.environ.get("RPR_T1_THEME_WORKERS", "3"))))
_OPUS_WORKERS = max(1, min(2, int(os.environ.get("RPR_T1_OPUS_WORKERS", "2"))))
_MAX_EVENTS_DEFAULT = max(1, min(3, int(os.environ.get("RPR_T1_MAX_EVENTS_PER_THEME", "2"))))
_GEMINI_MAX_CHARS = max(12000, int(os.environ.get("RPR_T1_GEMINI_MAX_CHARS", "36000")))
_OPUS_MAX_TOKENS = max(1600, min(6000, int(os.environ.get("RPR_T1_OPUS_MAX_TOKENS", "4200"))))
_OPUS_MODEL = os.environ.get("RPR_STEP1_REFINEMENT_MODEL", "claude-opus-4-6")
_INLINE_SOURCE_RE = re.compile(r"\(Source:\s*\[[^\]]+\]\((https?://[^)]+)\)\)", re.IGNORECASE)
_GEMINI_SEMAPHORE = threading.BoundedSemaphore(_THEME_WORKERS)
_OPUS_SEMAPHORE = threading.BoundedSemaphore(_OPUS_WORKERS)


def _load_prompt(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception as exc:
        raise RuntimeError(f"Required Trigger-1 prompt not found: {path}") from exc


def _normalise_search_output(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        for key in ("answer", "text", "output", "response", "content", "raw"):
            if isinstance(value.get(key), str):
                return str(value[key])
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (list, tuple)):
        return "\n".join(_normalise_search_output(x) for x in value)
    return str(value)


def _await_in_new_thread(awaitable: Any, timeout: int) -> Any:
    result: Dict[str, Any] = {}
    error: Dict[str, BaseException] = {}

    def runner() -> None:
        try:
            result["value"] = asyncio.run(asyncio.wait_for(awaitable, timeout=timeout))
        except BaseException as exc:  # noqa: BLE001
            error["error"] = exc

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    thread.join(timeout + 5)
    if thread.is_alive():
        raise TimeoutError(f"Gemini enterprise search exceeded {timeout}s")
    if "error" in error:
        raise error["error"]
    return result.get("value")


def _adk_search_sync(prompt: str, *, timeout: int, role: str, trace_label: str) -> str:
    if _adk_run_web_search is None:
        raise RuntimeError(
            "ADK web search is unavailable because rpr_search_agent could not be imported"
            + (f": {_ADK_IMPORT_ERROR}" if _ADK_IMPORT_ERROR else "")
        )
    with _GEMINI_SEMAPHORE:
        try:
            value = _adk_run_web_search(prompt, role=role, trace_label=trace_label)
        except TypeError:
            value = _adk_run_web_search(prompt, role=role)
        if inspect.isawaitable(value):
            try:
                value = asyncio.run(asyncio.wait_for(value, timeout=timeout))
            except RuntimeError as exc:
                if "asyncio.run() cannot be called" not in str(exc):
                    raise
                value = _await_in_new_thread(value, timeout)
        text = _normalise_search_output(value).strip()
        if not text:
            raise RuntimeError("Gemini enterprise web search returned an empty response")
        return text


def _call_text_with_timeout(
    gateway: Any,
    *,
    system_prompt: str,
    user_prompt: str,
    max_tokens: int,
    timeout: int,
) -> str:
    result: Dict[str, Any] = {}
    error: Dict[str, BaseException] = {}

    def runner() -> None:
        try:
            result["value"] = gateway.call_text(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                max_tokens=max_tokens,
            )
        except BaseException as exc:  # noqa: BLE001
            error["error"] = exc

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    thread.join(timeout)
    if thread.is_alive():
        raise TimeoutError(f"R2D2 Opus refinement exceeded {timeout}s")
    if "error" in error:
        raise error["error"]
    return str(result.get("value") or "").strip()


def _call_opus_refinement(*, system_prompt: str, user_prompt: str, trace_label: str) -> str:
    try:
        from llm_gateway import get_gateway  # type: ignore
        gateway = get_gateway()
    except Exception as exc:
        raise RuntimeError(f"R2D2 gateway unavailable: {exc}") from exc
    if not hasattr(gateway, "call_text"):
        raise RuntimeError("Trigger-1 refinement requires an R2D2 gateway with call_text().")
    if hasattr(gateway, "_model"):
        gateway._model = _OPUS_MODEL
    with model_span(
        provider="r2d2",
        model=_OPUS_MODEL,
        role="trigger1_opus_batch_refinement",
        scope=trace_label,
    ) as trace:
        text = _call_text_with_timeout(
            gateway,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            max_tokens=_OPUS_MAX_TOKENS,
            timeout=_OPUS_TIMEOUT,
        )
        trace.output_chars = len(text)
    if not text:
        raise RuntimeError("Trigger-1 Opus refinement returned an empty response")
    return text


def _strip_fences(text: str) -> str:
    cleaned = str(text or "").strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    return cleaned.strip()


def _parse_json_object(text: str) -> Dict[str, Any]:
    cleaned = _strip_fences(text)
    try:
        value = json.loads(cleaned)
        if isinstance(value, dict):
            return value
    except Exception:
        pass
    decoder = json.JSONDecoder()
    for match in re.finditer(r"\{", cleaned):
        try:
            value, _ = decoder.raw_decode(cleaned[match.start():])
            if isinstance(value, dict):
                return value
        except Exception:
            continue
    raise ValueError("Model response did not contain a valid JSON object")


def _normalise_sources(value: Any) -> List[Dict[str, Any]]:
    sources: List[Dict[str, Any]] = []
    for item in value if isinstance(value, list) else []:
        if not isinstance(item, dict):
            continue
        url = str(item.get("url") or item.get("link") or "").strip()
        name = str(item.get("name") or item.get("source") or item.get("publisher") or "").strip()
        if not url and not name:
            continue
        sources.append({
            "name": name or url,
            "url": url,
            "published_at": str(item.get("published_at") or item.get("date") or "").strip(),
            "supports": list(item.get("supports") or []) if isinstance(item.get("supports"), list) else [],
        })
    return sources[:8]


def _normalise_sections(value: Any, *, retrieval_status: str = "SUCCESS") -> List[Dict[str, Any]]:
    if isinstance(value, list):
        rows: List[Any] = value
    elif isinstance(value, dict):
        rows = [value.get(str(i + 1), value.get(title, {})) for i, title in enumerate(SECTION_TITLES)]
    else:
        rows = []
    output: List[Dict[str, Any]] = []
    for index, title in enumerate(SECTION_TITLES):
        raw = rows[index] if index < len(rows) else {}
        if isinstance(raw, str):
            raw = {"text": raw}
        if not isinstance(raw, dict):
            raw = {}
        text = strip_control_tags(str(raw.get("txt") or raw.get("text") or raw.get("content") or ""))
        evidence = raw.get("source_evidence") or raw.get("sources") or []
        output.append({
            "num": index + 1,
            "title": title,
            "txt": text,
            "retrieval_status": retrieval_status,
            "source_evidence": evidence if isinstance(evidence, list) else [],
            "model_evidence_tier": raw.get("model_evidence_tier"),
            "model_retrieval_status": raw.get("model_retrieval_status"),
        })
    return output


def _filter_synthesis_citations(text: str, evidence_json: str) -> Tuple[str, int]:
    removed = 0

    def replace(match: re.Match[str]) -> str:
        nonlocal removed
        url = str(match.group(1) or "").strip()
        if url and url in evidence_json:
            return match.group(0)
        removed += 1
        return ""

    cleaned = _INLINE_SOURCE_RE.sub(replace, str(text or ""))
    return re.sub(r"[ \t]{2,}", " ", cleaned).strip(), removed


def _source_names_from_meta(section_meta: Sequence[Dict[str, Any]], sources: Sequence[Dict[str, Any]]) -> str:
    names = {str(s.get("name") or "").strip() for s in sources if str(s.get("name") or "").strip()}
    names.update(
        str(name).strip()
        for meta in section_meta
        for name in (meta.get("source_names") or [])
        if str(name).strip()
    )
    return ", ".join(sorted(names))


def _event_key(title: str) -> str:
    return re.sub(r"\W+", " ", str(title or "").lower()).strip()


class MarketEventScout:
    def __init__(self) -> None:
        self.batch_discovery_prompt = _load_prompt(BATCH_DISCOVERY_PROMPT_PATH)
        self.batch_opus_prompt = _load_prompt(BATCH_OPUS_PROMPT_PATH)
        self.targeted_retrieval_prompt = _load_prompt(TARGETED_RETRIEVAL_PROMPT_PATH)
        self.targeted_opus_prompt = _load_prompt(TARGETED_OPUS_PROMPT_PATH)

    def preflight(self) -> Dict[str, Any]:
        try:
            from rpr_search_agent import runtime_info as search_runtime_info
            search_runtime = search_runtime_info()
        except Exception as exc:
            search_runtime = {"error": f"{type(exc).__name__}: {exc}"}
        return {
            "ok": _adk_run_web_search is not None and "error" not in search_runtime,
            "adk_available": _adk_run_web_search is not None,
            "adk_import_error": _ADK_IMPORT_ERROR or None,
            "search_runtime": search_runtime,
            "scanner_mode": "v9_progressive_batched_theme_pipeline",
            "prompt_paths": [
                str(BATCH_DISCOVERY_PROMPT_PATH),
                str(BATCH_OPUS_PROMPT_PATH),
                str(TARGETED_RETRIEVAL_PROMPT_PATH),
                str(TARGETED_OPUS_PROMPT_PATH),
            ],
            "models": {
                "initial": os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash"),
                "refinement": _OPUS_MODEL,
            },
            "limits": {
                "theme_workers": _THEME_WORKERS,
                "opus_workers": _OPUS_WORKERS,
                "max_events_per_theme_default": _MAX_EVENTS_DEFAULT,
                "initial_timeout_seconds": _GEMINI_TIMEOUT,
                "refinement_timeout_seconds": _OPUS_TIMEOUT,
            },
        }

    @staticmethod
    def _theme_specs(themes: Sequence[Any]) -> List[Dict[str, Any]]:
        specs: List[Dict[str, Any]] = []
        for original_index, item in enumerate(themes):
            if isinstance(item, dict):
                theme = str(item.get("theme") or item.get("name") or "").strip()
                description = str(item.get("description") or item.get("narr") or "").strip()
            else:
                theme = str(item or "").strip()
                description = ""
            if theme:
                specs.append({"theme": theme, "description": description, "theme_index": original_index})
        if not specs:
            raise ValueError("At least one theme is required")
        return specs

    def _scan_theme_gemini(self, spec: Dict[str, Any], max_events: int) -> List[Dict[str, Any]]:
        runtime = {
            "mode": "BATCH_DISCOVERY_AND_EVIDENCE",
            "report_as_of": datetime.now(timezone.utc).isoformat(),
            "theme": spec["theme"],
            "description": spec["description"] or None,
            "requested_event_count": max_events,
            "section_titles": list(SECTION_TITLES),
        }
        raw = _adk_search_sync(
            self.batch_discovery_prompt + "\n\n# RUNTIME\n" + json.dumps(runtime, ensure_ascii=False, indent=2),
            timeout=_GEMINI_TIMEOUT,
            role="discovery",
            trace_label=f"theme:{spec['theme'][:60]}",
        )[:_GEMINI_MAX_CHARS]
        parsed = _parse_json_object(raw)
        event_rows = parsed.get("events")
        if not isinstance(event_rows, list):
            raise ValueError("Gemini batch response did not contain an events array")
        output: List[Dict[str, Any]] = []
        for item in event_rows[:max_events]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("title") or item.get("event") or "").strip()
            if not title:
                continue
            sections = _normalise_sections(item.get("sections"), retrieval_status="SUCCESS")
            if not any(str(section.get("txt") or "").strip() for section in sections):
                continue
            output.append({
                "title": title,
                "event_date": str(item.get("event_date") or "").strip(),
                "why_material": str(item.get("why_material") or item.get("rationale") or "").strip(),
                "confidence": str(item.get("confidence") or "MEDIUM").upper(),
                "sections": sections,
                "sources": _normalise_sources(item.get("sources")),
                "search_queries": [str(q).strip() for q in (item.get("search_queries") or []) if str(q).strip()],
            })
        if not output:
            raise ValueError("Gemini batch response contained no usable evidenced event")
        return output

    def _build_initial_event(self, *, event_id: int, spec: Dict[str, Any], item: Dict[str, Any]) -> Dict[str, Any]:
        sections = copy.deepcopy(item["sections"])
        sources = copy.deepcopy(item.get("sources") or [])
        queries = list(item.get("search_queries") or [])
        section_meta = assess_sections(sections)
        retrieval_status = overall_retrieval_status(section_meta)
        event_info = {
            "title": item["title"],
            "event_date": item.get("event_date") or "",
            "theme": spec["theme"],
            "why_material": item.get("why_material") or "",
            "confidence": item.get("confidence") or "MEDIUM",
        }
        machine_payload = build_machine_payload(
            trigger="trigger1",
            sections=sections,
            event=event_info,
            query_log=queries,
            query_log_source="gemini_batch_reported_search_formulations",
            model_metadata={"stage": "gemini_initial", "refinement_status": "pending"},
        )
        initial_model = os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash")
        enhancement_meta = {
            "retrieval_failure": retrieval_status == "TECHNICAL_FAILURE",
            "retrieval_status": retrieval_status,
            "refinement_status": "pending",
            "section_meta": section_meta,
            "quality": summarize_quality(section_meta),
            "executed_query": " | ".join(queries),
            "query_log": queries,
            "query_log_source": "gemini_batch_reported_search_formulations",
            "machine_payload": machine_payload,
            "model_path": f"Gemini {initial_model} batched discovery+evidence -> pending R2D2 {_OPUS_MODEL}",
            "models_triggered": [{"provider": "gemini", "model": initial_model, "role": "trigger1_batch_discovery_evidence"}],
            "evidence_sources": sources,
        }
        source_names = _source_names_from_meta(section_meta, sources)
        return {
            "id": event_id,
            "event_id": event_id,
            "label": f"Event {event_id}",
            "subtitle": item["title"],
            "theme": spec["theme"],
            "theme_name": spec["theme"],
            "theme_index": int(spec["theme_index"]),
            "event_date": item.get("event_date") or "",
            "why_material": item.get("why_material") or "",
            "confidence": item.get("confidence") or "MEDIUM",
            "sections": sections,
            "source": source_names,
            "source_names": source_names,
            "horizon": "12 months",
            "search_failed": False,
            "fail_reason": "",
            "executed_query": " | ".join(queries),
            "query_log": queries,
            "enhancement_meta": enhancement_meta,
            "machine_payload": machine_payload,
        }

    def fetch_initial_events(self, themes: Sequence[Any], max_events_per_theme: int = 2) -> Dict[str, Any]:
        """Return complete Gemini results and mark Opus refinement as pending."""
        started = time.monotonic()
        specs = self._theme_specs(themes)
        requested = int(max_events_per_theme or _MAX_EVENTS_DEFAULT)
        max_events = max(1, min(3, requested, _MAX_EVENTS_DEFAULT))
        results_by_index: Dict[int, List[Dict[str, Any]]] = {}
        errors_by_index: Dict[int, str] = {}

        def scan(spec: Dict[str, Any]) -> Tuple[int, List[Dict[str, Any]], str]:
            index = int(spec["theme_index"])
            try:
                return index, self._scan_theme_gemini(spec, max_events), ""
            except Exception as exc:
                return index, [], f"{type(exc).__name__}: {exc}"

        with ThreadPoolExecutor(max_workers=min(_THEME_WORKERS, len(specs))) as pool:
            futures = {pool.submit(scan, spec): spec for spec in specs}
            for future in as_completed(futures):
                index, rows, error = future.result()
                results_by_index[index] = rows
                if error:
                    errors_by_index[index] = error

        if len(errors_by_index) == len(specs):
            detail = " | ".join(
                f"{spec['theme']}: {errors_by_index.get(int(spec['theme_index']), 'failed')}" for spec in specs
            )
            raise RuntimeError(f"All Gemini theme scans failed. {detail}")

        warnings: List[str] = []
        events: List[Dict[str, Any]] = []
        seen: set[str] = set()
        event_id = 1
        for spec in specs:
            index = int(spec["theme_index"])
            if index in errors_by_index:
                warnings.append(f"Gemini scan failed for '{spec['theme']}': {errors_by_index[index]}")
                continue
            for item in results_by_index.get(index, []):
                key = _event_key(item.get("title") or "")
                if key and key in seen:
                    warnings.append(f"Duplicate event skipped across themes: {item.get('title')}")
                    continue
                if key:
                    seen.add(key)
                events.append(self._build_initial_event(event_id=event_id, spec=spec, item=item))
                event_id += 1

        elapsed = round(time.monotonic() - started, 3)
        return {
            "events": events,
            "themes": [spec["theme"] for spec in specs],
            "theme_inputs": [{"theme": spec["theme"], "description": spec["description"]} for spec in specs],
            "source": "ADK Gemini enterprise web search",
            "sources_seen": sorted({
                name.strip()
                for event in events
                for name in str(event.get("source_names") or "").split(",")
                if name.strip()
            }),
            "total": len(events),
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
            "warnings": warnings,
            "scanner_mode": "v9_gemini_batch_initial",
            "refinement_status": "pending" if events else "not_started",
            "models_triggered": [{
                "provider": "gemini",
                "model": os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash"),
                "role": "trigger1_batch_discovery_evidence",
            }],
            "scan_timing": {
                "initial_seconds": elapsed,
                "theme_workers": min(_THEME_WORKERS, len(specs)),
                "calls_completed": len(specs) - len(errors_by_index),
            },
        }

    @staticmethod
    def _compact_event_for_opus(event: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "event_id": int(event.get("event_id") or event.get("id") or 0),
            "title": str(event.get("subtitle") or event.get("title") or ""),
            "event_date": str(event.get("event_date") or ""),
            "why_material": str(event.get("why_material") or ""),
            "sources": list((event.get("enhancement_meta") or {}).get("evidence_sources") or []),
            "sections": [
                {"num": section.get("num"), "title": section.get("title"), "text": section.get("txt")}
                for section in (event.get("sections") or [])
            ],
        }

    def _refine_theme_group(self, theme: str, events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        evidence_input = {
            "report_as_of": datetime.now(timezone.utc).isoformat(),
            "theme": theme,
            "section_titles": list(SECTION_TITLES),
            "word_limit_per_section": "120-180 words",
            "events": [self._compact_event_for_opus(event) for event in events],
        }
        evidence_json = json.dumps(evidence_input, ensure_ascii=False)
        with _OPUS_SEMAPHORE:
            raw = _call_opus_refinement(
                system_prompt=self.batch_opus_prompt,
                user_prompt=evidence_json,
                trace_label=f"theme:{theme[:60]}",
            )
        parsed = _parse_json_object(raw)
        refined_rows = parsed.get("events")
        if not isinstance(refined_rows, list):
            raise ValueError("Opus batch response did not contain an events array")
        by_id = {
            int(row.get("event_id") or row.get("id") or 0): row
            for row in refined_rows
            if isinstance(row, dict)
        }
        if not by_id:
            raise ValueError("Opus batch response contained no identifiable events")

        updated: List[Dict[str, Any]] = []
        for original in events:
            event = copy.deepcopy(original)
            event_id = int(event.get("event_id") or event.get("id") or 0)
            row = by_id.get(event_id)
            meta = event.setdefault("enhancement_meta", {})
            if row is None:
                meta["refinement_status"] = "failed"
                meta["refinement_error"] = "Event missing from Opus batch response; Gemini result retained."
                updated.append(event)
                continue
            sections = _normalise_sections(row.get("sections"), retrieval_status="SUCCESS")
            removed_total = 0
            for section in sections:
                section["txt"], removed = _filter_synthesis_citations(section.get("txt") or "", evidence_json)
                section["unverified_citation_count"] = removed
                removed_total += removed
            if not any(str(section.get("txt") or "").strip() for section in sections):
                meta["refinement_status"] = "failed"
                meta["refinement_error"] = "Opus returned empty sections; Gemini result retained."
                updated.append(event)
                continue
            section_meta = assess_sections(sections)
            sources = list(meta.get("evidence_sources") or [])
            event["sections"] = sections
            event["source"] = _source_names_from_meta(section_meta, sources)
            event["source_names"] = event["source"]
            machine_payload = build_machine_payload(
                trigger="trigger1",
                sections=sections,
                event={
                    "title": event.get("subtitle"),
                    "event_date": event.get("event_date"),
                    "theme": theme,
                    "why_material": event.get("why_material"),
                },
                query_log=event.get("query_log") or [],
                query_log_source=str(meta.get("query_log_source") or "gemini_batch_reported_search_formulations"),
                model_metadata={"stage": "opus_batch_refined", "refinement_status": "complete"},
            )
            event["machine_payload"] = machine_payload
            meta.update({
                "retrieval_failure": False,
                "retrieval_status": overall_retrieval_status(section_meta),
                "refinement_status": "complete",
                "refinement_error": "",
                "section_meta": section_meta,
                "quality": summarize_quality(section_meta),
                "machine_payload": machine_payload,
                "model_path": (
                    f"Gemini {os.environ.get('RPR_GEMINI_DISCOVERY_MODEL', 'gemini-3.5-flash')} "
                    f"batched discovery+evidence -> R2D2 {_OPUS_MODEL} batched refinement"
                ),
                "models_triggered": [
                    {
                        "provider": "gemini",
                        "model": os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash"),
                        "role": "trigger1_batch_discovery_evidence",
                    },
                    {"provider": "r2d2", "model": _OPUS_MODEL, "role": "trigger1_opus_batch_refinement"},
                ],
                "unsupported_synthesis_citations_removed": removed_total,
            })
            updated.append(event)
        return updated

    def refine_initial_result(self, initial: Dict[str, Any]) -> Dict[str, Any]:
        """Refine themes concurrently and always retain successful Gemini events."""
        started = time.monotonic()
        result = copy.deepcopy(initial)
        original_events = list(result.get("events") or [])
        groups: Dict[int, List[Dict[str, Any]]] = {}
        for event in original_events:
            groups.setdefault(int(event.get("theme_index") or 0), []).append(event)
        if not groups:
            result["refinement_status"] = "not_started"
            return result

        updated_groups: Dict[int, List[Dict[str, Any]]] = {}
        errors: Dict[int, str] = {}

        def refine(index: int, rows: List[Dict[str, Any]]) -> Tuple[int, List[Dict[str, Any]], str]:
            theme = str(rows[0].get("theme_name") or rows[0].get("theme") or "")
            try:
                return index, self._refine_theme_group(theme, rows), ""
            except Exception as exc:
                retained = copy.deepcopy(rows)
                status = "timeout" if isinstance(exc, TimeoutError) else "failed"
                for event in retained:
                    meta = event.setdefault("enhancement_meta", {})
                    meta["refinement_status"] = status
                    meta["refinement_error"] = f"{type(exc).__name__}: {exc}; Gemini result retained."
                return index, retained, f"{type(exc).__name__}: {exc}"

        with ThreadPoolExecutor(max_workers=min(_OPUS_WORKERS, len(groups))) as pool:
            futures = {pool.submit(refine, index, rows): index for index, rows in groups.items()}
            for future in as_completed(futures):
                index, rows, error = future.result()
                updated_groups[index] = rows
                if error:
                    errors[index] = error

        result["events"] = [event for index in sorted(updated_groups) for event in updated_groups[index]]
        warnings = list(result.get("warnings") or [])
        for index, error in errors.items():
            theme = next(
                (str(e.get("theme_name") or "") for e in original_events if int(e.get("theme_index") or 0) == index),
                str(index),
            )
            warnings.append(f"Opus refinement failed for '{theme}'; Gemini results were retained: {error}")
        result["warnings"] = warnings
        success_count = len(groups) - len(errors)
        result["refinement_status"] = "complete" if not errors else "failed" if success_count == 0 else "partial_failed"
        result["scanner_mode"] = "v9_progressive_gemini_then_opus_batch"
        result["models_triggered"] = [
            {
                "provider": "gemini",
                "model": os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash"),
                "role": "trigger1_batch_discovery_evidence",
            },
            {"provider": "r2d2", "model": _OPUS_MODEL, "role": "trigger1_opus_batch_refinement"},
        ]
        timing = dict(result.get("scan_timing") or {})
        timing["refinement_seconds"] = round(time.monotonic() - started, 3)
        timing["opus_workers"] = min(_OPUS_WORKERS, len(groups))
        timing["total_seconds"] = round(float(timing.get("initial_seconds") or 0) + timing["refinement_seconds"], 3)
        result["scan_timing"] = timing
        return result

    def fetch_events(self, themes: Sequence[Any], max_events_per_theme: int = 2) -> Dict[str, Any]:
        """Compatibility method: return initial results; server owns background refinement."""
        return self.fetch_initial_events(themes, max_events_per_theme)

    def refine_event(
        self,
        event: Dict[str, Any],
        feedback: str,
        affected_sections: Optional[Sequence[str]] = None,
        analyst_modified_sections: Optional[Sequence[str]] = None,
    ) -> Dict[str, Any]:
        """Targeted analyst-approved rescan; original sections survive non-improvements."""
        guidance = str(feedback or "").strip()
        if not guidance:
            raise ValueError("Feedback/refinement guidance is required")
        affected = [name for name in (affected_sections or []) if name in SECTION_TITLES]
        if not affected:
            affected = list(SECTION_TITLES)
        original_sections = list(event.get("sections") or [])
        theme = str(event.get("theme_name") or event.get("theme") or "").strip()
        title = str(event.get("subtitle") or event.get("label") or "Market event").strip()
        event_id = int(event.get("event_id") or event.get("id") or 0)
        trace_label = f"event:E{event_id}:targeted"
        retrieval_input = {
            "mode": "TARGETED_RETRIEVAL",
            "report_as_of": datetime.now(timezone.utc).isoformat(),
            "theme": theme,
            "event": title,
            "affected_sections": affected,
            "analyst_guidance": guidance,
        }
        evidence = _adk_search_sync(
            self.targeted_retrieval_prompt + "\n\n# RUNTIME\n" + json.dumps(retrieval_input, ensure_ascii=False, indent=2),
            timeout=_TARGETED_TIMEOUT,
            role="evidence",
            trace_label=trace_label,
        )[:_GEMINI_MAX_CHARS]
        parsed_evidence = parse_sectioned_report(evidence)
        queries = [str(q).strip() for q in (parsed_evidence.get("search_queries") or []) if str(q).strip()]
        opus_input = {
            **retrieval_input,
            "prior_sections": original_sections,
            "enterprise_web_evidence": evidence,
        }
        raw = _call_opus_refinement(
            system_prompt=self.targeted_opus_prompt,
            user_prompt=json.dumps(opus_input, ensure_ascii=False),
            trace_label=trace_label,
        )
        try:
            parsed = _parse_json_object(raw)
            candidate_sections = _normalise_sections(parsed.get("sections"), retrieval_status="SUCCESS")
        except Exception:
            parsed_report = parse_sectioned_report(raw)
            candidate_sections = _normalise_sections(parsed_report.get("sections"), retrieval_status="SUCCESS")
        for section in candidate_sections:
            section["txt"], removed = _filter_synthesis_citations(section.get("txt") or "", evidence)
            section["unverified_citation_count"] = removed
        final_sections, comparison = select_improved_sections(original_sections, candidate_sections, affected)
        modified_before = {name for name in (analyst_modified_sections or []) if name in SECTION_TITLES}
        accepted = set(comparison.get("accepted_sections") or [])
        final_modified = sorted(modified_before - accepted, key=lambda name: SECTION_TITLES.index(name))
        section_meta = assess_sections(final_sections)
        retrieval_status = overall_retrieval_status(section_meta)
        machine_payload = build_machine_payload(
            trigger="trigger1",
            sections=final_sections,
            event={"title": title, "theme": theme},
            query_log=queries or [guidance],
            query_log_source="model_reported_search_formulations" if queries else "analyst_approved_search_instruction",
            model_metadata={"stage": "targeted_refinement"} if not final_modified else {},
        )
        machine_payload["analyst_state"] = {
            "confirmed": False,
            "modified_sections": final_modified,
            "structured_model_metadata_reused": not bool(final_modified),
        }
        updated = copy.deepcopy(event)
        updated.update({
            "id": event_id,
            "event_id": event_id,
            "sections": final_sections,
            "source_names": _source_names_from_meta(section_meta, []),
            "executed_query": " | ".join(queries or [guidance]),
            "query_log": queries or [guidance],
            "machine_payload": machine_payload,
            "rescan_result": {**comparison, "guidance": guidance},
        })
        updated.setdefault("enhancement_meta", {}).update({
            "retrieval_failure": retrieval_status == "TECHNICAL_FAILURE",
            "retrieval_status": retrieval_status,
            "refinement_status": "complete",
            "section_meta": section_meta,
            "quality": summarize_quality(section_meta),
            "machine_payload": machine_payload,
            "models_triggered": [
                {
                    "provider": "gemini",
                    "model": os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", "gemini-3.5-flash"),
                    "role": "trigger1_targeted_retrieval",
                },
                {"provider": "r2d2", "model": _OPUS_MODEL, "role": "trigger1_targeted_refinement"},
            ],
        })
        return updated
