# start_backend.ps1 — convenience launcher for the RPR backend.
# Run this from the folder containing server.py, market_event_scout.py,
# and web_search_agent.py.

if (-not $env:ANTHROPIC_API_KEY) {
    Write-Warning "ANTHROPIC_API_KEY is not set — Trigger 2 (R2D2 enrichment) will fail 502 until it is."
    Write-Host "Set it for this session with:  `$env:ANTHROPIC_API_KEY = 'sk-ant-...'" -ForegroundColor Yellow
}

if (-not (Test-Path ".\.venv")) {
    Write-Host "Creating virtual environment (.venv)..." -ForegroundColor Cyan
    python -m venv .venv
}

. .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt --quiet

Write-Host "Starting backend on http://127.0.0.1:8000 ..." -ForegroundColor Green
uvicorn server:app --host 127.0.0.1 --port 8000 --reload
