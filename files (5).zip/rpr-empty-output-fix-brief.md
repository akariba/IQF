# Engineering Brief — Fix Empty/Failed Event Generation in ICM PM Rapid Portfolio Review

## Context

The Rapid Portfolio Review tool has two generation paths that both populate the same
8-section event structure:

- **Trigger 1 (Market Scanner)** — `market_event_scout.py` (`MarketEventScout.fetch_events`),
  called from `rpr-step1-test-v2.html` via `POST /api/v1/rpr/market-events/fetch`.
- **Trigger 2 (User Narrative / R2D2)** — a separate enrichment prompt (the "R2D2" prompt,
  `#Role / #Context / #Objective / #Guidelines / #Output Format / #Demonstration Example / #Input`),
  called via `POST /api/v1/rpr/step1/enrich`.

**Symptom:** most scans currently return empty or placeholder-looking events.

This brief is the single source of truth for the fix. Work through it in order —
Section 1 is mandatory and must be done **before** any code is changed, because it
determines which of the later sections actually apply.

Do not rewrite files wholesale. Every change below is scoped to a specific
function/section. Preserve all other behavior, styling, and structure exactly as-is,
including the existing `#Role / #Context / #Objective / #Guidelines / #Output Format /
#Demonstration Example` structure of the R2D2 prompt — amend it, do not replace it.

---

## 1. Root-cause diagnosis (do this first, before touching code)

Run the scout module standalone, outside the HTML/frontend entirely, so backend and
frontend failure modes cannot be confused with each other:

```python
import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s %(levelname)s %(message)s')

from market_event_scout import MarketEventScout

scout = MarketEventScout()
preflight = scout.preflight()
print("Preflight:", preflight)   # adk_available MUST be True — if False, stop here

result = scout.fetch_events(themes=["US Tariff Escalation 2026"], max_events_per_theme=3)
print("Warnings:", result["warnings"])
for ev in result["events"]:
    print("---")
    print("failed:", ev["_search_failed"], "| reason:", ev["_fail_reason"])
    print("raw (first 300 chars):", ev["raw_search_result"][:300])
```

Record the outcome. It determines which fix track applies:

| Observation | Root cause | Fix track |
|---|---|---|
| `adk_available: False` | `web_search_agent` import failing silently | Track A |
| `_fail_reason: "timeout"` on most/all events | 240s insufficient, or timeout exception mismatch swallowing real timeouts as generic errors | Track B |
| `_fail_reason: "no_results"`, ADK call succeeds but returns <100 chars | Search backend / query issue, not a parsing bug | Track C |
| `raw_search_result` has real, substantial content but `sections` are generic/thin | `[EVENT_N]...[/EVENT_N]` tag parsing failing, falling through to keyword-sentence fallback | Track D |

Attach the console output (or at minimum the `warnings` array and one event's
`_fail_reason` + first 300 chars of `raw_search_result`) to the ticket/PR for this work.
Do not proceed to write fixes for a track that the diagnosis did not actually surface.

---

## 2. `market_event_scout.py` — required changes

### 2.1 Surface preflight status in the UI (applies regardless of track)
`preflight()` already returns `adk_available`. Nothing currently displays this in
`rpr-step1-test-v2.html`. Add a call to a `/preflight`-equivalent endpoint (or fold
`adk_available` into the existing `/health` response) and surface it in the connection
chip (`#conn-chip` / `#conn-lbl`) so "Backend Live" vs "ADK unavailable" are visibly
different states, not both shown as green/connected.

### 2.2 Fix timeout exception handling (Track B)
In `_adk_search_sync`, the running-loop branch does not catch `asyncio.TimeoutError`
raised inside the inner `_run()` — only `concurrent.futures.TimeoutError` is caught
by the outer `with ThreadPoolExecutor` block. On Python versions where these are
distinct exception classes, a genuine ADK timeout in the threaded path is
mis-classified as a generic `Exception` in `fetch_events()`, producing an `"error"`
placeholder instead of a `"timeout"` placeholder. Fix `_run()` to convert
`asyncio.TimeoutError` to the builtin `TimeoutError` before it propagates, mirroring
what the non-running-loop branch already does.

### 2.3 Add debug visibility without re-running the standalone script every time (Track C/D)
`fetch_events()` already returns `warnings` and each `MarketEvent.to_dict()` already
includes `raw_search_result` and `_fail_reason`. These are computed but never surfaced
in the UI. No new logging infrastructure is needed — wire the existing fields through
(see Section 3.3).

### 2.4 Fix dead `max_events_per_theme` parameter
`fetch_events(self, themes=None, max_events_per_theme: int = 3)` immediately overwrites
the argument with `max_events_per_theme = 3`. Remove the override line and actually
respect the caller's value (or, if 3 must always be enforced, remove the parameter
from the signature instead of silently ignoring it — pick one, don't leave both).

### 2.5 Align `[S1]` regex between section parser and headline extractor (possible contributor to Track D)
`_parse_sections_from_block`'s `label_pat` requires whitespace after the section
number (`\[S(\d)\s+[^\]]*\]`), while `_extract_headline`'s pattern matches a bare
`[S1]` with no following text (`\[S1[^\]]*\]`). If the model ever emits a bare
`[S1]` marker, section parsing silently drops to the fallback path while headline
extraction still succeeds — producing events that look partially populated. Align
both patterns to accept a bare `[S<n>]` marker.

### 2.6 Log silently swallowed parse failures
`except (ValueError, IndexError): i += 1` in the Method 1 section parser currently
has no logging. Add `log.debug(...)` here so malformed section markers are visible
in diagnosis rather than invisible.

### 2.7 Replace hardcoded source attribution
`parse_response()` currently hardcodes `source_names="Bloomberg · Reuters · FT"` and
`MarketEventSource(name="ADK enterprise_web_search", ...)` regardless of what the
model actually cited. Extract real source mentions from `answer`/`block` by matching
against `APPROVED_SOURCES` instead of hardcoding. This is a traceability requirement
for a credit-risk tool, not cosmetic — do not defer this.

### 2.8 (Optional, do only if Track B diagnosis shows total wall-clock time is the constraint)
Parallelize the per-theme loop in `fetch_events()` (themes are independent; nothing
requires sequential processing). Do not do this as a first response to empty outputs —
only after Section 1's diagnosis confirms timeout, and only after 2.2 is fixed and
retested, since parallelizing a mis-classified timeout won't fix anything.

---

## 3. `rpr-step1-test-v2.html` — required changes

### 3.1 Fix naming mismatch: "Contagious" vs "Contagion"
The reference build (`icm-pm-rapid-portfolio-review-v31.html`) uses **"Contagion
Impact Geographies."** Both `SECTION_TITLES` in `market_event_scout.py` and the `SECS`
array in this file use **"Contagious Impact Geographies."** Pick one spelling and make
all three consistent. Recommend matching v31 since it is the design reference.

### 3.2 Restore the Trigger 1 feedback loop
`icm-pm-rapid-portfolio-review-v31.html` has a "Feedback to Market Scanner Agent"
input box wired to re-query the scanner with user feedback — this is the UI caller for
`MarketEventScout.refine_event()`, which currently has **no caller anywhere** in
`rpr-step1-test-v2.html`. Port this control back in:
- A feedback textarea + submit button under the event detail panel (or wherever fits
  the current layout), matching v31's placement.
- On submit, call a `/refine`-equivalent endpoint that invokes `refine_event(event, feedback)`.
- Update the corresponding event in `THEMES_DATA` in place and re-render
  (`renderEvTree()`, `renderEvDetail()`) rather than triggering a full re-scan.

### 3.3 Surface `_fail_reason` / `raw_search_result` for failed events
When `ev.failed` is true, add a collapsible "Debug info" block inside the existing
event detail panel (`renderEvDetail`) showing `_fail_reason` and the first ~500 chars
of `raw_search_result`. This reuses data already returned by the backend (Section 2.3)
— no new endpoint required.

### 3.4 Fix modal/panel section-sync bugs
- `openModal()` renders `modal-nacc` directly from `ev.sections`, but the main panel
  only writes edits back into `ev.sections` via `saveCurrentSections()`, which only
  fires on navigation away from the event. Call `saveCurrentSections()` at the top of
  `openModal()` so the modal can't show stale text relative to unsaved edits in the
  main panel.
- `closeModal()` does not call `syncModalSections()` on plain close (✕ button) — only
  the Proceed/Confirm footer buttons do. Either call `syncModalSections()` in
  `closeModal()` too, or add a visible "unsaved changes" affordance if discarding on
  close is intentional.

---

## 4. R2D2 enrichment prompt — required amendments

**Preserve the existing prompt structure exactly** (`#Role`, `#Context`, `#Objective`,
`#Guidelines` with its four steps, `#Output Format`, `#Demonstration Example`,
`#Input`). The changes below are targeted insertions/edits within that structure, not
a rewrite.

### 4.1 Resolve the Step 4 contradiction
Step 4 currently states both "do not speculate beyond what is reported in sources"
and (in `#Output Format`) "do not leave fields as placeholders" with no way to satisfy
both when a section genuinely has no material in the 3-month window. This is a likely
contributor to unreliable output on niche narratives. Add an explicit exception directly
under the existing Step 4 bullets:

> - If no material is found for a section within the 3-month window after a genuine
>   search, state that explicitly (e.g., "No sources published in the past 3 months
>   address [X] for this narrative") rather than inferring or fabricating content to
>   fill the section.

### 4.2 Add a citation format spec
Step 4 already requires "Cite the source URL for every key claim or data point used,"
but neither `#Output Format` nor `#Demonstration Example` shows what that looks like —
the demonstration example currently has zero URLs. Add one line to `#Output Format`
specifying the exact citation style (e.g., inline `[Source: <URL>]` after the sentence,
or a trailing "Sources:" list per section — pick one), and **update the Demonstration
Example to actually include citations in that format**, so the model has a concrete
pattern to follow rather than an instruction contradicted by its own example.

### 4.3 Inject the current date explicitly
"Most recent 3 months" is undated in the prompt as written. Add a line to `#Input`
(or immediately above it) of the form:

> Today's date: {current_date}

and confirm the calling code actually populates this at request time. Without it, the
model has to infer "now" from its own training data, which will silently drift stale.

### 4.4 Specify the machine-readable output schema
The frontend's `rs()` helper (in `rpr-step1-test-v2.html`) probes multiple key-name
variants per section (e.g., `event_summary` / `event_overview`) — a defensive pattern
that only makes sense if the model's actual field naming has been observed to drift.
Add an explicit schema block to `#Output Format` specifying the exact JSON keys
expected for each of the 8 sections, matching the canonical `SECTION_TITLES` /
`SECS` naming resolved in Section 3.1 above. Once this is added, the frontend's `rs()`
fallback list can be trimmed to just the canonical key (tracked separately, not part
of this brief).

---

## 5. Acceptance criteria

- [ ] Section 1 diagnosis was run and its output is attached to this work item.
- [ ] `preflight()`'s `adk_available` is visibly surfaced in the UI connection state.
- [ ] A deliberately-forced timeout (e.g., temporarily lower `TOUT.SCAN`/timeout param)
      produces a `"timeout"` placeholder, not an `"error"` placeholder.
- [ ] `max_events_per_theme` passed from the frontend is honored by the backend, or the
      parameter is removed — not silently ignored.
- [ ] A live scan against a real theme returns non-empty, source-attributed events
      (source names reflect what was actually cited, not a fixed string).
- [ ] Failed/empty events show `_fail_reason` and a `raw_search_result` excerpt in the UI.
- [ ] "Feedback to Market Scanner Agent" is present in `rpr-step1-test-v2.html` and
      successfully calls `refine_event()` end-to-end.
- [ ] Section naming ("Contagion" vs "Contagious") matches across `market_event_scout.py`,
      `rpr-step1-test-v2.html`, and the R2D2 prompt's `#Output Format`.
- [ ] The R2D2 prompt's `#Demonstration Example` includes citations in the format now
      specified in `#Output Format`.
- [ ] The R2D2 prompt's `#Input` section includes an explicit current-date line, and the
      calling code populates it.
