"""
narrative_enricher.py — Trigger 2 ("R2D2"): calls the LLM with the prompt
in r2d2_prompt.py and parses its labelled-text response into the flat
dict the frontend's rs() helper expects.

Two things this file deliberately does NOT do:
  - It does not rewrite the R2D2 prompt's own Output Format into JSON.
    The prompt already specifies "Field Title:" labels; this module
    parses that format directly (same label-splitting approach as
    market_event_scout.py's MarketEventParser, for consistency with the
    Trigger-1/ADK code path).
  - It does not hardcode a public Anthropic API key as the only way to
    reach the model. See LLMClient below.
"""

from __future__ import annotations

import logging
import os
import re
from datetime import date

import anthropic

from r2d2_prompt import R2D2_PROMPT

log = logging.getLogger("narrative_enricher")

MODEL = os.environ.get("RPR_LLM_MODEL", "claude-sonnet-5")
MAX_TOKENS = 6000
WEB_SEARCH_MAX_USES = 8

NO_DATA_MARKER = "no data returned for this section"

# (flat_key, exact label text as it appears in r2d2_prompt.py's Output Format)
LABELS: list[tuple[str, str]] = [
    ("event_overview", "Event Overview"),
    ("event_history", "Event History"),
    ("direct_impact_geographies", "Direct Impact Geographies"),
    ("contagion_impact_geographies", "Contagious Impact Geographies"),
    ("equity_market_impact", "Equity Market Impact"),
    ("credit_market_impact", "Credit Market Impact"),
    ("commodity_market_impact", "Commodity Market Impact"),
    ("assumptions", "Assumptions"),
]

# Alternate key names the frontend's rs(data, primaryKey, fallbackKey)
# helper also checks — every section is emitted under both so either
# lookup order it uses will find content.
SECTION_ALIASES = {
    "event_overview": "event_summary",
    "event_history": "history",
    "direct_impact_geographies": "direct_impact",
    "contagion_impact_geographies": "contagion_impact",
    "equity_market_impact": "equity_impact",
    "credit_market_impact": "credit_impact",
    "commodity_market_impact": "commodity_impact",
    "assumptions": "assumptions",
}

_LABEL_PATTERN = re.compile(
    r"^\s*(" + "|".join(re.escape(title) for _, title in LABELS) + r")\s*:\s*",
    re.IGNORECASE | re.MULTILINE,
)


class NarrativeEnrichError(RuntimeError):
    """Raised when the model call fails or its output can't be parsed."""


# ---------------------------------------------------------------------------
# LLM transport — swappable between the public API and an internal gateway
# ---------------------------------------------------------------------------

class LLMClient:
    """
    Wraps the model call so this module can point at either the public
    Anthropic API or an internal enterprise gateway without any change to
    the calling code in enrich_narrative().

    The frontend's classifyErr() already checks for STYLUS_NO_TOKEN /
    STYLUS_TIMEOUT patterns, which implies an internal gateway ("Stylus")
    is the real target in production, not a bare ANTHROPIC_API_KEY.

    Configure via environment variables:
      RPR_LLM_BASE_URL     Internal gateway URL. Unset -> public Anthropic API.
      RPR_LLM_API_KEY      Token/key for whichever endpoint is active.
                            Falls back to ANTHROPIC_API_KEY if unset.
      RPR_LLM_AUTH_HEADER  Header name carrying the token.
                            Default "x-api-key" (Anthropic's own header).
                            Set to "Authorization" if the gateway expects
                            "Bearer <token>" — this class adds the
                            "Bearer " prefix automatically in that case.
      RPR_LLM_MODEL         Model id. Default MODEL above.
      RPR_LLM_WEB_SEARCH    "1"/"0", default "1". Set "0" only if the
                            gateway can't proxy Anthropic's server-side
                            web_search tool — the prompt requires live
                            search, so this should stay "1" in production.

    ASSUMPTION FLAGGED FOR CONFIRMATION: this assumes the gateway is
    wire-compatible with Anthropic's /v1/messages API (common for
    enterprise LLM proxies that sit in front of it). If your Stylus
    gateway uses a different request/response shape, replace the body
    of call() with a raw httpx POST matching that shape — R2D2_PROMPT,
    the parser, and the section-key mapping below are unaffected either
    way.
    """

    def __init__(self):
        self.base_url = os.environ.get("RPR_LLM_BASE_URL") or None
        self.token = (
            os.environ.get("RPR_LLM_API_KEY")
            or os.environ.get("ANTHROPIC_API_KEY")
        )
        self.auth_header = os.environ.get("RPR_LLM_AUTH_HEADER", "x-api-key")
        self.model = os.environ.get("RPR_LLM_MODEL", MODEL)
        self.web_search_enabled = os.environ.get("RPR_LLM_WEB_SEARCH", "1") != "0"

        if not self.token:
            raise NarrativeEnrichError(
                "No API key/token found. Set RPR_LLM_API_KEY (internal gateway) "
                "or ANTHROPIC_API_KEY (public API) in the environment."
            )

        client_kwargs: dict = {"api_key": self.token}
        if self.base_url:
            client_kwargs["base_url"] = self.base_url
        if self.auth_header.lower() != "x-api-key":
            header_value = self.token
            if self.auth_header.lower() == "authorization" and not header_value.lower().startswith("bearer "):
                header_value = f"Bearer {header_value}"
            client_kwargs["default_headers"] = {self.auth_header: header_value}

        self._client = anthropic.Anthropic(**client_kwargs)

    def call(self, prompt: str) -> str:
        tools = []
        if self.web_search_enabled:
            tools = [{
                "type": "web_search_20250305",
                "name": "web_search",
                "max_uses": WEB_SEARCH_MAX_USES,
            }]

        try:
            response = self._client.messages.create(
                model=self.model,
                max_tokens=MAX_TOKENS,
                messages=[{"role": "user", "content": prompt}],
                tools=tools,
            )
        except anthropic.APIError as exc:
            target = self.base_url or "public Anthropic API"
            raise NarrativeEnrichError(f"LLM call to {target} failed: {exc}") from exc

        text_parts = [
            block.text for block in response.content
            if getattr(block, "type", None) == "text"
        ]
        full_text = "\n".join(text_parts).strip()
        if not full_text:
            raise NarrativeEnrichError("Model returned no text content (tool calls only).")
        return full_text


# ---------------------------------------------------------------------------
# Response parsing — mirrors MarketEventParser's label-splitting method
# ---------------------------------------------------------------------------

def _parse_sections(text: str) -> dict[str, str]:
    matches = list(_LABEL_PATTERN.finditer(text))
    if not matches:
        return {}

    by_title: dict[str, str] = {}
    for i, m in enumerate(matches):
        title = m.group(1).strip().lower()
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = text[start:end].strip()
        by_title[title] = body

    out: dict[str, str] = {}
    for key, title in LABELS:
        val = by_title.get(title.lower(), "")
        if val.strip().lower().startswith(NO_DATA_MARKER):
            val = ""  # normalize the model's explicit marker to empty, so
                      # the frontend's existing red "NO DATA" badge logic
                      # (which checks for emptiness) picks it up correctly
        out[key] = val
    return out


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def enrich_narrative(narrative: str) -> dict:
    """
    Runs the R2D2 enrichment for a single narrative. Returns a flat dict
    with every LABELS key + its SECTION_ALIASES counterpart populated
    (value may be "" for a section with genuinely no data).
    """
    prompt = R2D2_PROMPT.format(
        today=date.today().isoformat(),
        narrative=narrative.replace('"', "'"),
    )

    client = LLMClient()
    log.info(
        "Calling %s (base_url=%s, web_search=%s)…",
        client.model, client.base_url or "public API", client.web_search_enabled,
    )

    raw_text = client.call(prompt)
    sections = _parse_sections(raw_text)

    if not sections:
        log.warning(
            "No labelled sections found in model output — check that the "
            "model followed the 'Title:' format. Raw output preview: %r",
            raw_text[:400],
        )

    out: dict = {}
    for key, _title in LABELS:
        val = sections.get(key, "")
        out[key] = val
        out[SECTION_ALIASES[key]] = val

    n_populated = sum(1 for k, _ in LABELS if out[k])
    log.info("Enrichment parsed — %d/%d sections have content.", n_populated, len(LABELS))

    return out
