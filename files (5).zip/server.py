"""
server.py — FastAPI backend for "ICM PM — AI-assisted Rapid Portfolio Review"

Serves exactly the endpoints the frontend (rpr-step1-test-v2/v3.html) calls
against http://127.0.0.1:8000:

    GET  /health
    POST /api/v1/rpr/market-events/fetch     (Trigger 1 — ADK Market Scanner)
    POST /api/v1/rpr/market-events/refine    (feedback-to-agent loop, NEW)
    POST /api/v1/rpr/step1/enrich            (Trigger 2 — R2D2 narrative enrichment)

Run:
    pip install -r requirements.txt
    $env:ANTHROPIC_API_KEY = "sk-ant-..."      # PowerShell
    uvicorn server:app --host 127.0.0.1 --port 8000 --reload

or just double-click / run start_backend.ps1, which does all of the above.

This file assumes market_event_scout.py (and its own dependency,
web_search_agent.py — your internal ADK web-search module) already exist
in this same directory. It imports MarketEventScout rather than
redefining it.
"""

from __future__ import annotations

import logging
import traceback
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from market_event_scout import MarketEventScout
from narrative_enricher import enrich_narrative, NarrativeEnrichError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("rpr_backend")

app = FastAPI(title="ICM PM Rapid Portfolio Review — Backend", version="1.0")

# The frontend is a local .html file opened via file://, which sends
# `Origin: null`. allow_origins=["*"] covers this (no cookies/credentials
# are used here, so this is safe for a local dev tool).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

scout = MarketEventScout()


# ---------------------------------------------------------------------------
# Request schemas
# ---------------------------------------------------------------------------

class FetchRequest(BaseModel):
    themes: list[str] = Field(default_factory=list)
    max_events_per_theme: int = 3


class RefineRequest(BaseModel):
    event: dict[str, Any]
    feedback: str


class EnrichRequest(BaseModel):
    narrative: str


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/health")
def health():
    try:
        pf = scout.preflight()
    except Exception as exc:  # preflight should never fail, but don't 500 /health for it
        log.warning("preflight() raised: %s", exc)
        pf = {"adk_available": False}
    return {"status": "ok", **pf}


@app.post("/api/v1/rpr/market-events/fetch")
def fetch_market_events(req: FetchRequest):
    themes = [t.strip() for t in req.themes if t and t.strip()]
    if not themes:
        raise HTTPException(400, detail="At least one theme is required.")

    log.info("Fetch — %d theme(s): %s (max_events_per_theme=%d requested)",
              len(themes), themes, req.max_events_per_theme)

    try:
        result = scout.fetch_events(
            themes=themes,
            max_events_per_theme=req.max_events_per_theme,
        )
    except Exception as exc:
        log.error("fetch_events failed: %s", exc)
        log.debug(traceback.format_exc())
        raise HTTPException(500, detail=str(exc)[:300]) from exc

    # Debug aid: log real content length per section so an empty-content
    # bug is visible here, in the terminal, before the frontend even
    # renders it as "NO DATA".
    for ev in result.get("events", []):
        sec_lens = [len((s.get("txt") or "")) for s in ev.get("sections", [])]
        theme_label = ev.get("themeName") or ev.get("theme") or "?"
        log.info(
            "  event id=%s theme=%r failed=%s section_char_counts=%s",
            ev.get("id"), theme_label, ev.get("_search_failed"), sec_lens,
        )
        if ev.get("_search_failed") or all(n == 0 for n in sec_lens):
            log.warning(
                "  -> event id=%s has NO real content. reason=%r raw_preview=%r",
                ev.get("id"), ev.get("_fail_reason"),
                (ev.get("raw_search_result") or "")[:200],
            )

    return result


@app.post("/api/v1/rpr/market-events/refine")
def refine_market_event(req: RefineRequest):
    """
    Backs the "feedback to the agent" loop: re-runs the ADK search for a
    single event with the analyst's steer appended to the query, instead
    of the analyst typing the answer themselves.
    """
    if not req.feedback or not req.feedback.strip():
        raise HTTPException(400, detail="Feedback text is required.")

    log.info("Refine — event id=%s feedback=%r",
              req.event.get("id"), req.feedback[:120])

    try:
        result = scout.refine_event(req.event, req.feedback.strip())
    except Exception as exc:
        log.error("refine_event failed: %s", exc)
        log.debug(traceback.format_exc())
        raise HTTPException(500, detail=str(exc)[:300]) from exc

    return result


@app.post("/api/v1/rpr/step1/enrich")
def enrich_step1(req: EnrichRequest):
    narrative = (req.narrative or "").strip()
    if not narrative:
        raise HTTPException(400, detail="Narrative text is required.")

    log.info("Enrich — narrative=%r", narrative[:160])

    try:
        data = enrich_narrative(narrative)
    except NarrativeEnrichError as exc:
        log.error("Enrichment failed: %s", exc)
        raise HTTPException(502, detail=str(exc)[:300]) from exc
    except Exception as exc:
        log.error("Unexpected enrichment error: %s", exc)
        log.debug(traceback.format_exc())
        raise HTTPException(500, detail=str(exc)[:300]) from exc

    for k, v in data.items():
        if isinstance(v, str):
            log.info("  section %-28s %d chars", k, len(v))

    return data


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("server:app", host="127.0.0.1", port=8000, reload=True)
