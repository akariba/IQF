RPR FAST-SCAN PATCH — v6.2

REPLACE EXISTING
- backend/market_event_scout.py

MANUAL ONE-LINE CHANGE (recommended now)
- backend/web_search_agent.py
  Change the search model back to:
  model=HelixGemini(model="gemini-2.5-flash")

WHY
- The scanner currently allows each ADK search to wait up to 240 seconds.
- Discovery may also perform up to two extra follow-up searches per theme before enrichment.
- With 3 themes this creates unnecessary latency and makes a single slow/cancelled ADK root node block the scan.

PATCH BEHAVIOR
- discovery timeout: 90s
- enrichment timeout: 120s
- refinement timeout: 120s
- discovery follow-up searches: disabled by default
- still requests up to 3 events in the first discovery call
- if fewer than 3 supported events are returned, it accepts fewer rather than doing quota-filling searches
- existing parallel discovery and bounded parallel enrichment are preserved
- schemas, Step-1 evidence logic, prompts, Step-2, and v31 HTML are untouched

OPTIONAL ENV OVERRIDES
RPR_ADK_TIMEOUT_SECONDS=120
RPR_T1_DISCOVERY_TIMEOUT_SECONDS=90
RPR_T1_ENRICH_TIMEOUT_SECONDS=120
RPR_T1_REFINEMENT_TIMEOUT_SECONDS=120
RPR_T1_DISCOVERY_FOLLOWUPS=0
RPR_T1_DISCOVERY_WORKERS=3
RPR_T1_ENRICH_WORKERS=4

DO NOT TOUCH
- v31 HTML baseline
- Step-1 prompts
- Step-2 files
- server.py
- narrative_enricher.py
- theme_assistant.py

After replacing the file and changing the search model, restart uvicorn.
