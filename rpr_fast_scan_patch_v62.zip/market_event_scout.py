"""Trigger-1 Market Scanner: broad theme -> top material events -> 8-section enrichment.

Key changes in this vNext implementation:
- Prompt source is explicitly backend/prompts/trigger1_market_scanner.txt.
- Trigger 1 is treated as broad-theme DISCOVERY, not narrative enrichment.
- Optional two-pass search: discover candidates, then enrich each event independently.
- Deterministic evidence metadata is produced for downstream diagnosis/Step 2.
- Refinement can target only weak sections and keeps the original when quality does not improve.
"""
from __future__ import annotations

import asyncio
import inspect
import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from step1_quality import (
    SECTION_TITLES,
    assess_sections,
    build_machine_payload,
    select_improved_sections,
    overall_retrieval_status,
    parse_sectioned_report,
    strip_control_tags,
    summarize_quality,
)

try:
    from web_search_agent import run_web_search as _adk_run_web_search  # type: ignore
except Exception:  # pragma: no cover - environment-specific
    _adk_run_web_search = None

PROMPT_PATH = Path(__file__).resolve().parent / "prompts" / "trigger1_market_scanner.txt"
DISCOVERY_NORMALIZER_PATH = Path(__file__).resolve().parent / "prompts" / "trigger1_discovery_normalizer.txt"
_SEARCH_TIMEOUT = int(os.environ.get("RPR_ADK_TIMEOUT_SECONDS", "120"))
_DISCOVERY_TIMEOUT = int(os.environ.get("RPR_T1_DISCOVERY_TIMEOUT_SECONDS", "90"))
_ENRICH_TIMEOUT = int(os.environ.get("RPR_T1_ENRICH_TIMEOUT_SECONDS", "120"))
_REFINEMENT_TIMEOUT = int(os.environ.get("RPR_T1_REFINEMENT_TIMEOUT_SECONDS", "120"))
_DISCOVERY_FOLLOWUPS = max(0, min(1, int(os.environ.get("RPR_T1_DISCOVERY_FOLLOWUPS", "0"))))
_PARALLEL_ENRICH = os.environ.get("RPR_T1_PARALLEL", "1").strip().lower() not in {"0", "false", "no"}
_DISCOVERY_WORKERS = max(1, int(os.environ.get("RPR_T1_DISCOVERY_WORKERS", "3")))
_ENRICH_WORKERS = max(1, int(os.environ.get("RPR_T1_ENRICH_WORKERS", "4")))


@dataclass
class CandidateEvent:
    title: str
    event_date: str = ""
    why_material: str = ""
    search_seed: str = ""
    confidence: str = "MEDIUM"


@dataclass
class MarketEvent:
    id: int
    label: str
    subtitle: str
    theme_name: str
    theme_index: int
    sections: List[Dict[str, Any]]
    source_names: str = ""
    horizon: str = "12 months"
    search_failed: bool = False
    fail_reason: str = ""
    executed_query: str = ""
    query_log: List[str] = field(default_factory=list)
    enhancement_meta: Dict[str, Any] = field(default_factory=dict)
    machine_payload: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "event_id": self.id,
            "label": self.label,
            "subtitle": self.subtitle,
            "theme": self.theme_name,
            "theme_name": self.theme_name,
            "theme_index": self.theme_index,
            "sections": self.sections,
            "source": self.source_names,
            "source_names": self.source_names,
            "horizon": self.horizon,
            "search_failed": self.search_failed,
            "fail_reason": self.fail_reason,
            "executed_query": self.executed_query,
            "query_log": self.query_log,
            "enhancement_meta": self.enhancement_meta,
            "machine_payload": self.machine_payload,
        }


def _load_prompt() -> str:
    try:
        return PROMPT_PATH.read_text(encoding="utf-8")
    except Exception as exc:
        raise RuntimeError(f"Trigger-1 prompt not found: {PROMPT_PATH}") from exc


def _load_discovery_normalizer() -> str:
    try:
        return DISCOVERY_NORMALIZER_PATH.read_text(encoding="utf-8")
    except Exception:
        return "Extract only supported distinct events from the supplied discovery output. Return JSON with an events array; add no facts."


def _strip_fences(text: str) -> str:
    t = str(text or "").strip()
    t = re.sub(r"^```(?:json)?\s*", "", t, flags=re.I)
    t = re.sub(r"\s*```$", "", t)
    return t.strip()


def _normalise_search_output(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        for key in ("text", "output", "response", "content", "answer"):
            if isinstance(value.get(key), str):
                return value[key]
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (list, tuple)):
        return "\n".join(_normalise_search_output(x) for x in value)
    return str(value)


def _await_in_new_thread(awaitable: Any, timeout: int) -> Any:
    result: Dict[str, Any] = {}
    error: Dict[str, BaseException] = {}

    def runner() -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result["value"] = loop.run_until_complete(asyncio.wait_for(awaitable, timeout=timeout))
        except BaseException as exc:  # noqa: BLE001
            error["error"] = exc
        finally:
            loop.close()

    th = threading.Thread(target=runner, daemon=True)
    th.start()
    th.join(timeout + 5)
    if th.is_alive():
        raise TimeoutError(f"ADK search exceeded {timeout}s")
    if "error" in error:
        raise error["error"]
    return result.get("value")


def _adk_search_sync(prompt: str, timeout: int = _SEARCH_TIMEOUT) -> str:
    if _adk_run_web_search is None:
        raise RuntimeError("ADK web search is unavailable: web_search_agent.run_web_search could not be imported")
    value = _adk_run_web_search(prompt)
    if inspect.isawaitable(value):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            value = asyncio.run(asyncio.wait_for(value, timeout=timeout))
        else:
            value = _await_in_new_thread(value, timeout)
    text = _normalise_search_output(value).strip()
    if not text:
        raise RuntimeError("ADK web search returned an empty response")
    return text


def _parse_discovery(text: str, limit: int) -> List[CandidateEvent]:
    cleaned = _strip_fences(text)
    obj: Optional[Dict[str, Any]] = None
    try:
        obj = json.loads(cleaned)
    except Exception:
        m = re.search(r"(?s)\{.*\}", cleaned)
        if m:
            try:
                obj = json.loads(m.group(0))
            except Exception:
                obj = None

    out: List[CandidateEvent] = []
    if isinstance(obj, dict) and isinstance(obj.get("events"), list):
        for raw in obj["events"]:
            if not isinstance(raw, dict):
                continue
            title = str(raw.get("title") or raw.get("event") or "").strip()
            if not title:
                continue
            out.append(CandidateEvent(
                title=title,
                event_date=str(raw.get("event_date") or "").strip(),
                why_material=str(raw.get("why_material") or raw.get("rationale") or "").strip(),
                search_seed=str(raw.get("search_seed") or title).strip(),
                confidence=str(raw.get("confidence") or "MEDIUM").upper(),
            ))
            if len(out) >= limit:
                break
    if out:
        return out

    # Conservative fallback for non-JSON model output.
    for line in cleaned.splitlines():
        m = re.match(r"^\s*(?:\d+[.)]|[-*])\s*(.+?)\s*$", line)
        if not m:
            continue
        title = re.sub(r"\s*[—–:-]\s*(?:why|material|rationale).*", "", m.group(1), flags=re.I).strip()
        if 8 <= len(title) <= 180:
            out.append(CandidateEvent(title=title, search_seed=title, confidence="LOW"))
            if len(out) >= limit:
                break
    return out


def _normalize_discovery_with_llm(
    *,
    raw_discovery: str,
    theme: str,
    description: str,
    limit: int,
) -> List[CandidateEvent]:
    """Normalize non-JSON ADK discovery output without inventing new events.

    This is a compatibility layer for shared web-search agents whose presentation format
    is not guaranteed to be JSON. The web research remains Gemini/ADK; the LLM gateway
    may only extract/rank events already present in that research result.
    """
    try:
        from llm_gateway import get_gateway  # type: ignore

        gateway = get_gateway()
        if not hasattr(gateway, "call_text"):
            return []
        payload = {
            "theme": theme,
            "description": description,
            "requested_event_count": limit,
            "enterprise_web_discovery_output": str(raw_discovery or "")[:18000],
        }
        raw = str(gateway.call_text(
            system_prompt=_load_discovery_normalizer(),
            user_prompt=json.dumps(payload, ensure_ascii=False),
            max_tokens=1600,
        ) or "").strip()
        return _parse_discovery(raw, limit)
    except Exception:
        return []


def _source_names_from_meta(section_meta: Sequence[Dict[str, Any]]) -> str:
    names = sorted({n for m in section_meta for n in (m.get("source_names") or []) if n})
    return ", ".join(names)


def _clean_sections(parsed_sections: Sequence[Dict[str, Any]], retrieval_status: str = "SUCCESS") -> List[Dict[str, Any]]:
    """Normalize parsed model output while keeping technical retrieval status backend-owned."""
    out: List[Dict[str, Any]] = []
    for i, title in enumerate(SECTION_TITLES):
        s = parsed_sections[i] if i < len(parsed_sections) else {}
        out.append({
            "num": i + 1,
            "title": title,
            "txt": strip_control_tags(str(s.get("txt", s.get("text", "")) or "")),
            "retrieval_status": retrieval_status,
            "model_evidence_tier": s.get("model_evidence_tier"),
            "model_retrieval_status": s.get("model_retrieval_status"),
            "source_evidence": list(s.get("source_evidence") or []) if isinstance(s.get("source_evidence"), list) else [],
        })
    return out


class MarketEventScout:
    def __init__(self) -> None:
        self.prompt = _load_prompt()

    def preflight(self) -> Dict[str, Any]:
        return {
            "ok": _adk_run_web_search is not None,
            "adk_available": _adk_run_web_search is not None,
            "prompt_path": str(PROMPT_PATH),
            "scanner_mode": "discovery_then_independent_enrichment",
            "parallel_enrichment": _PARALLEL_ENRICH,
        }

    def _discover_candidates(self, theme: str, description: str, max_events: int) -> List[CandidateEvent]:
        now = datetime.now(timezone.utc).isoformat()
        runtime = f"""

# RUNTIME
MODE: DISCOVERY
REPORT_AS_OF: {now}
REQUESTED_EVENT_COUNT: {max_events}
BROAD_THEME: {theme}
THEME_DESCRIPTION: {description or 'None supplied'}

Execute DISCOVERY MODE only. Return JSON only. Find up to {max_events} distinct, strongest evidence-supported material events for this broad theme, ordered strongest first. Use the description as scope/context only; verify any factual assertions independently.
"""
        raw = _adk_search_sync(self.prompt + runtime, timeout=_DISCOVERY_TIMEOUT)
        candidates = _parse_discovery(raw, max_events)
        if not candidates:
            candidates = _normalize_discovery_with_llm(
                raw_discovery=raw,
                theme=theme,
                description=description,
                limit=max_events,
            )

        # Shared enterprise-search agents may occasionally return only one strong event even
        # when the discovery prompt asks for three. Fill the remaining slots with up to two
        # targeted follow-up searches, explicitly excluding already-found events. Every new
        # candidate still has to be present in the new Gemini/ADK research output.
        seen = {re.sub(r"\W+", " ", c.title.lower()).strip() for c in candidates}
        follow_up_round = 0
        while len(candidates) < max_events and follow_up_round < _DISCOVERY_FOLLOWUPS:
            follow_up_round += 1
            excluded = [c.title for c in candidates]
            follow_runtime = f"""

# RUNTIME
MODE: DISCOVERY
REPORT_AS_OF: {now}
REQUESTED_EVENT_COUNT: {max_events - len(candidates)}
BROAD_THEME: {theme}
THEME_DESCRIPTION: {description or 'None supplied'}
EXCLUDE_ALREADY_SELECTED_EVENTS: {json.dumps(excluded, ensure_ascii=False)}

Find additional distinct recent material events for the same theme. Do not repeat or rephrase the excluded events. Return JSON only using the DISCOVERY MODE contract.
"""
            follow_raw = _adk_search_sync(self.prompt + follow_runtime, timeout=_DISCOVERY_TIMEOUT)
            extra = _parse_discovery(follow_raw, max_events - len(candidates))
            if not extra:
                extra = _normalize_discovery_with_llm(
                    raw_discovery=follow_raw,
                    theme=theme,
                    description=description,
                    limit=max_events - len(candidates),
                )
            added = 0
            for cand in extra:
                key = re.sub(r"\W+", " ", cand.title.lower()).strip()
                if not key or key in seen:
                    continue
                seen.add(key)
                candidates.append(cand)
                added += 1
                if len(candidates) >= max_events:
                    break
            if added == 0:
                break
        return candidates[:max_events]

    def _enrich_candidate(self, theme: str, description: str, candidate: CandidateEvent, theme_index: int, event_id: int) -> MarketEvent:
        now = datetime.now(timezone.utc).isoformat()
        runtime = f"""

# RUNTIME
MODE: ENRICHMENT
REPORT_AS_OF: {now}
PARENT_THEME: {theme}
THEME_DESCRIPTION: {description or 'None supplied'}
SELECTED_EVENT: {candidate.title}
EVENT_DATE_HINT: {candidate.event_date}
DISCOVERY_RATIONALE: {candidate.why_material}
SEARCH_SEED: {candidate.search_seed or candidate.title}

Execute ENRICHMENT MODE only. Research this selected event deeply and return the exact eight-section contract.
"""
        try:
            raw = _adk_search_sync(self.prompt + runtime, timeout=_ENRICH_TIMEOUT)
            parsed = parse_sectioned_report(raw)
            sections = _clean_sections(parsed["sections"], retrieval_status="SUCCESS")
            section_meta = assess_sections(sections)
            quality = summarize_quality(section_meta)
            retrieval_status = overall_retrieval_status(section_meta)
            parsed_queries = [str(q).strip() for q in (parsed.get("search_queries") or []) if str(q).strip()]
            queries = parsed_queries or [candidate.search_seed or candidate.title]
            query_log_source = "model_reported_search_formulations" if parsed_queries else "search_instruction"
            event_info = {
                "title": candidate.title,
                "event_date": candidate.event_date,
                "theme": theme,
                "why_material": candidate.why_material,
                "confidence": candidate.confidence,
            }
            machine_payload = build_machine_payload(
                trigger="trigger1",
                sections=sections,
                event=event_info,
                query_log=queries,
                query_log_source=query_log_source,
                model_metadata=parsed.get("machine_metadata") or {},
            )
            enhancement_meta = {
                "retrieval_failure": retrieval_status == "TECHNICAL_FAILURE",
                "retrieval_status": retrieval_status,
                "section_meta": section_meta,
                "quality": quality,
                "executed_query": " | ".join(queries),
                "query_log": queries,
                "query_log_source": query_log_source,
                "machine_payload": machine_payload,
            }
            return MarketEvent(
                id=event_id,
                label=f"Event {event_id}",
                subtitle=candidate.title,
                theme_name=theme,
                theme_index=theme_index,
                sections=sections,
                source_names=_source_names_from_meta(section_meta),
                executed_query=" | ".join(queries),
                query_log=list(queries),
                enhancement_meta=enhancement_meta,
                machine_payload=machine_payload,
            )
        except Exception as exc:
            sections = [
                {"num": i + 1, "title": title, "txt": "", "retrieval_status": "TECHNICAL_FAILURE"}
                for i, title in enumerate(SECTION_TITLES)
            ]
            section_meta = assess_sections(sections, default_retrieval_status="TECHNICAL_FAILURE")
            return MarketEvent(
                id=event_id,
                label=f"Event {event_id}",
                subtitle=candidate.title,
                theme_name=theme,
                theme_index=theme_index,
                sections=sections,
                search_failed=True,
                fail_reason=str(exc),
                executed_query=candidate.search_seed or candidate.title,
                query_log=[candidate.search_seed or candidate.title],
                enhancement_meta={
                    "retrieval_failure": True,
                    "retrieval_status": "TECHNICAL_FAILURE",
                    "section_meta": section_meta,
                    "quality": summarize_quality(section_meta),
                    "executed_query": candidate.search_seed or candidate.title,
                    "query_log": [candidate.search_seed or candidate.title],
                    "query_log_source": "search_instruction",
                },
            )

    def fetch_events(self, themes: Sequence[Any], max_events_per_theme: int = 3) -> Dict[str, Any]:
        """Discover and enrich events with bounded cross-theme concurrency.

        v6 initially processed themes sequentially. With three themes that meant roughly:
        discovery(theme1)+enrich(theme1) -> discovery(theme2)+enrich(theme2) -> ...,
        which can exceed the UI's five-minute request budget even when every upstream call
        succeeds.  This implementation preserves deterministic theme/event ordering while:
        1) discovering candidate events for independent themes concurrently; and
        2) enriching all discovered events in one bounded worker pool.

        The worker counts are deliberately bounded/configurable so the internal ADK gateway
        is not flooded.  The browser timeout remains only a safety ceiling, not the primary
        performance mechanism.
        """
        started = time.monotonic()
        theme_specs: List[Dict[str, Any]] = []
        for theme_index, item in enumerate(themes):
            if isinstance(item, dict):
                theme = str(item.get("theme") or item.get("name") or "").strip()
                description = str(item.get("description") or item.get("narr") or "").strip()
            else:
                theme = str(item or "").strip()
                description = ""
            if theme:
                theme_specs.append({"theme": theme, "description": description, "theme_index": theme_index})
        if not theme_specs:
            raise ValueError("At least one theme is required")
        max_events = max(1, min(int(max_events_per_theme or 3), 3))

        warnings: List[str] = []
        discovery_started = time.monotonic()
        candidates_by_index: Dict[int, List[CandidateEvent]] = {}

        def discover(spec: Dict[str, Any]) -> tuple[int, List[CandidateEvent], Optional[str]]:
            idx = int(spec["theme_index"])
            try:
                found = self._discover_candidates(spec["theme"], spec["description"], max_events)
                return idx, found, None
            except Exception as exc:  # keep one theme failure isolated from the others
                return idx, [], str(exc)

        if len(theme_specs) > 1:
            workers = min(_DISCOVERY_WORKERS, len(theme_specs))
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futs = {pool.submit(discover, spec): spec for spec in theme_specs}
                for fut in as_completed(futs):
                    idx, found, error = fut.result()
                    candidates_by_index[idx] = found
                    if error:
                        spec = futs[fut]
                        warnings.append(f"Discovery failed for '{spec['theme']}': {error}")
        else:
            idx, found, error = discover(theme_specs[0])
            candidates_by_index[idx] = found
            if error:
                warnings.append(f"Discovery failed for '{theme_specs[0]['theme']}': {error}")

        discovery_seconds = round(time.monotonic() - discovery_started, 3)

        # Build jobs in analyst/theme order so integer event IDs remain deterministic even
        # though the actual enrichment calls complete out of order.
        jobs: List[tuple[int, Dict[str, Any], CandidateEvent, int]] = []
        next_id = 1
        for spec in theme_specs:
            idx = int(spec["theme_index"])
            candidates = candidates_by_index.get(idx, [])
            if not candidates:
                warnings.append(
                    f"No supported discovery candidates for '{spec['theme']}'; no event was created because Step 1 must not invent or reinterpret a broad theme as a specific event."
                )
                continue
            for cand in candidates[:max_events]:
                jobs.append((idx, spec, cand, next_id))
                next_id += 1

        enrichment_started = time.monotonic()
        event_by_id: Dict[int, MarketEvent] = {}

        def enrich(job: tuple[int, Dict[str, Any], CandidateEvent, int]) -> MarketEvent:
            idx, spec, cand, event_id = job
            return self._enrich_candidate(
                spec["theme"], spec["description"], cand, idx, event_id
            )

        if _PARALLEL_ENRICH and len(jobs) > 1:
            workers = min(_ENRICH_WORKERS, len(jobs))
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futs = {pool.submit(enrich, job): job for job in jobs}
                for fut in as_completed(futs):
                    ev = fut.result()
                    event_by_id[ev.id] = ev
        else:
            for job in jobs:
                ev = enrich(job)
                event_by_id[ev.id] = ev

        enrichment_seconds = round(time.monotonic() - enrichment_started, 3)
        events = [event_by_id[event_id] for event_id in sorted(event_by_id)]

        sources_seen = sorted({
            name.strip()
            for ev in events
            for name in (ev.source_names or "").split(",")
            if name.strip()
        })
        total_seconds = round(time.monotonic() - started, 3)
        return {
            "events": [e.to_dict() for e in events],
            "themes": [x["theme"] for x in theme_specs],
            "theme_inputs": [{"theme": x["theme"], "description": x["description"]} for x in theme_specs],
            "source": "ADK Gemini enterprise web search",
            "sources_seen": sources_seen,
            "total": len(events),
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
            "warnings": warnings,
            "scanner_mode": "parallel_discovery_then_bounded_parallel_enrichment",
            "scan_timing": {
                "discovery_seconds": discovery_seconds,
                "enrichment_seconds": enrichment_seconds,
                "total_seconds": total_seconds,
                "discovery_workers": min(_DISCOVERY_WORKERS, max(1, len(theme_specs))),
                "enrichment_workers": min(_ENRICH_WORKERS, max(1, len(jobs))) if jobs else 0,
            },
        }

    def refine_event(
        self,
        event: Dict[str, Any],
        feedback: str,
        affected_sections: Optional[Sequence[str]] = None,
        analyst_modified_sections: Optional[Sequence[str]] = None,
    ) -> Dict[str, Any]:
        if not str(feedback or "").strip():
            raise ValueError("Feedback/refinement guidance is required")
        affected = [s for s in (affected_sections or []) if s in SECTION_TITLES]
        if not affected:
            affected = list(SECTION_TITLES)

        original_sections = event.get("sections") or []
        before_meta = assess_sections(original_sections)
        theme = str(event.get("theme_name") or event.get("theme") or "").strip()
        title = str(event.get("subtitle") or event.get("label") or "Market event").strip()
        now = datetime.now(timezone.utc).isoformat()
        runtime = f"""

# RUNTIME
MODE: TARGETED_REFINEMENT
REPORT_AS_OF: {now}
PARENT_THEME: {theme}
SELECTED_EVENT: {title}
AFFECTED_SECTIONS: {json.dumps(affected, ensure_ascii=False)}
ANALYST_APPROVED_REFINEMENT_GUIDANCE: {feedback}

Execute TARGETED_REFINEMENT MODE only. Re-search only the named affected sections. Return only those section labels plus Search Queries Used and optional MACHINE_METADATA.
"""
        raw = _adk_search_sync(self.prompt + runtime, timeout=_REFINEMENT_TIMEOUT)
        parsed = parse_sectioned_report(raw)
        candidate_sections = _clean_sections(parsed["sections"], retrieval_status="SUCCESS")
        final_sections, comparison = select_improved_sections(original_sections, candidate_sections, affected)
        modified_before = {s for s in (analyst_modified_sections or []) if s in SECTION_TITLES}
        accepted = set(comparison.get("accepted_sections") or [])
        final_modified = sorted(modified_before - accepted, key=lambda x: SECTION_TITLES.index(x))
        final_meta = assess_sections(final_sections)
        final_retrieval_status = overall_retrieval_status(final_meta)
        original_retained = bool(comparison.get("original_retained"))
        parsed_queries = [str(q).strip() for q in (parsed.get("search_queries") or []) if str(q).strip()]
        queries = parsed_queries or [str(feedback).strip()]
        query_log_source = "model_reported_search_formulations" if parsed_queries else "analyst_approved_search_instruction"
        machine_payload = build_machine_payload(
            trigger="trigger1",
            sections=final_sections,
            event={"title": title, "theme": theme},
            query_log=queries,
            query_log_source=query_log_source,
            model_metadata=(parsed.get("machine_metadata") or {}) if not final_modified else {},
        )
        machine_payload["analyst_state"] = {
            "confirmed": False,
            "modified_sections": final_modified,
            "structured_model_metadata_reused": not bool(final_modified),
        }
        result = {
            "id": int(event.get("id") or event.get("event_id") or 0),
            "event_id": int(event.get("id") or event.get("event_id") or 0),
            "label": str(event.get("label") or "Event"),
            "subtitle": title,
            "theme": theme,
            "theme_name": theme,
            "theme_index": event.get("theme_index"),
            "horizon": event.get("horizon") or "12 months",
            "sections": final_sections,
            "source_names": _source_names_from_meta(final_meta),
            "executed_query": " | ".join(queries),
            "query_log": queries,
            "enhancement_meta": {
                "retrieval_failure": final_retrieval_status == "TECHNICAL_FAILURE",
                "retrieval_status": final_retrieval_status,
                "section_meta": final_meta,
                "quality": summarize_quality(final_meta),
                "executed_query": " | ".join(queries),
                "query_log": queries,
                "query_log_source": query_log_source,
                "machine_payload": machine_payload,
            },
            "machine_payload": machine_payload,
            "rescan_result": {
                **comparison,
                "original_retained": original_retained,
                "guidance": str(feedback).strip(),
            },
        }
        return result
