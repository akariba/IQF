import sys
from pathlib import Path
import pytest

BACKEND = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND))

# Stub llm_gateway before importing service so local validation does not need the internal package.
import types
stub = types.ModuleType("llm_gateway")
stub.get_gateway = lambda: object()
sys.modules["llm_gateway"] = stub

import step2_service as s

STEP1 = {
    "event_overview": "Confirmed event overview",
    "credit_market_impact": "Confirmed credit evidence",
    "assumptions": "Step-1 source caveats",
}


def scenario_obj():
    return {
        "scenario_narrative": "A structural scenario over the requested horizon.",
        "assessment_horizon": "12 months",
        "assumptions": [
            {
                "code": f"A{i}", "type": "Macro Backdrop",
                "quantified_or_bounded_value": "bounded", "rationale": "test",
                "horizon": "12 months", "direction": "MIXED", "origin": "STEP1_DERIVED",
                "source_reference": None, "confidence": "MEDIUM", "observed_vs_assumed": "ASSUMPTION",
            }
            for i in range(1, 5)
        ],
    }


def test_no_optional_context_bypasses_assessor():
    r = s.assess_optional_context(STEP1, "12 months")
    assert r["overall_decision"] == "STEP1_HORIZON_ONLY"
    assert r["assessor_bypassed"] is True
    assert r["curated_context"] == []


def test_weak_upload_does_not_override_step1():
    r = s.assess_optional_context(
        STEP1, "12 months",
        uploaded_contexts=[{"file_name":"weak.txt","extraction_status":"SUCCESS","extracted_text":"too short"}],
    )
    assert r["overall_decision"] == "STEP1_HORIZON_ONLY"
    assert r["uploaded_contexts"][0]["status"] == "INSUFFICIENT_QUALITY"


def test_context_assessor_curates_relevant_input(monkeypatch):
    def fake_call(system_prompt, payload, model, max_tokens=5000):
        assert payload["CONFIRMED_STEP1"]["event_overview"] == "Confirmed event overview"
        return {
            "overall_decision":"USE_OPTIONAL_CONTEXT",
            "typed_context":{"status":"USE","role":"SCENARIO_CONSTRAINT","reason":"relevant","usable_items":["Assume refinancing stress persists"],"excluded_items":[]},
            "uploaded_contexts":[],"conflicts":[],
            "curated_context":[{"text":"Assume refinancing stress persists","origin":"TYPED_CONTEXT","source_name":"typed context","role":"SCENARIO_CONSTRAINT"}],
            "limitations":[],
        }
    monkeypatch.setattr(s, "_call_json", fake_call)
    r = s.assess_optional_context(STEP1, "12 months", "Assume refinancing stress persists")
    assert r["curated_context"][0]["role"] == "SCENARIO_CONSTRAINT"


def test_scenario_generation_uses_curated_context(monkeypatch):
    monkeypatch.setattr(s, "assess_optional_context", lambda *a, **k: {
        "overall_decision":"USE_OPTIONAL_CONTEXT",
        "curated_context":[{"text":"test constraint","origin":"TYPED_CONTEXT","source_name":"typed context","role":"SCENARIO_CONSTRAINT"}],
        "limitations":[],
    })
    def fake_call(system_prompt, payload, model, max_tokens=5000):
        assert payload["CURATED_OPTIONAL_CONTEXT"][0]["text"] == "test constraint"
        return scenario_obj()
    monkeypatch.setattr(s, "_call_json", fake_call)
    r = s.generate_scenario(STEP1, "12 months", "context")
    assert len(r["assumptions"]) == 4
    assert r["state"] == "AI_PROPOSAL"


def test_finalize_creates_downstream_gate():
    r = s.finalize_scenario(scenario_obj(), ["scenario_narrative"])
    assert r["state"] == "CONFIRMED"
    assert r["confirmed_for_downstream"] is True
    assert r["analyst_modified_fields"] == ["scenario_narrative"]


def test_feedback_assistant_does_not_execute(monkeypatch):
    monkeypatch.setattr(s, "_call_json", lambda *a, **k: {
        "decision":"NEEDS_REFINEMENT", "reason":"Too vague",
        "suggested_feedback":"Increase refinancing stress only.", "target_dimensions":["A2"],
        "preserve_unaffected_content":True,
    })
    r = s.assist_feedback(STEP1, "12 months", scenario_obj(), "make it worse")
    assert r["decision"] == "NEEDS_REFINEMENT"
    assert "refinancing" in r["suggested_feedback"].lower()


def test_event_factor_weights_are_deterministic(monkeypatch):
    base = scenario_obj(); base["state"] = "CONFIRMED"; base["confirmed_for_downstream"] = True
    factors = []
    for i, imp in enumerate(["HIGH","HIGH","MEDIUM","MEDIUM"], start=1):
        factors.append({
            "factor_id":f"RF{i}", "name":f"Factor {i}", "importance":imp,
            "one_line_rationale":"x", "narrative":"x", "vulnerability_metrics":[],
            "critical_threshold":{"logic":"AND","conditions":["c1","c2"]},
            "buffer_metrics":[], "scoring_rationale":"x",
        })
    monkeypatch.setattr(s, "_call_json", lambda *a, **k: {"factors":factors,"industry_sensitivity":[],"methodology_limitations":[]})
    r = s.generate_event_factors(STEP1, base, "Software", {})
    assert r["weights_sum_pct"] == 100.0
    assert [x["importance_score"] for x in r["factors"]] == [2,2,1,1]
    assert [x["weight_pct"] for x in r["factors"]] == [33.33,33.33,16.67,16.67]


def test_step23_rejects_unconfirmed_scenario():
    with pytest.raises(s.Step2Error):
        s.generate_event_factors(STEP1, scenario_obj(), "Software", {})
