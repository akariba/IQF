import sys
from pathlib import Path
import pytest

BACKEND = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND))

from step2_uploads import extract_context_file, UploadExtractionError


def test_txt_extracts_and_hashes():
    r = extract_context_file("context.txt", b"Assume refinancing markets remain selective for 18 months.")
    assert r["extraction_status"] == "SUCCESS"
    assert "refinancing" in r["extracted_text"]
    assert len(r["sha256"]) == 64


def test_csv_extracts_bounded_rows():
    r = extract_context_file("assumptions.csv", b"metric,value\nGDP,-1.0%\nSpread,+150bps\n")
    assert "GDP | -1.0%" in r["extracted_text"]


def test_unsupported_extension_fails():
    with pytest.raises(UploadExtractionError):
        extract_context_file("bad.exe", b"abc")


def test_legacy_doc_fails_clearly():
    with pytest.raises(UploadExtractionError) as exc:
        extract_context_file("legacy.doc", b"abc")
    assert "Convert to DOCX or PDF" in str(exc.value)
