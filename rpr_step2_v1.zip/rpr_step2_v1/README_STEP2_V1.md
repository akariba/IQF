# RPR Step 2 v1 — Scenario Quality + Feedback + Event Factors

This package adds a governed Step 2.1 / Step 2.3 test path without overwriting the working full workflow.

## Step 2.1 hierarchy

1. Confirmed Step-1 narrative — factual anchor.
2. Assessment horizon — mandatory.
3. Typed analyst context — optional forward-looking constraint/context.
4. Uploaded context — optional supplemental material.

If no optional context is supplied, the context assessor is bypassed and Step 1 + horizon go directly to scenario generation.

If optional context is supplied, Sonnet assesses relevance and extracts only usable items. Weak, irrelevant or conflicting material is excluded rather than allowed to degrade Step 1.

Claude Opus 4.6 generates the forward-looking scenario and 4-7 assumptions.

## Feedback

Sonnet first assists/validates feedback. The analyst reviews or edits it. Only confirmed feedback is sent to Opus for a targeted revision. Unaffected assumptions are preserved.

## Step 2.3

The manager V7 methodology is split cleanly: scenario construction stays in Step 2.1; event-driven factor methodology stays in Step 2.3.

Step 2.3 generates 4-6 factors, metrics, buffers and multi-condition AND thresholds. The LLM does not calculate exact weights. Backend code maps HIGH=2 / MEDIUM=1 and normalizes weights to 100% deterministically.

## Why additive

The exact current full-workflow HTML/runtime source was not available as an editable source file in this turn. Replacing it from screenshots would be unsafe. Test these endpoints first; then wire the approved existing UI to them with no visual redesign.
