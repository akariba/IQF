"""Governed Step 2.1 / Step 2.3 service for RPR.

Additive by design: this module does not replace the current RPRService until live tests pass.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from llm_gateway import get_gateway

PROMPT_DIR = Path(__file__).resolve().parent / "prompts"
MODEL_SONNET = os.environ.get("STEP2_SONNET_MODEL", "claude-sonnet-4-6")
MODEL_OPUS = os.environ.get("STEP2_OPUS_MODEL", "claude-opus-4-6")
_ASSUMPTION_DIRECTIONS = {"HEADWIND", "TAILWIND", "MIXED", "NEUTRAL"}
_IMPORTANCE_SCORE = {"HIGH": 2, "MEDIUM": 1}


class Step2Error(RuntimeError):
    pass


def _load_prompt(name: str) -> str:
    path = PROMPT_DIR / name
    if not path.exists():
        raise Step2Error(f"Required Step-2 prompt is missing: {path}")
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        raise Step2Error(f"Required Step-2 prompt is empty: {path}")
    return text


def _gateway_for_model(model: str):
    gw = get_gateway()
    # Current R2D2LLMGateway stores model on the instance. Instance-level routing avoids
    # mutating process-wide R2D2_MODEL and therefore avoids cross-request model races.
    if hasattr(gw, "_model"):
        gw._model = model
    return gw


def _call_json(system_prompt: str, user_payload: Dict[str, Any], model: str, max_tokens: int = 5000) -> Dict[str, Any]:
    gw = _gateway_for_model(model)
    if not hasattr(gw, "call_raw"):
        raise Step2Error("Prompt-oriented Step-2 calls require the R2D2 gateway.")
    result = gw.call_raw(
        system_prompt,
        json.dumps(user_payload, ensure_ascii=False, indent=2),
        max_tokens=max_tokens,
    )
    if not isinstance(result, dict):
        raise Step2Error("Step-2 model response must be a JSON object.")
    return result


def _compact_step1(step1: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(step1, dict) or not step1:
        raise Step2Error("Confirmed Step-1 payload is required.")
    keep: Dict[str, Any] = {}
    keys = (
        "event_overview", "event_history", "direct_impact_geographies",
        "contagion_impact_geographies", "contagious_impact_geographies",
        "equity_market_impact", "credit_market_impact", "commodity_market_impact",
        "assumptions", "scenario_label", "event_summary", "history", "direct_impact",
        "contagion_impact", "equity_impact", "credit_impact", "commodity_impact",
        "machine_payload", "analyst_state", "trigger", "theme", "event",
    )
    for key in keys:
        if key in step1:
            keep[key] = step1[key]
    return keep or dict(step1)


def _clean_uploads(uploaded_contexts: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for item in uploaded_contexts or []:
        if not isinstance(item, dict):
            continue
        text = str(item.get("extracted_text") or item.get("text") or "").strip()
        status = str(item.get("extraction_status") or "SUCCESS").upper()
        if status != "SUCCESS" or not text:
            continue
        out.append({
            "file_name": str(item.get("file_name") or "uploaded_context"),
            "file_type": str(item.get("file_type") or ""),
            "size_bytes": item.get("size_bytes"),
            "sha256": item.get("sha256"),
            "extracted_text": text[:16000],
            "page_or_sheet_refs": item.get("page_or_sheet_refs") or [],
            "warnings": item.get("warnings") or [],
        })
    return out


def assess_optional_context(
    confirmed_step1: Dict[str, Any],
    horizon: str,
    typed_context: str = "",
    uploaded_contexts: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    step1 = _compact_step1(confirmed_step1)
    horizon = str(horizon or "").strip()
    if not horizon:
        raise Step2Error("Assessment horizon is required.")

    typed = str(typed_context or "").strip()
    uploads = _clean_uploads(uploaded_contexts)

    # Default path requested by business: Step 1 + horizon only. No unnecessary extra call.
    if not typed and not uploads:
        return {
            "overall_decision": "STEP1_HORIZON_ONLY",
            "typed_context": {"status": "NOT_PROVIDED", "role": None, "reason": "No typed context provided.", "usable_items": [], "excluded_items": []},
            "uploaded_contexts": [], "conflicts": [], "curated_context": [], "limitations": [],
            "assessor_bypassed": True,
        }

    usable_uploads: List[Dict[str, Any]] = []
    preexcluded: List[Dict[str, Any]] = []
    for upload in uploads:
        if len(upload["extracted_text"]) < 40:
            preexcluded.append({
                "file_name": upload["file_name"], "status": "INSUFFICIENT_QUALITY",
                "reason": "Extracted content is too short to provide meaningful scenario context.",
                "usable_items": [], "excluded_items": [{"text": upload["extracted_text"], "reason": "Too little usable content."}],
            })
        else:
            usable_uploads.append(upload)

    if not typed and not usable_uploads:
        return {
            "overall_decision": "STEP1_HORIZON_ONLY",
            "typed_context": {"status": "NOT_PROVIDED", "role": None, "reason": "No typed context provided.", "usable_items": [], "excluded_items": []},
            "uploaded_contexts": preexcluded, "conflicts": [], "curated_context": [],
            "limitations": ["Optional uploaded context was not strong enough to use."],
            "assessor_bypassed": True,
        }

    payload = {
        "CONFIRMED_STEP1": step1,
        "ASSESSMENT_HORIZON": horizon,
        "TYPED_CONTEXT": typed or None,
        "UPLOADED_CONTEXTS": usable_uploads,
    }
    try:
        result = _call_json(_load_prompt("step2_context_assessor.txt"), payload, MODEL_SONNET, max_tokens=4500)
    except Exception as exc:
        # Quality-preserving fallback: optional context can fail without degrading the strong anchor.
        return {
            "overall_decision": "STEP1_HORIZON_ONLY",
            "typed_context": {
                "status": "INSUFFICIENT_QUALITY" if typed else "NOT_PROVIDED", "role": None,
                "reason": "Optional-context assessment did not complete; context was not applied.",
                "usable_items": [], "excluded_items": [],
            },
            "uploaded_contexts": preexcluded + [{
                "file_name": u["file_name"], "status": "INSUFFICIENT_QUALITY",
                "reason": "Optional-context assessment did not complete; file was not applied.",
                "usable_items": [], "excluded_items": [],
            } for u in usable_uploads],
            "conflicts": [], "curated_context": [],
            "limitations": [f"Context assessor fallback used: {type(exc).__name__}"],
            "assessor_bypassed": False, "assessor_fallback": True,
        }

    if not isinstance(result.get("curated_context"), list):
        result["curated_context"] = []
    result["uploaded_contexts"] = (result.get("uploaded_contexts") or []) + preexcluded
    result["assessor_bypassed"] = False
    return result


def _validate_scenario(result: Dict[str, Any], horizon: str) -> Dict[str, Any]:
    narrative = str(result.get("scenario_narrative") or "").strip()
    assumptions = result.get("assumptions")
    if not narrative:
        raise Step2Error("Scenario response is missing scenario_narrative.")
    if not isinstance(assumptions, list) or not (4 <= len(assumptions) <= 7):
        raise Step2Error("Scenario must contain 4-7 assumptions.")

    normalized = []
    for i, assumption in enumerate(assumptions, start=1):
        if not isinstance(assumption, dict):
            raise Step2Error(f"Assumption {i} is not an object.")
        a = dict(assumption)
        a["code"] = str(a.get("code") or f"A{i}")
        a["type"] = str(a.get("type") or "Other")
        a["quantified_or_bounded_value"] = str(a.get("quantified_or_bounded_value") or a.get("value") or "")
        a["rationale"] = str(a.get("rationale") or "")
        a["horizon"] = str(a.get("horizon") or horizon)
        direction = str(a.get("direction") or "MIXED").upper()
        a["direction"] = direction if direction in _ASSUMPTION_DIRECTIONS else "MIXED"
        a["origin"] = str(a.get("origin") or "SYNTHESIZED_FROM_ACCEPTED_INPUTS")
        a["source_reference"] = a.get("source_reference")
        confidence = str(a.get("confidence") or "MEDIUM").upper()
        a["confidence"] = confidence if confidence in {"HIGH", "MEDIUM", "LOW"} else "MEDIUM"
        a["observed_vs_assumed"] = "ASSUMPTION"
        normalized.append(a)

    result["scenario_narrative"] = narrative
    result["assessment_horizon"] = str(result.get("assessment_horizon") or horizon)
    result["assumptions"] = normalized
    result.setdefault("structural_headwinds", [])
    result.setdefault("structural_tailwinds_or_adaptations", [])
    result.setdefault("beneficiary_or_resilient_segments", [])
    result.setdefault("limitations", [])
    return result


def generate_scenario(
    confirmed_step1: Dict[str, Any], horizon: str, typed_context: str = "",
    uploaded_contexts: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    step1 = _compact_step1(confirmed_step1)
    horizon = str(horizon or "").strip()
    if not horizon:
        raise Step2Error("Assessment horizon is required.")
    context_assessment = assess_optional_context(step1, horizon, typed_context, uploaded_contexts)
    payload = {
        "CONFIRMED_STEP1": step1,
        "ASSESSMENT_HORIZON": horizon,
        "CURATED_OPTIONAL_CONTEXT": context_assessment.get("curated_context") or [],
        "CONTEXT_LIMITATIONS": context_assessment.get("limitations") or [],
    }
    result = _call_json(_load_prompt("step2_scenario.txt"), payload, MODEL_OPUS, max_tokens=6000)
    result = _validate_scenario(result, horizon)
    result["context_assessment"] = context_assessment
    result["model_path"] = MODEL_OPUS
    result["prompt_version"] = "step2_scenario_v1"
    result["state"] = "AI_PROPOSAL"
    return result


def assist_feedback(
    confirmed_step1: Dict[str, Any], horizon: str, current_scenario: Dict[str, Any], feedback: str,
) -> Dict[str, Any]:
    text = str(feedback or "").strip()
    if not text:
        raise Step2Error("Feedback is required.")
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "ASSESSMENT_HORIZON": str(horizon or "").strip(),
        "CURRENT_SCENARIO": current_scenario,
        "ANALYST_FEEDBACK": text,
    }
    result = _call_json(_load_prompt("step2_feedback_assistant.txt"), payload, MODEL_SONNET, max_tokens=2500)
    decision = str(result.get("decision") or "NEEDS_REFINEMENT").upper()
    if decision not in {"READY", "NEEDS_REFINEMENT", "OFF_CONTEXT", "CONFLICT_REQUIRES_CLARIFICATION"}:
        decision = "NEEDS_REFINEMENT"
    result["decision"] = decision
    result["preserve_unaffected_content"] = True
    return result


def revise_scenario(
    confirmed_step1: Dict[str, Any], horizon: str, base_scenario: Dict[str, Any],
    confirmed_feedback: str, accepted_context: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    feedback = str(confirmed_feedback or "").strip()
    if not feedback:
        raise Step2Error("Confirmed feedback is required.")
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "ASSESSMENT_HORIZON": str(horizon or "").strip(),
        "BASE_SCENARIO": str(base_scenario.get("scenario_narrative") or ""),
        "BASE_ASSUMPTIONS": base_scenario.get("assumptions") or [],
        "ACCEPTED_CONTEXT": accepted_context or ((base_scenario.get("context_assessment") or {}).get("curated_context") or []),
        "CONFIRMED_FEEDBACK": feedback,
    }
    result = _call_json(_load_prompt("step2_scenario_revision.txt"), payload, MODEL_OPUS, max_tokens=6500)
    result = _validate_scenario(result, str(horizon or ""))
    result.setdefault("revision", {})
    result["revision"]["feedback_applied"] = feedback
    result["model_path"] = MODEL_OPUS
    result["prompt_version"] = "step2_scenario_revision_v1"
    result["state"] = "AI_REVISION"
    return result


def finalize_scenario(scenario: Dict[str, Any], analyst_modified_fields: Optional[List[str]] = None) -> Dict[str, Any]:
    """Deterministic confirmation gate: no LLM call."""
    horizon = str(scenario.get("assessment_horizon") or "").strip()
    validated = _validate_scenario(dict(scenario), horizon)
    validated["state"] = "CONFIRMED"
    validated["analyst_modified_fields"] = sorted(set(analyst_modified_fields or []))
    validated["confirmed_for_downstream"] = True
    return validated


def _normalize_event_factors(result: Dict[str, Any]) -> Dict[str, Any]:
    factors = result.get("factors")
    if not isinstance(factors, list) or not (4 <= len(factors) <= 6):
        raise Step2Error("Step 2.3 must return 4-6 event-driven factors.")
    scores: List[int] = []
    for i, factor in enumerate(factors, start=1):
        if not isinstance(factor, dict):
            raise Step2Error(f"Risk factor {i} is not an object.")
        factor["factor_id"] = str(factor.get("factor_id") or f"RF{i}")
        importance = str(factor.get("importance") or "").upper()
        if importance not in _IMPORTANCE_SCORE:
            raise Step2Error(f"{factor['factor_id']} importance must be HIGH or MEDIUM.")
        factor["importance"] = importance
        factor["importance_score"] = _IMPORTANCE_SCORE[importance]
        scores.append(_IMPORTANCE_SCORE[importance])
        threshold = factor.get("critical_threshold") or {}
        conditions = threshold.get("conditions") if isinstance(threshold, dict) else None
        if not isinstance(conditions, list) or len(conditions) < 2:
            raise Step2Error(f"{factor['factor_id']} critical threshold must use at least two AND conditions.")
        threshold["logic"] = "AND"
        factor["critical_threshold"] = threshold

    total = sum(scores)
    weights = [round(100.0 * score / total, 2) for score in scores]
    weights[-1] = round(weights[-1] + (100.0 - sum(weights)), 2)
    for factor, weight in zip(factors, weights):
        factor["weight_pct"] = weight

    result["factors"] = factors
    result.setdefault("industry_sensitivity", [])
    result.setdefault("methodology_limitations", [])
    result["weight_method"] = "DETERMINISTIC_IMPORTANCE_NORMALIZATION"
    result["importance_mapping"] = {"HIGH": 2, "MEDIUM": 1}
    result["weights_sum_pct"] = round(sum(f["weight_pct"] for f in factors), 2)
    result["state"] = "AI_PROPOSAL"
    return result


def generate_event_factors(
    confirmed_step1: Dict[str, Any], confirmed_scenario: Dict[str, Any], sector: str,
    portfolio_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    if not confirmed_scenario.get("confirmed_for_downstream") and str(confirmed_scenario.get("state") or "").upper() != "CONFIRMED":
        raise Step2Error("Step 2.3 requires a confirmed Step-2.1 scenario.")
    sector = str(sector or "").strip()
    if not sector:
        raise Step2Error("Selected sector is required for Step 2.3.")
    payload = {
        "CONFIRMED_STEP1": _compact_step1(confirmed_step1),
        "CONFIRMED_STEP2_SCENARIO": confirmed_scenario.get("scenario_narrative"),
        "CONFIRMED_STEP2_ASSUMPTIONS": confirmed_scenario.get("assumptions") or [],
        "SELECTED_SECTOR": sector,
        "PORTFOLIO_CONTEXT": portfolio_context or {},
    }
    result = _call_json(_load_prompt("step2_event_factors.txt"), payload, MODEL_OPUS, max_tokens=9000)
    result = _normalize_event_factors(result)
    result["sector"] = sector
    result["model_path"] = MODEL_OPUS
    result["prompt_version"] = "step2_event_factors_v1"
    return result
