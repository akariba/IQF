# CHANGE_MANIFEST.md — RPR Trigger 1 v11.1

Candidate for review. Not approved for deployment. Fixes 8 release blockers identified
in review of v11; does not touch Trigger 2 or the v31 visual baseline.

## Changed files (replace on disk)

| File | What changed |
|---|---|
| `backend/market_event_scout.py` | Live-safe timeouts (50s/150s/180s). New `_run_with_semaphore_owned_timeout()` — semaphore permit is now held for the true duration of the underlying call, not released early at the caller's timeout (fixes blocker #3). Removed the now-dead `_await_in_new_thread`/`_call_text_with_timeout`. Fixed a double-semaphore-acquisition bug in `_refine_theme_group` introduced by that same fix. `_theme_specs()` and `build_discovered_event()` now carry `client_theme_id` through; `theme_index` is now always a gap-free 0..N-1 sequence based on output position. Event `label` field is no longer numbered (was leaking the global event_id). |
| `backend/server.py` | `ThemeInput` gains `client_theme_id`. `theme_status` entries and cache-hit responses now carry/preserve it. Cache writes are allowed only when every theme discovered successfully and every event reached `refined`; fully failed and partially retained technical results are never replayed from cache. Cache-hit responses return the original `job_id` when it still exists, instead of always `null`, so retry has an identity to act on. Retry preserves `client_theme_id`. |
| `backend/prompts/trigger1_batch_discovery_evidence.txt` | Not changed in this revision (already correct from v11). |
| `frontend/rpr-v8-consolidated-test.html` | Changes inside `<script>` only — confirmed byte-identical to v31 outside it. Scan/Re-scan stays disabled until the backend explicitly reports a terminal job (the old fixed 300s polling cutoff was removed because it was shorter than the 380s configured stage ceiling). `applyProgressivePayload`/`resolveThemeId` match by `client_theme_id` first, with gap-free filtered indices as fallback. A late generated candidate is stored as `pendingGeneratedVersion`; Review & Compare now shows the full confirmed and generated versions together before an explicit “Use Update as Editable Draft” action, while keeping a confirmed snapshot. Retry is wired to the stage-aware endpoint. Event numbering is local to each theme. |
| `RUNTIME_ENV.ps1` | `RPR_T1_DISCOVERY_TIMEOUT=50`, `RPR_T1_ENRICHMENT_TIMEOUT=150`, `RPR_T1_REFINEMENT_TIMEOUT=180`, with a comment recording the measured live ranges these were derived from. |

## Unchanged files — included for a complete replacement set

`backend/rpr_search_agent.py`, `backend/theme_assistant_batch.py`, all prompt files except
`trigger1_batch_discovery_evidence.txt` (unchanged from v11) — all confirmed byte-identical
to the prior (v11) package.

## Explicitly NOT touched

`backend/theme_assistant.py`, `backend/llm_gateway.py`, `backend/step1_quality.py`,
`backend/rpr_model_trace.py`, `backend/rpr_enhancement_routes.py`, `backend/step2_routes.py`,
`backend/rpr_feedback_routes.py`, `backend/narrative_enricher.py` (Trigger 2 — untouched),
approved Helix/R2D2/Vertex/certificate/token implementation, v31 layout/CSS/typography.

## Diff patches included (against the prior v11 package)

`DIFF_v11_to_v11_1_market_event_scout.patch`, `DIFF_v11_to_v11_1_server.patch`,
`DIFF_v11_to_v11_1_frontend.patch`, `DIFF_v11_to_v11_1_RUNTIME_ENV.patch`.
