# RPR Step 2 v31 Integrated Test v1

This package corrects the earlier standalone test-harness mistake.

## Visual rule

- `rpr-step2-v31-integrated-test-v1.html` is a **NEW test file**.
- It uses `rpr-step1-test-v6-1.html` as the Step-1 base.
- Existing Step-1 markup/CSS/JS is left in place.
- Step 2 and Step 3 are added using the v31 replication contract supplied in the screenshots.
- The original `icm-pm-rapid-portfolio-review-v31.html` is **not replaced or modified**.
- No standalone generic test UI is included.

## Functional scope wired now

Step 2.1:
- confirmed Step-1 input + horizon;
- optional typed context;
- optional PDF/DOCX/TXT/CSV/XLSX upload extraction;
- quality-preserving context assessor;
- Opus scenario + assumptions;
- analyst edit + deterministic confirmation gate;
- shared v31 feedback panel:
  - Sonnet feedback assistance;
  - analyst confirms/edits feedback;
  - Opus targeted scenario revision.

Step 2.2:
- deterministic sector selection UI.

Step 2.3:
- confirmed Step-1 + confirmed Step-2.1 + selected sector/context;
- Opus event-driven factor proposal;
- backend deterministic High=2 / Medium=1 factor weights.

Step 2.4 / 2.5 / Step 3:
- v31 visual containers are present;
- their existing/proposed business logic is intentionally not replaced by this package.

## Backend

`backend/server.py` is the current Step-1 server with only the Step-2 router registration added.
