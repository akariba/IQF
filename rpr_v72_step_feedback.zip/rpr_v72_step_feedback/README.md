# RPR v7.2 — Step-Scoped Feedback Architecture

This package implements the feedback design decision: **each workflow page/step has its own feedback interaction, prompt contract, state, and endpoint**.

## Model routing

- Feedback conversation / reasoning: **Claude Sonnet 4.6** (`RPR_FEEDBACK_MODEL`, default `claude-sonnet-4-6`)
- Step 2.1 scenario generation: **Claude Opus 4.6** (existing Step-2 routing)
- Step 2.1 applied revision: **Claude Opus 4.6** (`STEP2_REVISION_MODEL`, now defaults to Opus)
- Step 2.3 event-factor generation: **Claude Opus 4.6**
- Step 2.3 applied revision: **Claude Opus 4.6**
- Exact importance-score/weight arithmetic: **deterministic Python**, unchanged
- Step 2.2 portfolio selection: **deterministic user selection**; feedback may advise but can never auto-select

This keeps conversational feedback fast while reserving Opus for expensive content mutation.

## Separate feedback surfaces

1. Step 2.1 — Feedback to Scenario & Assumptions Agent
2. Step 2.2 — Feedback to Portfolio Selection Assistant
3. Step 2.3 — Feedback to Event-Driven Risk Factor Agent
4. Step 2.4 — Feedback to Sector-Inherent Risk Factor Agent
5. Step 2.5 — Feedback to Name-Level Assessment Agent
6. Step 3 — Feedback to Portfolio Assessment Agent

Each panel has an independent chat-history array in the test HTML. No conversation history is shared across steps.

## Apply behavior

- **Step 2.1:** Sonnet analyzes feedback; an explicit `Apply Proposed Revision` button calls the existing scenario revision path, now Opus by default.
- **Step 2.2:** advice only. No LLM can mutate portfolio selection.
- **Step 2.3:** Sonnet analyzes feedback; explicit Apply calls the new `/event-factors/revise` endpoint using Opus, then deterministic weights are recomputed.
- **Step 2.4:** review/governance guidance only in this build. Approved taxonomy is never silently mutated.
- **Step 2.5:** review/guidance only in this build. SEC/public and CAM/internal evidence boundaries remain protected.
- **Step 3:** review/guidance only in this build. Portfolio arithmetic remains deterministic.

## Visual contract

The new test HTML was created from `rpr-step2-integrated-v31-v2-visual-recovery.html`.

Validation confirms:
- the full `<style>` block is byte-for-byte identical to the v2 visual-recovery source;
- the entire Step-1 HTML prefix before `tab-1` is byte-for-byte identical;
- the new panels reuse the existing v31 `.panel-feedback`, `.pf-hdr`, `.chat-msgs`, `.chat-input-row`, `.chat-input`, and `.chat-send` classes;
- no v31 baseline file is modified.

The original shared Step-1 feedback panel remains untouched in markup. It is only hidden when the user switches to Step 2 or Step 3, where the dedicated page feedback panels are shown.

## Model observability

Backend Step-2 and feedback calls log lines such as:

`[LLM] START provider=r2d2 model=claude-sonnet-4-6 role=feedback_step2_3 ...`

`[LLM] START provider=r2d2 model=claude-opus-4-6 role=step2_event_factor_revision ...`

The new HTML also copies `models_triggered` / `model_path` metadata into the existing System Log.

## Validation

- Python syntax compilation: PASS
- JavaScript syntax check: PASS when Node is available
- 6 feedback contract/mock tests: PASS
- CSS identity check against v2 visual recovery: PASS
- Step-1 HTML prefix identity check: PASS
