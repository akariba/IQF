from pathlib import Path

PKG = Path(__file__).resolve().parents[1]


def test_six_scoped_feedback_prompts_exist():
    prompt_dir = PKG / "backend" / "prompts"
    expected = {
        "feedback_step21.txt", "feedback_step22.txt", "feedback_step23.txt",
        "feedback_step24.txt", "feedback_step25.txt", "feedback_step3.txt",
    }
    assert expected.issubset({p.name for p in prompt_dir.glob("*.txt")})


def test_html_has_unique_feedback_state_and_panels():
    html = (PKG / "frontend" / "rpr-step2-integrated-v31-v3-step-feedback.html").read_text(encoding="utf-8")
    for key in ("step2-1", "step2-2", "step2-3", "step2-4", "step2-5", "step3"):
        assert f'id="{key}-chat-msgs"' in html
        assert f'id="{key}-chat-input"' in html
    assert "STEP21_FEEDBACK_HISTORY" in html
    assert "STEP22_FEEDBACK_HISTORY" in html
    assert "STEP23_FEEDBACK_HISTORY" in html
    assert "STEP24_FEEDBACK_HISTORY" in html
    assert "STEP25_FEEDBACK_HISTORY" in html
    assert "STEP3_FEEDBACK_HISTORY" in html


def test_feedback_routes_are_explicit_per_step():
    routes = (PKG / "backend" / "rpr_feedback_routes.py").read_text(encoding="utf-8")
    for path in ("/step2-1/assist", "/step2-2/assist", "/step2-3/assist", "/step2-4/assist", "/step2-5/assist", "/step3/assist"):
        assert path in routes


def test_step23_revision_is_explicit_apply_only():
    service = (PKG / "backend" / "step2_service.py").read_text(encoding="utf-8")
    routes = (PKG / "backend" / "step2_routes.py").read_text(encoding="utf-8")
    assert "def revise_event_factors(" in service
    assert '"step2_event_factors_revision.txt"' in service
    assert 'post("/event-factors/revise")' in routes
    assert 'MODEL_REVISION = os.environ.get("STEP2_REVISION_MODEL", MODEL_OPUS)' in service
