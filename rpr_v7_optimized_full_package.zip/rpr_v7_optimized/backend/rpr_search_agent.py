"""RPR role-aware Gemini/ADK enterprise web search agent.

Why this exists:
- The legacy shared web_search_agent has a report-writing system instruction.
- RPR uses search for several different jobs (discovery, evidence retrieval, theme suggestions).
- This neutral agent follows the caller's mode-specific prompt exactly, reducing instruction conflict,
  retries and latency.

The legacy web_search_agent.py is not modified and remains available as a fallback.
"""
from __future__ import annotations

import logging
import os
import uuid
from typing import Dict

from google.adk.agents import LlmAgent
from google.adk.tools import enterprise_web_search
from helix_adk_adapter.custom_google_llm import HelixGemini

log = logging.getLogger("rpr_search_agent")

_DISCOVERY_MODEL = os.environ.get("RPR_GEMINI_DISCOVERY_MODEL", "gemini-3.5-flash")
_EVIDENCE_MODEL = os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", "gemini-3.5-flash")

_BASE_INSTRUCTION = """You are the enterprise-web retrieval layer for a bank credit-risk application.
Use enterprise_web_search when the caller requests current/public evidence.
Follow the caller's requested scope and output format exactly.
Do not substitute a different event or theme.
Prefer primary/authoritative sources and reputable financial news.
Never invent facts, numbers, publication dates, URLs, search queries, or source support.
If evidence is unavailable, say so in the caller's requested format.
The caller owns the business schema; do not impose an unrelated report structure.
"""

_agents: Dict[str, LlmAgent] = {}

def _model_for_role(role: str) -> str:
    return _DISCOVERY_MODEL if str(role).lower() in {"discovery", "theme"} else _EVIDENCE_MODEL

def _agent_for(role: str) -> LlmAgent:
    key = f"{role}:{_model_for_role(role)}"
    agent = _agents.get(key)
    if agent is None:
        agent = LlmAgent(
            name=f"rpr_web_{str(role).lower()}_agent",
            model=HelixGemini(model=_model_for_role(role)),
            instruction=_BASE_INSTRUCTION,
            description="RPR role-aware enterprise web retrieval agent",
            tools=[enterprise_web_search],
            output_key="results",
        )
        _agents[key] = agent
    return agent

async def run_web_search(query: str, role: str = "evidence", **_) -> dict:
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService
    from google.genai import types

    session_id = "rprws-" + uuid.uuid4().hex[:12]
    session_service = InMemorySessionService()
    await session_service.create_session(app_name="rpr_web_search", user_id="user", session_id=session_id)
    runner = Runner(agent=_agent_for(role), app_name="rpr_web_search", session_service=session_service)
    content = types.Content(role="user", parts=[types.Part(text=str(query))])
    answer = ""
    async for event in runner.run_async(user_id="user", session_id=session_id, new_message=content):
        if not getattr(event, "is_final_response", lambda: False)():
            continue
        evt_content = getattr(event, "content", None)
        for part in getattr(evt_content, "parts", []) or []:
            text = getattr(part, "text", None)
            if text:
                answer += str(text)
    answer = answer.strip()
    log.info("RPR enterprise search role=%s model=%s chars=%s", role, _model_for_role(role), len(answer))
    return {"answer": answer, "raw": answer, "role": role, "model": _model_for_role(role)}
