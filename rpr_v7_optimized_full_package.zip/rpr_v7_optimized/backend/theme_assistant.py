"""Trigger-1 theme quality gate and live market-theme assistant.

The workflow is deliberately two-stage:
1) classify whether the analyst's input can support a high-quality credit portfolio scan;
2) only when the input is weak/broad/ambiguous, use the existing ADK/Gemini enterprise
   web-search path to propose current, evidence-supported market themes.

The assistant never changes a theme automatically. The frontend must require analyst selection
or an explicit "scan original anyway" action.
"""
from __future__ import annotations

import asyncio
import inspect
import json
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

PROMPT_DIR = Path(__file__).resolve().parent / "prompts"
CLASSIFIER_PROMPT_PATH = PROMPT_DIR / "theme_assistant.txt"
SEARCH_PROMPT_PATH = PROMPT_DIR / "theme_market_search.txt"
SUGGESTION_PROMPT_PATH = PROMPT_DIR / "theme_market_suggestions.txt"

try:
    from rpr_search_agent import run_web_search as _adk_run_web_search  # type: ignore
except Exception:
    try:
        from web_search_agent import run_web_search as _adk_run_web_search  # type: ignore
    except Exception:
        _adk_run_web_search = None

_ALLOWED_CLASSIFICATIONS = {
    "STRONG",
    "RELEVANT_BUT_BROAD",
    "AMBIGUOUS",
    "LOW_CREDIT_RELEVANCE",
    "OFF_DOMAIN",
}
_ALLOWED_RECOMMENDATIONS = {"SCAN", "REFINE", "CLARIFY", "SUGGEST_MARKET_THEMES"}
_ALLOWED_RELATIONSHIPS = {"DIRECT", "POSSIBLE", "ALTERNATIVE"}
_ALLOWED_EVIDENCE_STRENGTH = {"HIGH", "MEDIUM"}

_OFF_DOMAIN_TERMS = {
    "cooking", "recipe", "recipes", "knitting", "gardening", "poetry", "karaoke",
    "makeup", "hairstyles", "wedding dresses", "video games", "gaming tips",
}
_AMBIGUOUS_TERMS = {"fifa", "apple", "amazon", "meta", "jaguar", "mercury"}
_BROAD_GEOGRAPHIES = {
    "us", "u.s.", "usa", "united states", "uk", "u.k.", "united kingdom", "europe",
    "eu", "china", "japan", "india", "asia", "emea", "latam", "africa", "middle east",
}
_BROAD_MARKET_TERMS = {
    "geopolitics", "geopolitical risk", "markets", "market risk", "global markets",
    "monetary policy", "global monetary policy", "credit risk", "banking", "banks",
    "technology", "ai", "artificial intelligence", "energy", "commodities", "trade",
    "global trade", "macro", "macroeconomics", "economy", "global economy", "rates",
}
_CREDIT_TERMS_RE = re.compile(
    r"\b(?:credit|spread|cds|bond|yield|funding|liquidity|rating|default|sovereign|debt|"
    r"refinanc|tariff|trade policy|interest rate|monetary|bank|commodity|energy|inflation|"
    r"fx|currency|sanction|fiscal|treasury|corporate|sector|counterparty|portfolio)\b",
    re.IGNORECASE,
)


def _load_prompt(path: Path, fallback: str) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return fallback


def _strip_fences(text: str) -> str:
    t = str(text or "").strip()
    t = re.sub(r"^```(?:json)?\s*", "", t, flags=re.I)
    t = re.sub(r"\s*```$", "", t)
    return t.strip()


def _normalise_search_output(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        for key in ("text", "output", "response", "content", "answer"):
            if isinstance(value.get(key), str):
                return value[key]
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (list, tuple)):
        return "\n".join(_normalise_search_output(x) for x in value)
    return str(value)


def _await_in_thread(awaitable: Any, timeout: int) -> Any:
    result: Dict[str, Any] = {}
    error: Dict[str, BaseException] = {}

    def runner() -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result["value"] = loop.run_until_complete(asyncio.wait_for(awaitable, timeout=timeout))
        except BaseException as exc:  # noqa: BLE001
            error["error"] = exc
        finally:
            loop.close()

    th = threading.Thread(target=runner, daemon=True)
    th.start()
    th.join(timeout + 5)
    if th.is_alive():
        raise TimeoutError(f"Theme market suggestion search exceeded {timeout}s")
    if "error" in error:
        raise error["error"]
    return result.get("value")


def _adk_search_sync(prompt: str, timeout: int = 60) -> str:
    if _adk_run_web_search is None:
        raise RuntimeError("ADK enterprise web search is unavailable")
    try:
        value = _adk_run_web_search(prompt, role="theme")
    except TypeError:
        value = _adk_run_web_search(prompt)
    if inspect.isawaitable(value):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            value = asyncio.run(asyncio.wait_for(value, timeout=timeout))
        else:
            value = _await_in_thread(value, timeout)
    text = _normalise_search_output(value).strip()
    if not text:
        raise RuntimeError("ADK enterprise web search returned an empty response")
    return text


def _fallback_classification(theme: str, description: str = "") -> Dict[str, str]:
    raw = (theme or "").strip()
    desc = (description or "").strip()
    low = re.sub(r"\s+", " ", raw.lower())
    combined = f"{raw} {desc}".strip()
    words = re.findall(r"[A-Za-z0-9&.-]+", raw)

    if not raw:
        return {
            "classification": "AMBIGUOUS",
            "credit_relevance": "LOW",
            "specificity": "LOW",
            "scan_recommendation": "CLARIFY",
            "reason": "No usable market-risk theme was supplied for credit portfolio assessment.",
        }

    if low in _OFF_DOMAIN_TERMS and not _CREDIT_TERMS_RE.search(desc):
        return {
            "classification": "OFF_DOMAIN",
            "credit_relevance": "NONE",
            "specificity": "LOW",
            "scan_recommendation": "SUGGEST_MARKET_THEMES",
            "reason": "This theme is outside the market and credit-risk scope of the portfolio assessment and is unlikely to produce meaningful results.",
        }

    if low in _AMBIGUOUS_TERMS and not _CREDIT_TERMS_RE.search(desc):
        return {
            "classification": "AMBIGUOUS",
            "credit_relevance": "LOW",
            "specificity": "LOW",
            "scan_recommendation": "CLARIFY",
            "reason": "This phrase does not identify a clear market or credit-risk angle, so event discovery could be inconsistent.",
        }

    if low in _BROAD_GEOGRAPHIES:
        return {
            "classification": "RELEVANT_BUT_BROAD",
            "credit_relevance": "MEDIUM",
            "specificity": "LOW",
            "scan_recommendation": "REFINE",
            "reason": "The input identifies a geography but not the market or credit-risk driver, which can lead to unrelated event results.",
        }

    if low in _BROAD_MARKET_TERMS and len(desc) < 45:
        return {
            "classification": "RELEVANT_BUT_BROAD",
            "credit_relevance": "HIGH",
            "specificity": "LOW",
            "scan_recommendation": "REFINE",
            "reason": "The theme is relevant to credit risk but spans several event families and may reduce the coherence of the top-event assessment.",
        }

    if _CREDIT_TERMS_RE.search(combined) and (len(words) >= 3 or len(desc) >= 35):
        return {
            "classification": "STRONG",
            "credit_relevance": "HIGH",
            "specificity": "HIGH" if len(words) >= 3 else "MEDIUM",
            "scan_recommendation": "SCAN",
            "reason": "The theme has a clear market or credit-risk driver and is sufficiently scoped for event discovery.",
        }

    if len(words) <= 2:
        return {
            "classification": "AMBIGUOUS",
            "credit_relevance": "LOW" if not _CREDIT_TERMS_RE.search(combined) else "MEDIUM",
            "specificity": "LOW",
            "scan_recommendation": "CLARIFY",
            "reason": "The theme is too ambiguous to reliably identify a coherent market and credit-risk event set.",
        }

    return {
        "classification": "LOW_CREDIT_RELEVANCE",
        "credit_relevance": "LOW",
        "specificity": "MEDIUM",
        "scan_recommendation": "SUGGEST_MARKET_THEMES",
        "reason": "The theme does not show a sufficiently clear credit-risk transmission channel for a strong portfolio assessment.",
    }


def classify_theme(theme: str, description: str = "") -> Dict[str, str]:
    """Fast classification stage. It does not perform web search."""
    theme = (theme or "").strip()
    description = (description or "").strip()
    fallback = _fallback_classification(theme, description)
    if not theme:
        return fallback

    try:
        from llm_gateway import get_gateway  # type: ignore

        gateway = get_gateway()
        if not hasattr(gateway, "call_text"):
            return fallback
        system = _load_prompt(
            CLASSIFIER_PROMPT_PATH,
            "Return JSON classification/credit_relevance/specificity/scan_recommendation/reason for a credit-risk theme quality gate.",
        )
        user = json.dumps({"theme": theme, "description": description}, ensure_ascii=False)
        raw = str(gateway.call_text(system_prompt=system, user_prompt=user, max_tokens=650) or "").strip()
        obj = json.loads(_strip_fences(raw))

        classification = str(obj.get("classification") or "").upper()
        credit_relevance = str(obj.get("credit_relevance") or "").upper()
        specificity = str(obj.get("specificity") or "").upper()
        recommendation = str(obj.get("scan_recommendation") or "").upper()
        reason = str(obj.get("reason") or "").strip()

        if classification not in _ALLOWED_CLASSIFICATIONS:
            raise ValueError("invalid classification")
        if credit_relevance not in {"HIGH", "MEDIUM", "LOW", "NONE"}:
            raise ValueError("invalid credit_relevance")
        if specificity not in {"HIGH", "MEDIUM", "LOW"}:
            raise ValueError("invalid specificity")
        if recommendation not in _ALLOWED_RECOMMENDATIONS:
            raise ValueError("invalid scan_recommendation")
        if not reason:
            raise ValueError("missing reason")

        expected_recommendation = {
            "STRONG": "SCAN",
            "RELEVANT_BUT_BROAD": "REFINE",
            "AMBIGUOUS": "CLARIFY",
            "LOW_CREDIT_RELEVANCE": "SUGGEST_MARKET_THEMES",
            "OFF_DOMAIN": "SUGGEST_MARKET_THEMES",
        }[classification]
        # Classification drives the control flow. Do not let an inconsistent free-form
        # model field accidentally bypass the analyst-facing quality gate.
        recommendation = expected_recommendation

        return {
            "classification": classification,
            "credit_relevance": credit_relevance,
            "specificity": specificity,
            "scan_recommendation": recommendation,
            "reason": reason,
        }
    except Exception:
        return fallback


def _theme_tokens(value: str) -> set[str]:
    stop = {"and", "or", "the", "of", "to", "in", "for", "on", "global", "market", "markets", "risk"}
    out = set()
    for raw in re.findall(r"[a-z0-9]+", str(value or "").lower()):
        if raw in stop:
            continue
        if len(raw) <= 2 and raw not in {"us", "uk", "eu"}:
            continue
        token = raw[:-1] if len(raw) > 4 and raw.endswith("s") else raw
        out.add(token)
    return out


def themes_materially_overlap(a: str, b: str) -> bool:
    na = re.sub(r"\W+", " ", str(a or "").lower()).strip()
    nb = re.sub(r"\W+", " ", str(b or "").lower()).strip()
    if not na or not nb:
        return False
    if na == nb or (len(na) >= 12 and na in nb) or (len(nb) >= 12 and nb in na):
        return True
    ta, tb = _theme_tokens(na), _theme_tokens(nb)
    if not ta or not tb:
        return False
    jaccard = len(ta & tb) / max(1, len(ta | tb))
    containment = len(ta & tb) / max(1, min(len(ta), len(tb)))
    return jaccard >= 0.50 or (len(ta & tb) >= 2 and containment >= 0.60)


def _filter_existing_theme_duplicates(suggestions: List[Dict[str, Any]], existing_themes: Sequence[str]) -> List[Dict[str, Any]]:
    existing = [str(x or "").strip() for x in existing_themes or [] if str(x or "").strip()]
    out: List[Dict[str, Any]] = []
    for item in suggestions:
        theme = str(item.get("theme") or "").strip()
        if any(themes_materially_overlap(theme, ex) for ex in existing):
            continue
        if any(themes_materially_overlap(theme, str(prev.get("theme") or "")) for prev in out):
            continue
        out.append(item)
        if len(out) >= 3:
            break
    return out


def _parse_suggestions(raw: str) -> List[Dict[str, Any]]:
    cleaned = _strip_fences(raw)
    obj: Optional[Dict[str, Any]] = None
    try:
        obj = json.loads(cleaned)
    except Exception:
        match = re.search(r"(?s)\{.*\}", cleaned)
        if match:
            try:
                obj = json.loads(match.group(0))
            except Exception:
                obj = None
    if not isinstance(obj, dict) or not isinstance(obj.get("suggestions"), list):
        return []

    out: List[Dict[str, Any]] = []
    seen = set()
    for item in obj["suggestions"]:
        if not isinstance(item, dict):
            continue
        theme = str(item.get("theme") or "").strip()
        if not theme or theme.lower() in seen:
            continue
        seen.add(theme.lower())
        relationship = str(item.get("relationship_to_original") or "ALTERNATIVE").upper()
        if relationship not in _ALLOWED_RELATIONSHIPS:
            relationship = "ALTERNATIVE"
        evidence_strength = str(item.get("evidence_strength") or "MEDIUM").upper()
        if evidence_strength not in _ALLOWED_EVIDENCE_STRENGTH:
            evidence_strength = "MEDIUM"
        channels = [str(x).strip() for x in (item.get("key_credit_channels") or []) if str(x).strip()][:4]
        source_names = [str(x).strip() for x in (item.get("source_names") or []) if str(x).strip()][:3]
        source_urls = [str(x).strip() for x in (item.get("source_urls") or []) if str(x).strip().startswith(("http://", "https://"))][:3]
        out.append({
            "theme": theme,
            "rationale": str(item.get("rationale") or "").strip(),
            "relationship_to_original": relationship,
            "evidence_strength": evidence_strength,
            "key_credit_channels": channels,
            "source_names": source_names,
            "source_urls": source_urls,
        })
        if len(out) >= 3:
            break
    return out


def _ground_suggestions_in_dossier(
    suggestions: List[Dict[str, Any]],
    evidence_dossier: str,
) -> List[Dict[str, Any]]:
    """Remove provenance fields that are not literally present in the retrieved dossier."""
    dossier = str(evidence_dossier or "")
    low = dossier.lower()
    out: List[Dict[str, Any]] = []
    for item in suggestions:
        clean = dict(item)
        clean["source_urls"] = [u for u in (item.get("source_urls") or []) if str(u) in dossier][:3]
        clean["source_names"] = [n for n in (item.get("source_names") or []) if str(n).lower() in low][:3]
        out.append(clean)
    return out


def suggest_market_themes(
    *,
    theme: str,
    description: str,
    classification: Dict[str, str],
    existing_themes: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    """Live current-market suggestion workflow for non-STRONG themes.

    Gemini/ADK performs retrieval. R2D2/Claude (when available) only normalizes the
    retrieved dossier into the stable three-suggestion JSON contract. If the synthesis
    layer is unavailable, a directly parseable ADK JSON response is accepted as a safe
    fallback. No hard-coded current market themes are fabricated.
    """
    report_as_of = datetime.now(timezone.utc).isoformat()
    search_system = _load_prompt(
        SEARCH_PROMPT_PATH,
        "Search current web evidence for strong market-risk developments suitable for credit portfolio assessment.",
    )
    synthesis_system = _load_prompt(
        SUGGESTION_PROMPT_PATH,
        "Using only the supplied web evidence dossier, return JSON with up to 3 strong market-risk theme suggestions.",
    )
    runtime = {
        "REPORT_AS_OF": report_as_of,
        "original_theme": theme,
        "description": description,
        "classification": classification.get("classification"),
        "credit_relevance": classification.get("credit_relevance"),
        "specificity": classification.get("specificity"),
        "EXISTING_THEMES": [str(x).strip() for x in (existing_themes or []) if str(x).strip()],
    }
    search_prompt = search_system + "\n\n# RUNTIME INPUT\n" + json.dumps(runtime, ensure_ascii=False, indent=2)
    try:
        evidence_dossier = _adk_search_sync(search_prompt, timeout=120)

        suggestions: List[Dict[str, Any]] = []
        synthesis_raw = ""
        try:
            from llm_gateway import get_gateway  # type: ignore

            gateway = get_gateway()
            if hasattr(gateway, "call_text"):
                synthesis_input = {
                    **runtime,
                    "enterprise_web_evidence_dossier": evidence_dossier[:18000],
                }
                synthesis_raw = str(gateway.call_text(
                    system_prompt=synthesis_system,
                    user_prompt=json.dumps(synthesis_input, ensure_ascii=False),
                    max_tokens=1400,
                ) or "").strip()
                suggestions = _parse_suggestions(synthesis_raw)
        except Exception:
            suggestions = []

        # Compatibility fallback: if the shared ADK agent already returned the requested
        # JSON shape, accept it. Never invent hard-coded current themes on failure.
        if not suggestions:
            suggestions = _parse_suggestions(evidence_dossier)
        if not suggestions:
            raise ValueError("No parseable evidence-supported market themes were returned")
        suggestions = _ground_suggestions_in_dossier(suggestions, evidence_dossier)
        suggestions = _filter_existing_theme_duplicates(suggestions, existing_themes or [])
        if not suggestions:
            raise ValueError("All evidence-supported suggestions overlapped existing scanner themes")
        return {
            "status": "SUCCESS",
            "suggestions": suggestions,
            "report_as_of": report_as_of,
            "source": "ADK Gemini enterprise web search -> governed suggestion synthesis",
            "search_instruction": search_prompt[-2000:],
        }
    except Exception as exc:
        return {
            "status": "TECHNICAL_FAILURE",
            "suggestions": [],
            "report_as_of": report_as_of,
            "source": "ADK Gemini enterprise web search",
            "error": str(exc),
        }


def assist_theme(theme: str, description: str = "", existing_themes: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    """Return gate decision and, only when needed, live evidence-supported alternatives."""
    theme = (theme or "").strip()
    description = (description or "").strip()
    gate = classify_theme(theme, description)

    result: Dict[str, Any] = {
        "original_theme": theme,
        **gate,
        # Compatibility alias for the first vNext UI/package.
        "assessment": gate["classification"],
        "suggestions": [],
        "suggestion_status": "NOT_NEEDED" if gate["classification"] == "STRONG" else "PENDING",
        "classification_source": "llm_or_deterministic_fallback",
    }

    if gate["classification"] == "STRONG":
        return result

    suggestions = suggest_market_themes(
        theme=theme,
        description=description,
        classification=gate,
        existing_themes=existing_themes or [],
    )
    result["suggestions"] = suggestions.get("suggestions") or []
    result["suggestion_status"] = suggestions.get("status") or "TECHNICAL_FAILURE"
    result["suggestion_source"] = suggestions.get("source")
    result["report_as_of"] = suggestions.get("report_as_of")
    if suggestions.get("error"):
        result["suggestion_error"] = suggestions["error"]
    return result
