"""Safe, bounded extraction for Step-2.1 optional scenario-context uploads."""
from __future__ import annotations

import csv
import hashlib
import io
from pathlib import Path
from typing import Any, Dict, List

MAX_BYTES = 20 * 1024 * 1024
MAX_EXTRACTED_CHARS = 40000
ALLOWED_EXTENSIONS = {".pdf", ".doc", ".docx", ".txt", ".csv", ".xlsx"}


class UploadExtractionError(ValueError):
    pass


def _bounded(text: str):
    text = (text or "").replace("\x00", "").strip()
    warnings: List[str] = []
    if len(text) > MAX_EXTRACTED_CHARS:
        text = text[:MAX_EXTRACTED_CHARS]
        warnings.append(f"Extracted text truncated to {MAX_EXTRACTED_CHARS} characters.")
    return text, warnings


def _extract_txt(data: bytes):
    for encoding in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            return data.decode(encoding), []
        except UnicodeDecodeError:
            continue
    raise UploadExtractionError("TXT encoding could not be decoded.")


def _extract_csv(data: bytes):
    text, _ = _extract_txt(data)
    rows = []
    for i, row in enumerate(csv.reader(io.StringIO(text))):
        if i >= 250:
            break
        rows.append(" | ".join(str(x) for x in row[:30]))
    return "\n".join(rows), [{"type": "rows", "start": 1, "end": len(rows)}]


def _extract_docx(data: bytes):
    try:
        from docx import Document
    except Exception as exc:
        raise UploadExtractionError("python-docx is required for DOCX extraction.") from exc
    doc = Document(io.BytesIO(data))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for ti, table in enumerate(doc.tables[:30], start=1):
        parts.append(f"[TABLE {ti}]")
        for row in table.rows[:100]:
            parts.append(" | ".join(cell.text.strip() for cell in row.cells))
    return "\n".join(parts), [{"type": "document", "paragraphs": len(doc.paragraphs), "tables": len(doc.tables)}]


def _extract_pdf(data: bytes):
    try:
        from pypdf import PdfReader
    except Exception as exc:
        raise UploadExtractionError("pypdf is required for PDF extraction.") from exc
    reader = PdfReader(io.BytesIO(data))
    parts, refs = [], []
    for i, page in enumerate(reader.pages[:80], start=1):
        text = (page.extract_text() or "").strip()
        if text:
            parts.append(f"[PAGE {i}]\n{text}")
            refs.append({"type": "page", "page": i})
    return "\n".join(parts), refs


def _extract_xlsx(data: bytes):
    try:
        from openpyxl import load_workbook
    except Exception as exc:
        raise UploadExtractionError("openpyxl is required for XLSX extraction.") from exc
    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    parts, refs = [], []
    for ws in wb.worksheets[:15]:
        parts.append(f"[SHEET {ws.title}]")
        row_count = 0
        for row in ws.iter_rows(values_only=True):
            row_count += 1
            if row_count > 250:
                break
            parts.append(" | ".join("" if v is None else str(v) for v in row[:30]))
        refs.append({"type": "sheet", "sheet": ws.title, "rows_extracted": row_count})
    return "\n".join(parts), refs


def extract_context_file(file_name: str, data: bytes, content_type: str = "") -> Dict[str, Any]:
    name = Path(file_name or "upload").name
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise UploadExtractionError(f"Unsupported file type: {ext or 'no extension'}")
    if not data:
        raise UploadExtractionError("Uploaded file is empty.")
    if len(data) > MAX_BYTES:
        raise UploadExtractionError("Uploaded file exceeds the 20 MB Step-2.1 limit.")

    if ext == ".txt":
        text, refs = _extract_txt(data)
    elif ext == ".csv":
        text, refs = _extract_csv(data)
    elif ext == ".docx":
        text, refs = _extract_docx(data)
    elif ext == ".pdf":
        text, refs = _extract_pdf(data)
    elif ext == ".xlsx":
        text, refs = _extract_xlsx(data)
    elif ext == ".doc":
        raise UploadExtractionError("Legacy .doc extraction is not supported by this test package. Convert to DOCX or PDF.")
    else:
        raise UploadExtractionError(f"Unsupported file type: {ext}")

    text, warnings = _bounded(text)
    if not text:
        raise UploadExtractionError("No usable text could be extracted from the uploaded file.")
    return {
        "file_name": name,
        "file_type": ext.lstrip("."),
        "content_type": content_type or "",
        "size_bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "extraction_status": "SUCCESS",
        "extracted_text": text,
        "page_or_sheet_refs": refs,
        "warnings": warnings,
    }
