# RPR v7 Optimized Package

## Design split
- Step 1 v6 behavior stays frozen.
- v31 is the visual contract for Step 2/3.
- New backend search agent removes the legacy shared-agent instruction conflict.
- Trigger 1 prompt is split into discovery/enrichment/refinement.

## LLM routing
- Theme/search discovery: Gemini 3.5 Flash (configurable).
- Trigger 1 event enrichment: Gemini 3.5 Flash + enterprise web search, direct 8-section output (fast path; no extra Claude handoff).
- Trigger 2 retrieval: Gemini 3.5 Flash; synthesis remains R2D2/Claude.
- Step 2 context assessor + feedback assistant: Claude Sonnet 4.6.
- Step 2 fresh scenario + event-factor framework: Claude Opus 4.6.
- Step 2 targeted scenario revision: Claude Sonnet 4.6 by default (faster; configurable).
- Deterministic weights/confirmation: no LLM.

## Latency controls
- Discovery: 55s per theme, themes concurrent.
- Enrichment: 90s per event, bounded worker pool.
- No quota-filling discovery follow-ups by default.
- Discovery normalizer off by default.
- Exact cross-theme duplicate titles are enriched once.

## Important
The HTML v2 is a visual-recovery TEST built from the Stylus audit and the integrated file available in this chat. The original v31 baseline file itself was not available to this ChatGPT runtime as raw bytes, so run the same Stylus visual diff once before treating the HTML as final. No original v31 file is modified.
