# RPR v8 Consolidated

This is a single consolidated overlay. It supersedes the earlier generated v7.1 and v7.2 packages.

Included in the same release:

- Gemini 3.5 Flash enterprise-web fix using the official Citi ADK Adapter.
- Explicit Vertex `us` location.
- No legacy Gemini 2.5/search fallback.
- Fresh per-call ADK model/agent/session lifecycle to avoid cross-loop connector reuse.
- Trigger 1 and Trigger 2: Gemini evidence -> Claude Opus 4.6 refinement.
- Bounded parallel Trigger-1 event pipelines.
- Separate feedback assistant per workflow page.
- Sonnet feedback reasoning + explicit Opus revisions where the page supports apply/revise.
- Existing deterministic scoring/selection boundaries preserved.
- Model invocation logging.
- One integrated test HTML; approved v31 and frozen v6 remain untouched.

See `UPLOAD_SEQUENCE.txt` for the exact copy instructions.
