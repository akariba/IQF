# Non-secret RPR v8 runtime switches.
# Keep credentials/cert/token handling in your existing approved environment.
$env:RPR_GEMINI_MODEL="gemini-3.5-flash"
$env:RPR_GEMINI_DISCOVERY_MODEL="gemini-3.5-flash"
$env:RPR_GEMINI_EVIDENCE_MODEL="gemini-3.5-flash"
$env:RPR_GEMINI_THEME_MODEL="gemini-3.5-flash"
$env:RPR_GEMINI_LOCATION="us"
$env:RPR_STEP1_REFINEMENT_MODEL="claude-opus-4-6"
$env:STEP2_SONNET_MODEL="claude-sonnet-4-6"
$env:STEP2_OPUS_MODEL="claude-opus-4-6"
$env:RPR_FEEDBACK_MODEL="claude-sonnet-4-6"
