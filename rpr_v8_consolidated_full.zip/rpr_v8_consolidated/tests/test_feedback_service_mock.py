import importlib
import sys
import types
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND))


class FakeGateway:
    def __init__(self):
        self._model = ""

    def call_raw(self, system_prompt, user_prompt, max_tokens=2400):
        return {
            "status": "SUGGEST_REVISION",
            "answer": "Target the requested factor only.",
            "proposed_instruction": "Revise RF2 buffer metrics only; preserve all other factors.",
            "target_fields": ["RF2.buffer_metrics"],
            "preserve_unaffected_content": True,
        }


fake = types.ModuleType("llm_gateway")
fake.get_gateway = lambda: FakeGateway()
sys.modules["llm_gateway"] = fake

svc = importlib.import_module("rpr_feedback_service")


def test_step23_feedback_supports_apply():
    out = svc.assist_step_feedback(
        step_key="step2-3",
        message="make RF2 buffer more conservative",
        context={"current_event_factors": {"factors": [{"factor_id": "RF2"}]}},
        history=[],
    )
    assert out["status"] == "SUGGEST_REVISION"
    assert out["apply_supported"] is True
    assert out["model_path"] == "claude-sonnet-4-6"
    assert out["models_triggered"][0]["role"] == "feedback_step2_3"


def test_step22_never_auto_applies_even_if_model_suggests_revision():
    out = svc.assist_step_feedback(
        step_key="step2-2",
        message="select technology",
        context={"selected_sectors": [], "available_sectors": [{"id": "technology"}]},
        history=[],
    )
    assert out["apply_supported"] is False
