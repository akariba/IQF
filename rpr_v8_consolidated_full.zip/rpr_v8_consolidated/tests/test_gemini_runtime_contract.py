import asyncio
import importlib
import os
import sys
import types
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1] / "backend"
sys.path.insert(0, str(BACKEND))

created_vertices = []
created_agents = []
created_runners = []

class FakeVertex:
    def __init__(self, *, model, model_location):
        self.model = model
        self.model_location = model_location
        created_vertices.append(self)

class FakeAgent:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        created_agents.append(self)

class FakeSession:
    def __init__(self):
        self.state = {}

class FakeSessionService:
    def __init__(self):
        self.sessions = {}
    async def create_session(self, *, app_name, user_id, session_id):
        self.sessions[(app_name,user_id,session_id)] = FakeSession()
    async def get_session(self, *, app_name, user_id, session_id):
        return self.sessions[(app_name,user_id,session_id)]

class Part:
    def __init__(self, text=None): self.text=text
class Content:
    def __init__(self, role=None, parts=None): self.role=role; self.parts=parts or []
class FakeEvent:
    def __init__(self, text): self.content=Content(parts=[Part(text)])
    def is_final_response(self): return True
class FakeRunner:
    def __init__(self, **kwargs):
        self.kwargs=kwargs
        created_runners.append(self)
    async def run_async(self, **kwargs):
        yield FakeEvent('{"events": [{"title":"Event A"}]}')

# Build stub module tree expected by rpr_search_agent.
google = types.ModuleType('google')
adk = types.ModuleType('google.adk')
agents = types.ModuleType('google.adk.agents')
runners = types.ModuleType('google.adk.runners')
sessions = types.ModuleType('google.adk.sessions')
tools = types.ModuleType('google.adk.tools')
genai = types.ModuleType('google.genai')
genai_types = types.ModuleType('google.genai.types')
agents.LlmAgent = FakeAgent
runners.Runner = FakeRunner
sessions.InMemorySessionService = FakeSessionService
tools.enterprise_web_search = object()
genai_types.Content = Content
genai_types.Part = Part
genai.types = genai_types

citi = types.ModuleType('citi_adk_adapter')
citi_models = types.ModuleType('citi_adk_adapter.models')
citi_models.Vertex = FakeVertex

mods = {
    'google': google, 'google.adk': adk, 'google.adk.agents': agents,
    'google.adk.runners': runners, 'google.adk.sessions': sessions,
    'google.adk.tools': tools, 'google.genai': genai,
    'google.genai.types': genai_types, 'citi_adk_adapter': citi,
    'citi_adk_adapter.models': citi_models,
}
for k,v in mods.items(): sys.modules[k]=v

os.environ.pop('RPR_GEMINI_MODEL', None)
os.environ.pop('RPR_GEMINI_LOCATION', None)
sys.modules.pop('rpr_search_agent', None)
mod = importlib.import_module('rpr_search_agent')

assert mod.DISCOVERY_MODEL == 'gemini-3.5-flash'
assert mod.EVIDENCE_MODEL == 'gemini-3.5-flash'
assert mod.VERTEX_LOCATION == 'us'
assert mod.runtime_info()['legacy_search_fallback'] is False

async def main():
    r1 = await mod.run_web_search('query one', role='discovery', trace_label='t1')
    r2 = await mod.run_web_search('query two', role='evidence', trace_label='e1')
    assert r1['model'] == 'gemini-3.5-flash'
    assert r2['model'] == 'gemini-3.5-flash'
    assert r1['vertex_location'] == 'us'
    assert len(created_vertices) == 2
    assert len(created_agents) == 2
    assert len(created_runners) == 2
    assert created_vertices[0] is not created_vertices[1]
    assert created_agents[0] is not created_agents[1]
    assert all(v.model_location == 'us' for v in created_vertices)

asyncio.run(main())
print('PASS: Gemini 3.5 / us / fresh-per-call runtime contract')
