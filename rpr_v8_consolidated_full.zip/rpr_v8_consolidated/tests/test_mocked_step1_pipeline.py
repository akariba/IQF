import json
import sys
from pathlib import Path

BACKEND = Path(__file__).resolve().parents[1] / 'backend'
STEP1 = Path('/mnt/data/rpr_step1_final/backend')
sys.path.insert(0, str(BACKEND))
sys.path.insert(1, str(STEP1))

from step1_quality import SECTION_TITLES


def full_report():
    chunks=[]
    for title in SECTION_TITLES:
        chunks.append(
            f"{title}: {title} supported by an observed 10% move on 2026-08-10. "
            f"(Source: [Reuters, 2026-08-10](https://www.reuters.com/{title.lower().replace(' ','-')}))\n"
            "[EVIDENCE_TIER: SUFFICIENT]\n[RETRIEVAL_STATUS: SUCCESS]"
        )
    return '\n'.join(chunks) + '\nSearch Queries Used:\n- exact test query'


def test_trigger1_mocked_gemini_then_opus(monkeypatch):
    import market_event_scout as m
    discovery = {"events":[
        {"title":"Event A","event_date":"2026-08-10","why_material":"material","search_seed":"event a credit","confidence":"HIGH"},
        {"title":"Event B","event_date":"2026-08-11","why_material":"material","search_seed":"event b credit","confidence":"HIGH"},
    ]}
    calls=[]
    def fake_search(prompt, timeout, role='evidence', trace_label=''):
        calls.append(('gemini',role,trace_label))
        return json.dumps(discovery) if role == 'discovery' else full_report()
    def fake_opus(**kwargs):
        calls.append(('opus','refinement',kwargs.get('trace_label')))
        return full_report()
    monkeypatch.setattr(m, '_adk_search_sync', fake_search)
    monkeypatch.setattr(m, '_call_opus_refinement', fake_opus)
    monkeypatch.setattr(m, '_PARALLEL_ENRICH', False)
    out=m.MarketEventScout().fetch_events([{'theme':'US tariffs','description':'corporate credit'}],2)
    assert out['total']==2
    assert len(out['events'][0]['sections'])==8
    assert calls[0][0:2]==('gemini','discovery')
    assert ('gemini','evidence','event:E1') in calls
    assert ('opus','refinement','event:E1') in calls


def test_trigger2_mocked_gemini_then_opus(monkeypatch):
    import types
    stub=types.ModuleType('r2d2_prompt')
    stub.R2D2_PROMPT='Return the eight governed Step-1 sections.'
    sys.modules['r2d2_prompt']=stub
    sys.modules.pop('narrative_enricher', None)
    import narrative_enricher as n
    calls=[]
    def fake_search(prompt, timeout=90, trace_label='trigger2'):
        calls.append(('gemini',trace_label))
        return full_report()
    def fake_opus(system_prompt, user_prompt, trace_label='trigger2'):
        calls.append(('opus',trace_label))
        return full_report()
    monkeypatch.setattr(n, '_adk_search_sync', fake_search)
    monkeypatch.setattr(n, '_call_r2d2', fake_opus)
    out=n.enrich_narrative('Specific market event narrative')
    assert len(out['sections'])==8
    assert ('gemini','trigger2:evidence') in calls
    assert ('opus','trigger2:final') in calls
