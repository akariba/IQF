from pathlib import Path
import re

PKG = Path(__file__).resolve().parents[1]
BACKEND = PKG / 'backend'
PROMPTS = BACKEND / 'prompts'
HTML = PKG / 'frontend' / 'rpr-v8-consolidated-test.html'


def text(path):
    return Path(path).read_text(encoding='utf-8')


def test_gemini_runtime_contract_static():
    src = text(BACKEND / 'rpr_search_agent.py')
    assert 'from citi_adk_adapter.models import Vertex' in src
    assert 'gemini-3.5-flash' in src
    assert 'RPR_GEMINI_LOCATION", "us"' in src
    assert 'model_location=VERTEX_LOCATION' in src
    assert 'enterprise_web_search' in src
    assert 'agent = _new_agent(role)' in src
    assert 'session_service = InMemorySessionService()' in src
    assert 'runner = Runner(' in src
    assert 'legacy_search_fallback' in src
    assert 'HelixGemini' not in src


def test_no_legacy_search_fallback_in_step1_callers():
    for name in ['market_event_scout.py','narrative_enricher.py','theme_assistant.py']:
        src = text(BACKEND / name)
        assert 'from rpr_search_agent import run_web_search' in src
        assert 'from web_search_agent import run_web_search' not in src


def test_trigger1_is_gemini_then_opus():
    src = text(BACKEND / 'market_event_scout.py')
    assert 'role="discovery"' in src
    assert 'role="evidence"' in src
    assert 'trigger1_opus_refinement' in src
    assert 'claude-opus-4-6' in src
    assert 'ThreadPoolExecutor' in src
    assert '_ENRICH_WORKERS' in src


def test_trigger2_is_gemini_then_opus():
    src = text(BACKEND / 'narrative_enricher.py')
    assert 'role="evidence"' in src
    assert 'trigger2_opus_refinement' in src
    assert 'claude-opus-4-6' in src


def test_required_prompts_are_packaged():
    required = set(re.findall(r'"([A-Za-z0-9_\-]+\.txt)"', '\n'.join(text(p) for p in BACKEND.glob('*.py'))))
    missing = sorted(f for f in required if not (PROMPTS / f).exists())
    assert not missing, missing


def test_feedback_is_separate_per_step():
    service = text(BACKEND / 'rpr_feedback_service.py')
    routes = text(BACKEND / 'rpr_feedback_routes.py')
    for key in ['step2-1','step2-2','step2-3','step2-4','step2-5','step3']:
        assert key in service
    for route in ['/step2-1/assist','/step2-2/assist','/step2-3/assist','/step2-4/assist','/step2-5/assist','/step3/assist']:
        assert route in routes
    for prompt in ['feedback_step21.txt','feedback_step22.txt','feedback_step23.txt','feedback_step24.txt','feedback_step25.txt','feedback_step3.txt']:
        assert (PROMPTS / prompt).exists()


def test_step22_does_not_support_llm_apply():
    src = text(BACKEND / 'rpr_feedback_service.py')
    assert '"step2-2": ("Step 2.2 — Portfolio Selection", "feedback_step22.txt", False)' in src


def test_server_registers_all_routers():
    src = text(BACKEND / 'server.py')
    assert 'app.include_router(enhancement_router)' in src
    assert 'app.include_router(step2_router)' in src
    assert 'app.include_router(feedback_router)' in src
    assert 'version="1.6"' in src


def test_html_has_step1_and_feedback_model_logging():
    src = text(HTML)
    assert "logModelsTriggered(data,'Step 1 Market Scanner')" in src
    assert "logModelsTriggered(data,'Step 1 Narrative Enrichment')" in src
    assert "logModelsTriggered(updated.enhancement_meta||updated,'Step 1 Targeted Rescan')" in src
    assert 'STEP21_FEEDBACK_HISTORY' in src
    assert 'STEP23_FEEDBACK_HISTORY' in src
    assert 'STEP3_FEEDBACK_HISTORY' in src


def test_no_css_change_vs_feedback_build():
    original = Path('/mnt/data/rpr_v72_step_feedback/frontend/rpr-step2-integrated-v31-v3-step-feedback.html')
    if not original.exists():
        return
    def css(s):
        return '\n'.join(re.findall(r'<style[^>]*>(.*?)</style>', s, flags=re.S|re.I))
    assert css(text(HTML)) == css(text(original))
