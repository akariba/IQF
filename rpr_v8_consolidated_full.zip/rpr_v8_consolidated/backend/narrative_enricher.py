"""Trigger-2 user narrative enrichment.

Desired business path:
    specific analyst narrative
      -> ADK/Gemini enterprise web retrieval
      -> Citi R2D2/Claude synthesis using the governed R2D2 prompt
      -> 8 Step-1 sections + deterministic evidence metadata

Trigger 2 therefore remains distinct from Trigger 1 discovery.  It never replaces
the user's specific event with a more popular event.
"""
from __future__ import annotations

import asyncio
import inspect
import json
import os
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from rpr_model_trace import model_span

from step1_quality import (
    SECTION_TITLES,
    assess_sections,
    build_machine_payload,
    overall_retrieval_status,
    select_improved_sections,
    parse_sectioned_report,
    strip_control_tags,
    summarize_quality,
)

try:
    from r2d2_prompt import R2D2_PROMPT  # type: ignore
except Exception as exc:  # pragma: no cover
    raise RuntimeError("r2d2_prompt.R2D2_PROMPT is required for Trigger 2") from exc

try:
    from rpr_search_agent import run_web_search as _adk_run_web_search  # type: ignore
except Exception:
    _adk_run_web_search = None


class NarrativeEnrichError(RuntimeError):
    pass


LABELS = {
    "event_overview": "Event Overview",
    "event_history": "Event History",
    "direct_impact_geographies": "Direct Impact Geographies",
    "contagion_impact_geographies": "Contagious Impact Geographies",
    "equity_market_impact": "Equity Market Impact",
    "credit_market_impact": "Credit Market Impact",
    "commodity_market_impact": "Commodity Market Impact",
    "assumptions": "Assumptions",
}

_INLINE_SOURCE_RE = re.compile(
    r"\(Source:\s*\[[^\]]+\]\((https?://[^)]+)\)\)",
    re.IGNORECASE,
)


PROMPT_DIR = Path(__file__).resolve().parent / "prompts"
WEB_RETRIEVAL_PROMPT_PATH = PROMPT_DIR / "trigger2_web_retrieval.txt"
SYNTHESIS_ADDON_PROMPT_PATH = PROMPT_DIR / "trigger2_opus_refinement.txt"
_OPUS_MODEL = os.environ.get("RPR_STEP1_REFINEMENT_MODEL", "claude-opus-4-6")
_OPUS_TIMEOUT = int(os.environ.get("RPR_T2_OPUS_TIMEOUT", "90"))


def _load_prompt(path: Path, fallback: str) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return fallback

_SEARCH_TIMEOUT = int(os.environ.get("RPR_T2_SEARCH_TIMEOUT", "90"))
_MAX_WEB_CONTEXT_CHARS = int(os.environ.get("RPR_T2_WEB_CONTEXT_MAX_CHARS", "24000"))


def _normalise_search_output(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        for key in ("text", "output", "response", "content", "answer"):
            if isinstance(value.get(key), str):
                return value[key]
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (list, tuple)):
        return "\n".join(_normalise_search_output(x) for x in value)
    return str(value)


def _await_in_thread(awaitable: Any, timeout: int) -> Any:
    result: Dict[str, Any] = {}
    error: Dict[str, BaseException] = {}

    def runner() -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result["value"] = loop.run_until_complete(asyncio.wait_for(awaitable, timeout=timeout))
        except BaseException as exc:  # noqa: BLE001
            error["error"] = exc
        finally:
            loop.close()

    th = threading.Thread(target=runner, daemon=True)
    th.start()
    th.join(timeout + 5)
    if th.is_alive():
        raise TimeoutError("ADK enrichment search timed out")
    if "error" in error:
        raise error["error"]
    return result.get("value")


def _adk_search_sync(prompt: str, timeout: int = _SEARCH_TIMEOUT, trace_label: str = "trigger2") -> str:
    if _adk_run_web_search is None:
        raise NarrativeEnrichError("ADK web search is unavailable")
    try:
        value = _adk_run_web_search(prompt, role="evidence", trace_label=trace_label)
    except TypeError:
        try:
            value = _adk_run_web_search(prompt, role="evidence")
        except TypeError:
            value = _adk_run_web_search(prompt)
    if inspect.isawaitable(value):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            value = asyncio.run(asyncio.wait_for(value, timeout=timeout))
        else:
            value = _await_in_thread(value, timeout)
    text = _normalise_search_output(value).strip()
    if not text:
        raise NarrativeEnrichError("ADK web search returned an empty response")
    return text


def _render_r2d2_prompt(narrative: str) -> str:
    now = datetime.now(timezone.utc).isoformat()
    rendered = str(R2D2_PROMPT)
    replacements = {
        "{narrative}": narrative,
        "{user_narrative}": narrative,
        "{original_narrative}": narrative,
        "{date}": now,
        "{current_date}": now,
        "{report_as_of}": now,
        "{REPORT_AS_OF}": now,
    }
    for token, value in replacements.items():
        rendered = rendered.replace(token, value)
    if narrative not in rendered:
        rendered += f"\n\nOriginal analyst narrative:\n{narrative}\nREPORT_AS_OF: {now}\n"
    return rendered


def _search_prompt(
    narrative: str,
    refinement_guidance: Optional[str],
    affected_sections: Sequence[str],
) -> str:
    now = datetime.now(timezone.utc).isoformat()
    system = _load_prompt(
        WEB_RETRIEVAL_PROMPT_PATH,
        "Retrieve current source-grounded web evidence for the analyst's specific event narrative without substituting another event.",
    )
    runtime = {
        "REPORT_AS_OF": now,
        "ORIGINAL_NARRATIVE": narrative,
        "TARGETED_SECTIONS": list(affected_sections or []),
        "ANALYST_APPROVED_REFINEMENT_GUIDANCE": str(refinement_guidance or "").strip() or None,
    }
    return system + "\n\n# RUNTIME INPUT\n" + json.dumps(runtime, ensure_ascii=False, indent=2)


def _call_text_with_timeout(
    gateway: Any,
    *,
    system_prompt: str,
    user_prompt: str,
    max_tokens: int,
    timeout: int,
) -> str:
    result: Dict[str, Any] = {}
    error: Dict[str, BaseException] = {}

    def runner() -> None:
        try:
            result["value"] = gateway.call_text(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                max_tokens=max_tokens,
            )
        except BaseException as exc:  # noqa: BLE001
            error["error"] = exc

    th = threading.Thread(target=runner, daemon=True)
    th.start()
    th.join(timeout)
    if th.is_alive():
        raise TimeoutError(f"R2D2 Opus refinement exceeded {timeout}s")
    if "error" in error:
        raise error["error"]
    return str(result.get("value") or "")


def _call_r2d2(system_prompt: str, user_prompt: str, trace_label: str = "trigger2") -> str:
    try:
        from llm_gateway import get_gateway  # type: ignore
        gateway = get_gateway()
    except Exception as exc:
        raise NarrativeEnrichError(f"R2D2 gateway unavailable: {exc}") from exc
    if not hasattr(gateway, "call_text"):
        raise NarrativeEnrichError("Trigger 2 requires an R2D2 gateway with call_text(); mock/search-only fallback is disabled")
    if hasattr(gateway, "_model"):
        gateway._model = _OPUS_MODEL
    try:
        with model_span(
            provider="r2d2",
            model=_OPUS_MODEL,
            role="trigger2_opus_refinement",
            scope=trace_label,
        ) as trace:
            text = _call_text_with_timeout(
                gateway,
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                max_tokens=6000,
                timeout=_OPUS_TIMEOUT,
            ).strip()
            trace.output_chars = len(text)
    except Exception as exc:
        raise NarrativeEnrichError(f"R2D2 Opus refinement failed: {exc}") from exc
    if not text:
        raise NarrativeEnrichError("R2D2 Opus refinement returned empty output")
    return text


def _quality_system_addon() -> str:
    return _load_prompt(
        SYNTHESIS_ADDON_PROMPT_PATH,
        "Preserve the specific event scope and return the eight Step-1 sections with sourced evidence, evidence tiers and retrieval status.",
    )


def _sections_from_base(base_sections: Optional[Sequence[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for i, title in enumerate(SECTION_TITLES):
        src = base_sections[i] if base_sections and i < len(base_sections) else {}
        out.append({"num": i + 1, "title": title, "txt": str(src.get("txt", src.get("text", "")) or "")})
    return out


def _filter_synthesis_citations(text: str, evidence_dossier: str) -> tuple[str, int]:
    """Remove R2D2 citations whose direct URL was not present in retrieved evidence.

    Trigger 2 synthesis is constrained to the ADK evidence dossier. A direct URL that is
    absent from that dossier cannot be treated as verified provenance even if the prose is
    otherwise plausible. Removing only the unsupported citation lets deterministic quality
    checks downgrade the claim rather than falsely counting it as sourced evidence.
    """
    dossier = str(evidence_dossier or "")
    removed = 0

    def repl(match: re.Match[str]) -> str:
        nonlocal removed
        url = str(match.group(1) or "").strip()
        if url and url in dossier:
            return match.group(0)
        removed += 1
        return ""

    cleaned = _INLINE_SOURCE_RE.sub(repl, str(text or ""))
    return re.sub(r"[ \t]{2,}", " ", cleaned).strip(), removed


def enrich_narrative(
    narrative: str,
    refinement_guidance: Optional[str] = None,
    affected_sections: Optional[Sequence[str]] = None,
    base_sections: Optional[Sequence[Dict[str, Any]]] = None,
    analyst_modified_sections: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    narrative = (narrative or "").strip()
    if not narrative:
        raise NarrativeEnrichError("Narrative is required")

    affected = [s for s in (affected_sections or []) if s in SECTION_TITLES]

    # Stage A — Gemini/ADK enterprise retrieval.
    web_prompt = _search_prompt(narrative, refinement_guidance, affected)
    web_context = _adk_search_sync(web_prompt, timeout=_SEARCH_TIMEOUT, trace_label="trigger2:evidence")
    web_context = web_context[:_MAX_WEB_CONTEXT_CHARS]
    search_parse = parse_sectioned_report(web_context)
    parsed_retrieval_queries = [str(q).strip() for q in (search_parse.get("search_queries") or []) if str(q).strip()]
    retrieval_queries = parsed_retrieval_queries or [web_prompt[:500]]
    query_log_source = "model_reported_search_formulations" if parsed_retrieval_queries else "search_instruction"

    # Stage B — R2D2/Claude synthesis using the governed prompt.
    system = _render_r2d2_prompt(narrative) + "\n\n" + _quality_system_addon()
    user_parts = [
        "ORIGINAL ANALYST NARRATIVE (scope/context only):\n" + narrative,
        "\nENTERPRISE WEB EVIDENCE DOSSIER:\n" + web_context,
    ]
    if refinement_guidance:
        user_parts.append(
            "\nANALYST-APPROVED REFINEMENT GUIDANCE (search direction only):\n" + str(refinement_guidance).strip()
        )
    if affected:
        user_parts.append("\nTARGETED SECTIONS: " + ", ".join(affected))
        user_parts.append("Only these sections may be replaced after quality comparison; unaffected sections must remain unchanged.")
    if base_sections:
        prior = _sections_from_base(base_sections)
        user_parts.append("\nPRIOR CONFIRMED/EDITABLE STEP-1 TEXT FOR UNCHANGED-SECTIONS REFERENCE:")
        for s in prior:
            user_parts.append(f"\n{s['title']}: {s['txt']}")

    raw = _call_r2d2(system, "\n".join(user_parts), trace_label="trigger2:final")
    parsed = parse_sectioned_report(raw)
    candidate_sections: List[Dict[str, Any]] = []
    for i, title in enumerate(SECTION_TITLES):
        parsed_text = strip_control_tags(str(parsed["sections"][i].get("txt", "") or ""))
        verified_text, removed_citations = _filter_synthesis_citations(parsed_text, web_context)
        candidate_sections.append({
            "num": i + 1,
            "title": title,
            "txt": verified_text,
            "retrieval_status": parsed["sections"][i].get("retrieval_status") or "SUCCESS",
            "model_evidence_tier": parsed["sections"][i].get("model_evidence_tier"),
            "model_retrieval_status": parsed["sections"][i].get("retrieval_status"),
            "unverified_citation_count": removed_citations,
        })

    rescan_result: Optional[Dict[str, Any]] = None
    final_modified = {s for s in (analyst_modified_sections or []) if s in SECTION_TITLES}
    if affected and base_sections:
        before = _sections_from_base(base_sections)
        final_sections, comparison = select_improved_sections(before, candidate_sections, affected)
        rescan_result = comparison
        final_modified -= set(comparison.get("accepted_sections") or [])
    else:
        final_sections = candidate_sections

    section_meta = assess_sections(final_sections)
    quality = summarize_quality(section_meta)
    retrieval_status = overall_retrieval_status(section_meta)
    synthesis_queries = parsed.get("search_queries") or []
    queries = retrieval_queries or synthesis_queries
    machine_payload = build_machine_payload(
        trigger="trigger2",
        sections=final_sections,
        event={"narrative_preview": narrative[:120]},
        query_log=queries,
        query_log_source=query_log_source,
        model_metadata=(parsed.get("machine_metadata") or {}) if not final_modified else {},
    )
    machine_payload["analyst_state"] = {
        "confirmed": False,
        "modified_sections": sorted(final_modified, key=lambda x: SECTION_TITLES.index(x)),
        "structured_model_metadata_reused": not bool(final_modified),
    }

    texts = {s["title"]: s["txt"] for s in final_sections}
    result: Dict[str, Any] = {
        "event_overview": texts["Event Overview"],
        "event_history": texts["Event History"],
        "direct_impact_geographies": texts["Direct Impact Geographies"],
        "contagion_impact_geographies": texts["Contagious Impact Geographies"],
        "equity_market_impact": texts["Equity Market Impact"],
        "credit_market_impact": texts["Credit Market Impact"],
        "commodity_market_impact": texts["Commodity Market Impact"],
        "assumptions": texts["Assumptions"],
        # Compatibility aliases.
        "event_summary": texts["Event Overview"],
        "history": texts["Event History"],
        "direct_impact": texts["Direct Impact Geographies"],
        "contagion_impact": texts["Contagious Impact Geographies"],
        "equity_impact": texts["Equity Market Impact"],
        "credit_impact": texts["Credit Market Impact"],
        "commodity_impact": texts["Commodity Market Impact"],
        "sections": final_sections,
        "machine_payload": machine_payload,
        "model_path": f"Gemini {os.environ.get('RPR_GEMINI_EVIDENCE_MODEL', 'gemini-3.5-flash')} enterprise retrieval -> R2D2 {_OPUS_MODEL} refinement",
        "models_triggered": [
            {"provider": "gemini", "model": os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", "gemini-3.5-flash"), "role": "trigger2_evidence_retrieval"},
            {"provider": "r2d2", "model": _OPUS_MODEL, "role": "trigger2_opus_refinement"},
        ],
        "enhancement_meta": {
            "narrative_preview": narrative[:120],
            "retrieval_failure": retrieval_status == "TECHNICAL_FAILURE",
            "retrieval_status": retrieval_status,
            "section_meta": section_meta,
            "quality": quality,
            "executed_query": " | ".join(queries),
            "query_log": queries,
            "query_log_source": query_log_source,
            "machine_payload": machine_payload,
            "model_path": f"Gemini {os.environ.get('RPR_GEMINI_EVIDENCE_MODEL', 'gemini-3.5-flash')} enterprise retrieval -> R2D2 {_OPUS_MODEL} refinement",
        "models_triggered": [
            {"provider": "gemini", "model": os.environ.get("RPR_GEMINI_EVIDENCE_MODEL", "gemini-3.5-flash"), "role": "trigger2_evidence_retrieval"},
            {"provider": "r2d2", "model": _OPUS_MODEL, "role": "trigger2_opus_refinement"},
        ],
        },
    }
    if rescan_result is not None:
        result["rescan_result"] = {
            **rescan_result,
            "guidance": str(refinement_guidance or "").strip(),
        }
    return result
