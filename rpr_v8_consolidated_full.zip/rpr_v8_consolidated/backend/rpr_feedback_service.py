"""Step-scoped feedback assistant service for RPR.

Each workflow page keeps its own feedback conversation and prompt contract.  This
module deliberately provides a small shared transport/runtime layer only; the user-
facing feedback semantics remain separated by step.
"""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List

from llm_gateway import get_gateway

log = logging.getLogger("uvicorn.error")
PROMPT_DIR = Path(__file__).resolve().parent / "prompts"
MODEL_FEEDBACK = os.environ.get("RPR_FEEDBACK_MODEL", os.environ.get("STEP2_SONNET_MODEL", "claude-sonnet-4-6"))

_STEP_CONFIG = {
    "step2-1": ("Step 2.1 — Scenario & Assumptions", "feedback_step21.txt", True),
    "step2-2": ("Step 2.2 — Portfolio Selection", "feedback_step22.txt", False),
    "step2-3": ("Step 2.3 — Event-Driven Risk Factors", "feedback_step23.txt", True),
    "step2-4": ("Step 2.4 — Sector-Inherent Risk Factors", "feedback_step24.txt", False),
    "step2-5": ("Step 2.5 — Name-Level Assessment", "feedback_step25.txt", False),
    "step3": ("Step 3 — Portfolio-Level Assessment", "feedback_step3.txt", False),
}

_ALLOWED_STATUS = {
    "ANSWER",
    "SUGGEST_REVISION",
    "NEEDS_CONTEXT",
    "OUT_OF_SCOPE",
    "GOVERNANCE_REVIEW",
}


class FeedbackError(RuntimeError):
    pass


def _load_prompt(name: str) -> str:
    path = PROMPT_DIR / name
    if not path.exists():
        raise FeedbackError(f"Required feedback prompt is missing: {path}")
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        raise FeedbackError(f"Required feedback prompt is empty: {path}")
    return text


def _trim(value: Any, depth: int = 0) -> Any:
    """Bound the payload so feedback remains fast and does not resend giant objects."""
    if depth > 5:
        return "[nested content omitted]"
    if isinstance(value, str):
        return value[:6000]
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for i, (k, v) in enumerate(value.items()):
            if i >= 40:
                out["_omitted_keys"] = len(value) - 40
                break
            out[str(k)] = _trim(v, depth + 1)
        return out
    if isinstance(value, list):
        return [_trim(v, depth + 1) for v in value[:20]]
    return value


def _clean_history(history: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    cleaned: List[Dict[str, str]] = []
    for item in (history or [])[-8:]:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").lower()
        if role not in {"user", "assistant"}:
            continue
        text = str(item.get("text") or item.get("content") or "").strip()
        if text:
            cleaned.append({"role": role, "text": text[:1800]})
    return cleaned


def _gateway_for_model(model: str):
    gw = get_gateway()
    # Match the existing RPR gateway routing convention without changing process env.
    if hasattr(gw, "_model"):
        gw._model = model
    return gw


def _call_json(system_prompt: str, payload: Dict[str, Any], model: str, role: str) -> Dict[str, Any]:
    gw = _gateway_for_model(model)
    if not hasattr(gw, "call_raw"):
        raise FeedbackError("Feedback calls require the prompt-oriented R2D2 gateway.")

    started = time.monotonic()
    log.info("[LLM] START provider=r2d2 model=%s role=%s scope=feedback", model, role)
    try:
        result = gw.call_raw(
            system_prompt,
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            max_tokens=2400,
        )
    except Exception:
        duration_ms = int((time.monotonic() - started) * 1000)
        log.exception("[LLM] END provider=r2d2 model=%s role=%s status=FAILED duration_ms=%s", model, role, duration_ms)
        raise
    duration_ms = int((time.monotonic() - started) * 1000)
    log.info("[LLM] END provider=r2d2 model=%s role=%s status=SUCCESS duration_ms=%s", model, role, duration_ms)

    if not isinstance(result, dict):
        raise FeedbackError("Feedback assistant response must be a JSON object.")
    return result


def assist_step_feedback(
    *,
    step_key: str,
    message: str,
    context: Dict[str, Any],
    history: List[Dict[str, Any]],
) -> Dict[str, Any]:
    key = str(step_key or "").strip().lower()
    if key not in _STEP_CONFIG:
        raise FeedbackError(f"Unsupported feedback step: {step_key}")
    text = str(message or "").strip()
    if not text:
        raise FeedbackError("Feedback message is required.")

    label, prompt_name, apply_supported = _STEP_CONFIG[key]
    payload = {
        "STEP": label,
        "CURRENT_STEP_CONTEXT": _trim(context or {}),
        "CHAT_HISTORY": _clean_history(history or []),
        "ANALYST_MESSAGE": text[:4000],
    }
    result = _call_json(
        _load_prompt(prompt_name),
        payload,
        MODEL_FEEDBACK,
        role=f"feedback_{key.replace('-', '_')}",
    )

    status = str(result.get("status") or "ANSWER").upper()
    if status not in _ALLOWED_STATUS:
        status = "ANSWER"
    answer = str(result.get("answer") or "").strip()
    if not answer:
        answer = "I need a more specific instruction for this step."

    proposed = str(result.get("proposed_instruction") or "").strip()
    targets = result.get("target_fields")
    if not isinstance(targets, list):
        targets = []

    can_apply = bool(apply_supported and status == "SUGGEST_REVISION" and proposed)
    return {
        "step_key": key,
        "step_label": label,
        "status": status,
        "answer": answer,
        "proposed_instruction": proposed,
        "target_fields": [str(x) for x in targets[:20]],
        "preserve_unaffected_content": bool(result.get("preserve_unaffected_content", True)),
        "apply_supported": can_apply,
        "model_path": MODEL_FEEDBACK,
        "models_triggered": [
            {"provider": "r2d2", "model": MODEL_FEEDBACK, "role": f"feedback_{key.replace('-', '_')}"}
        ],
    }
