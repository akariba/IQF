"""Structured model-call tracing for the RPR workflow.

Purpose
-------
Make the active LLM path observable without logging prompts, uploaded documents,
credentials, tokens, or raw model responses.

Log examples
------------
[LLM] START provider=gemini model=gemini-3.5-flash role=trigger1_evidence scope=event:E2
[LLM] END provider=gemini model=gemini-3.5-flash role=trigger1_evidence status=SUCCESS duration_ms=18342
[LLM] START provider=r2d2 model=claude-opus-4-6 role=trigger1_opus_refinement scope=event:E2

This module is intentionally dependency-free and thread-safe: each span is local to
the caller and no mutable process-wide trace state is required.
"""
from __future__ import annotations

import logging
import time
from contextlib import contextmanager
from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterator, Optional

log = logging.getLogger("uvicorn.error")


def _safe(value: Any, limit: int = 96) -> str:
    """Compact non-sensitive identifiers for logs.

    Callers should pass IDs / role labels, not raw analyst narratives or document text.
    """
    text = " ".join(str(value or "").replace("\n", " ").split())
    if len(text) > limit:
        text = text[: limit - 1] + "…"
    return text


@dataclass
class ModelTrace:
    provider: str
    model: str
    role: str
    scope: str = ""
    status: str = "RUNNING"
    duration_ms: int = 0
    output_chars: Optional[int] = None
    error_type: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@contextmanager
def model_span(
    *,
    provider: str,
    model: str,
    role: str,
    scope: str = "",
) -> Iterator[ModelTrace]:
    """Log START/END for a model call and yield a serialisable trace object."""
    trace = ModelTrace(
        provider=_safe(provider, 32),
        model=_safe(model, 64),
        role=_safe(role, 64),
        scope=_safe(scope, 96),
    )
    started = time.monotonic()
    log.info(
        "[LLM] START provider=%s model=%s role=%s scope=%s",
        trace.provider,
        trace.model,
        trace.role,
        trace.scope or "-",
    )
    try:
        yield trace
    except BaseException as exc:
        trace.status = "FAILED"
        trace.error_type = type(exc).__name__
        trace.duration_ms = int((time.monotonic() - started) * 1000)
        log.exception(
            "[LLM] END provider=%s model=%s role=%s scope=%s status=%s duration_ms=%s error=%s",
            trace.provider,
            trace.model,
            trace.role,
            trace.scope or "-",
            trace.status,
            trace.duration_ms,
            trace.error_type,
        )
        raise
    else:
        trace.status = "SUCCESS"
        trace.duration_ms = int((time.monotonic() - started) * 1000)
        log.info(
            "[LLM] END provider=%s model=%s role=%s scope=%s status=%s duration_ms=%s output_chars=%s",
            trace.provider,
            trace.model,
            trace.role,
            trace.scope or "-",
            trace.status,
            trace.duration_ms,
            trace.output_chars if trace.output_chars is not None else "-",
        )
