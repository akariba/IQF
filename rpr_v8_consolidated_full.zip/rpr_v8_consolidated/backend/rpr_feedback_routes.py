"""FastAPI routes for page-specific RPR feedback assistants."""
from __future__ import annotations

from typing import Any, Dict, List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from rpr_feedback_service import FeedbackError, assist_step_feedback

feedback_router = APIRouter(prefix="/api/v1/rpr/feedback", tags=["RPR Feedback"])


class StepFeedbackRequest(BaseModel):
    message: str
    context: Dict[str, Any] = Field(default_factory=dict)
    history: List[Dict[str, Any]] = Field(default_factory=list)


def _assist(step_key: str, req: StepFeedbackRequest) -> Dict[str, Any]:
    try:
        return assist_step_feedback(
            step_key=step_key,
            message=req.message,
            context=req.context,
            history=req.history,
        )
    except (FeedbackError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Feedback assistant failed: {type(exc).__name__}: {exc}") from exc


@feedback_router.post("/step2-1/assist")
def feedback_step21(req: StepFeedbackRequest):
    return _assist("step2-1", req)


@feedback_router.post("/step2-2/assist")
def feedback_step22(req: StepFeedbackRequest):
    return _assist("step2-2", req)


@feedback_router.post("/step2-3/assist")
def feedback_step23(req: StepFeedbackRequest):
    return _assist("step2-3", req)


@feedback_router.post("/step2-4/assist")
def feedback_step24(req: StepFeedbackRequest):
    return _assist("step2-4", req)


@feedback_router.post("/step2-5/assist")
def feedback_step25(req: StepFeedbackRequest):
    return _assist("step2-5", req)


@feedback_router.post("/step3/assist")
def feedback_step3(req: StepFeedbackRequest):
    return _assist("step3", req)
