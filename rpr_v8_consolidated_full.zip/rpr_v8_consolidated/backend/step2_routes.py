"""FastAPI router for governed Step 2.1 and Step 2.3 test endpoints."""
from __future__ import annotations

from typing import Any, Dict, List

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel, Field

from step2_service import (
    Step2Error, assess_optional_context, assist_feedback, finalize_scenario,
    generate_event_factors, generate_scenario, revise_event_factors, revise_scenario,
)
from step2_uploads import UploadExtractionError, extract_context_file

step2_router = APIRouter(prefix="/api/v1/rpr/step2", tags=["RPR Step 2"])


class ContextAssessRequest(BaseModel):
    confirmed_step1: Dict[str, Any]
    horizon: str
    typed_context: str = ""
    uploaded_contexts: List[Dict[str, Any]] = Field(default_factory=list)


class ScenarioGenerateRequest(ContextAssessRequest):
    pass


class FeedbackAssistRequest(BaseModel):
    confirmed_step1: Dict[str, Any]
    horizon: str
    current_scenario: Dict[str, Any]
    feedback: str


class ScenarioReviseRequest(BaseModel):
    confirmed_step1: Dict[str, Any]
    horizon: str
    base_scenario: Dict[str, Any]
    confirmed_feedback: str
    accepted_context: List[Dict[str, Any]] = Field(default_factory=list)


class ScenarioFinalizeRequest(BaseModel):
    scenario: Dict[str, Any]
    analyst_modified_fields: List[str] = Field(default_factory=list)


class EventFactorsRequest(BaseModel):
    confirmed_step1: Dict[str, Any]
    confirmed_scenario: Dict[str, Any]
    sector: str
    portfolio_context: Dict[str, Any] = Field(default_factory=dict)


class EventFactorsReviseRequest(BaseModel):
    confirmed_step1: Dict[str, Any]
    confirmed_scenario: Dict[str, Any]
    sector: str
    base_factors: Dict[str, Any]
    confirmed_feedback: str
    portfolio_context: Dict[str, Any] = Field(default_factory=dict)


def _raise_http(exc: Exception):
    if isinstance(exc, (Step2Error, UploadExtractionError, ValueError)):
        raise HTTPException(status_code=400, detail=str(exc))
    raise HTTPException(status_code=502, detail=f"Step-2 processing failed: {type(exc).__name__}: {exc}")


@step2_router.post("/context/assess")
def context_assess(req: ContextAssessRequest):
    try:
        return assess_optional_context(req.confirmed_step1, req.horizon, req.typed_context, req.uploaded_contexts)
    except Exception as exc:
        _raise_http(exc)


@step2_router.post("/context/extract")
async def context_extract(file: UploadFile = File(...)):
    try:
        return extract_context_file(file.filename or "upload", await file.read(), file.content_type or "")
    except Exception as exc:
        _raise_http(exc)


@step2_router.post("/scenario/generate")
def scenario_generate(req: ScenarioGenerateRequest):
    try:
        return generate_scenario(req.confirmed_step1, req.horizon, req.typed_context, req.uploaded_contexts)
    except Exception as exc:
        _raise_http(exc)


@step2_router.post("/feedback/assist")
def feedback_assist(req: FeedbackAssistRequest):
    try:
        return assist_feedback(req.confirmed_step1, req.horizon, req.current_scenario, req.feedback)
    except Exception as exc:
        _raise_http(exc)


@step2_router.post("/scenario/revise")
def scenario_revise(req: ScenarioReviseRequest):
    try:
        return revise_scenario(req.confirmed_step1, req.horizon, req.base_scenario, req.confirmed_feedback, req.accepted_context)
    except Exception as exc:
        _raise_http(exc)


@step2_router.post("/scenario/finalize")
def scenario_finalize(req: ScenarioFinalizeRequest):
    try:
        return finalize_scenario(req.scenario, req.analyst_modified_fields)
    except Exception as exc:
        _raise_http(exc)


@step2_router.post("/event-factors/generate")
def event_factors_generate(req: EventFactorsRequest):
    try:
        return generate_event_factors(req.confirmed_step1, req.confirmed_scenario, req.sector, req.portfolio_context)
    except Exception as exc:
        _raise_http(exc)


@step2_router.post("/event-factors/revise")
def event_factors_revise(req: EventFactorsReviseRequest):
    try:
        return revise_event_factors(
            req.confirmed_step1, req.confirmed_scenario, req.sector,
            req.base_factors, req.confirmed_feedback, req.portfolio_context,
        )
    except Exception as exc:
        _raise_http(exc)
