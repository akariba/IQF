"""
narrative_enricher.py — Trigger 2 ("R2D2" narrative enrichment).

CORRECTED ARCHITECTURE: Trigger 2 now shares the SAME ADK web-search call
path as Trigger 1 (market_event_scout.py), instead of a separate direct
Anthropic API client. This was a real design error in the previous
version of this file, not just a config difference — it meant Trigger 2
needed its own credentials/auth flow when it should simply inherit
whatever auth Trigger 1's ADK agent already has working (H2M/Helix token,
per internal confirmation).

The only things that differ between the two triggers now are:
  - the QUERY sent to the ADK agent: R2D2_PROMPT here, vs. the
    theme-based query _build_query() builds in market_event_scout.py
  - the response PARSER: label-splitting on this prompt's field titles
    ("Event Overview:", etc.), vs. MarketEventParser's [EVENT_N]/[S1]
    block parser

MODEL SELECTION (Gemini vs Claude Sonnet) IS NOT CONTROLLED HERE.
That lives inside web_search_agent.py / the ADK agent definition itself,
which this module does not have visibility into. Whatever model that
agent is configured to use for Trigger 1 is automatically what Trigger 2
uses too, since both now go through the same _adk_search_sync() call.

>>> OPEN QUESTION FOR WHOEVER CAN READ web_search_agent.py <<<
Google's ADK commonly uses a model's own native "search grounding" tool
(e.g. Gemini's built-in google_search grounding) rather than a
model-agnostic search tool. If that's how this agent's web search is
wired, swapping the model string from Gemini to Claude Sonnet may not be
a one-line change — Claude doesn't share Gemini's grounding mechanism,
so the search TOOL implementation (not just the model parameter) may
need to change too. This needs confirming against the actual
web_search_agent.py source before assuming a simple model-name swap is
sufficient.
"""

from __future__ import annotations

import logging
import re
from datetime import date

from market_event_scout import _adk_search_sync, _ADK_AVAILABLE
from r2d2_prompt import R2D2_PROMPT

log = logging.getLogger("narrative_enricher")

NO_DATA_MARKER = "no data returned for this section"

# (flat_key, exact label text as it appears in r2d2_prompt.py's Output Format)
LABELS: list[tuple[str, str]] = [
    ("event_overview", "Event Overview"),
    ("event_history", "Event History"),
    ("direct_impact_geographies", "Direct Impact Geographies"),
    ("contagion_impact_geographies", "Contagious Impact Geographies"),
    ("equity_market_impact", "Equity Market Impact"),
    ("credit_market_impact", "Credit Market Impact"),
    ("commodity_market_impact", "Commodity Market Impact"),
    ("assumptions", "Assumptions"),
]

# Alternate key names the frontend's rs(data, primaryKey, fallbackKey)
# helper also checks — every section is emitted under both.
SECTION_ALIASES = {
    "event_overview": "event_summary",
    "event_history": "history",
    "direct_impact_geographies": "direct_impact",
    "contagion_impact_geographies": "contagion_impact",
    "equity_market_impact": "equity_impact",
    "credit_market_impact": "credit_impact",
    "commodity_market_impact": "commodity_impact",
    "assumptions": "assumptions",
}

_LABEL_PATTERN = re.compile(
    r"^\s*(" + "|".join(re.escape(title) for _, title in LABELS) + r")\s*:\s*",
    re.IGNORECASE | re.MULTILINE,
)


class NarrativeEnrichError(RuntimeError):
    """Raised when the ADK call fails or its output can't be parsed."""


def _parse_sections(text: str) -> dict[str, str]:
    """Same label-splitting approach as MarketEventParser's Method 1,
    applied to R2D2_PROMPT's field titles instead of [S1]/[S2] markers."""
    matches = list(_LABEL_PATTERN.finditer(text))
    if not matches:
        return {}

    by_title: dict[str, str] = {}
    for i, m in enumerate(matches):
        title = m.group(1).strip().lower()
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        by_title[title] = text[start:end].strip()

    out: dict[str, str] = {}
    for key, title in LABELS:
        val = by_title.get(title.lower(), "")
        if val.strip().lower().startswith(NO_DATA_MARKER):
            val = ""  # normalize to empty so the frontend's existing
                      # "NO DATA" badge logic (checks for emptiness) fires
        out[key] = val
    return out


def enrich_narrative(narrative: str) -> dict:
    """
    Runs Trigger 2 through the same ADK agent Trigger 1 uses. Returns a
    flat dict with every LABELS key + its SECTION_ALIASES counterpart
    populated (value may be "" for a section with genuinely no data).
    """
    if not _ADK_AVAILABLE:
        raise NarrativeEnrichError(
            "ADK web_search_agent is not available in this environment — "
            "same dependency Trigger 1 needs. Check scout.preflight() "
            "['adk_available'] before calling this."
        )

    prompt = R2D2_PROMPT.format(
        today=date.today().isoformat(),
        narrative=narrative.replace('"', "'"),
    )

    log.info("Calling ADK agent for Trigger 2 (narrative enrichment)…")
    try:
        raw_text = _adk_search_sync(prompt, timeout=240)
    except TimeoutError as exc:
        raise NarrativeEnrichError(f"ADK call timed out: {exc}") from exc
    except Exception as exc:
        raise NarrativeEnrichError(f"ADK call failed: {exc}") from exc

    if not raw_text or len(raw_text.strip()) < 100:
        raise NarrativeEnrichError(
            "ADK returned an empty/near-empty response — same failure "
            "mode as Trigger 1's 'no_results' placeholder path. This is "
            "very likely the same upstream root cause, not a Trigger-2-"
            "specific bug — check the same diagnosis track that applies "
            "to Trigger 1."
        )

    sections = _parse_sections(raw_text)
    if not sections:
        log.warning(
            "No labelled sections found in ADK response — check that the "
            "model followed the 'Title:' format. Raw preview: %r",
            raw_text[:400],
        )

    out: dict = {}
    for key, _title in LABELS:
        val = sections.get(key, "")
        out[key] = val
        out[SECTION_ALIASES[key]] = val

    n_populated = sum(1 for k, _ in LABELS if out[k])
    log.info("Enrichment parsed — %d/%d sections have content.", n_populated, len(LABELS))

    return out
